@echo off
setlocal
title Setup - BasedF Tool
color 0B

echo.
echo ====================================================
echo        INSTALLATION DE MYTOOL - by BasedF
echo ====================================================
echo.

:: 1. Verification de Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Erreur : Python n'est pas installe ou n'est pas dans le PATH.
    echo     Telecharge-le sur https://www.python.org/downloads/
    pause
    exit /b
)

:: 2. Installation des dependances
echo [*] Verification des dependances (requests, aiohttp, etc.)...
python -m pip install --upgrade pip >nul 2>&1
python -m pip install requests aiohttp phonenumbers pyautogui pycryptodome pywin32 colorama

if %errorlevel% neq 0 (
    echo [!] Attention : certaines dependances n'ont pas pu etre installees.
    echo     Essaie de lancer ce .bat en tant qu'Administrateur.
)

:: 3. Renommage du fichier .txt en .py si necessaire
if exist "import os.txt" (
    echo [*] Renommage de "import os.txt" en "mytool.py"...
    ren "import os.txt" "mytool.py"
)

:: 4. Lancement du tool
echo.
echo [+] Installation terminee. Lancement du tool...
echo ====================================================
echo.
python mytool.py

pause