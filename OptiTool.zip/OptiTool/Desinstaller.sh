#!/bin/bash

# Couleurs
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "===================================================="
echo "       INSTALLATION DE MYTOOL - by BasedF"
echo "===================================================="
echo -e "${NC}"

# 1. Verification de Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[!] Erreur : python3 n'est pas installe.${NC}"
    echo "    Sur Debian/Ubuntu : sudo apt install python3 python3-pip"
    echo "    Sur macOS         : brew install python3"
    exit 1
fi

# 2. Installation des dependances (avec pip3)
echo -e "${BLUE}[*] Installation des dependances...${NC}"
python3 -m pip install --upgrade pip
python3 -m pip install requests aiohttp phonenumbers pyautogui pycryptodome colorama

if [ $? -ne 0 ]; then
    echo -e "${RED}[!] Attention : certaines dependances n'ont pas pu etre installees.${NC}"
    echo "    Essaie avec sudo ou un environnement virtuel (venv)."
fi

# 3. Renommage du fichier si besoin
if [ -f "import os.txt" ]; then
    echo -e "${BLUE}[*] Renommage de 'import os.txt' en 'mytool.py'...${NC}"
    mv "import os.txt" mytool.py
fi

# 4. Lancement
echo -e "\n${GREEN}[+] Installation terminee. Lancement...${NC}"
echo "===================================================="
python3 mytool.py