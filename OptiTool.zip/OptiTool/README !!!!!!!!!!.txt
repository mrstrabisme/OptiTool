
🛠️ OptiTools - Multi-Tool 

**Un outil multifonction en Python pour le Pentest, l'OSINT, le Web Scraping et le Stealer Builder.**

![Version](https://img.shields.io/badge/version-1.0-blue)
![Python](https://img.shields.io/badge/python-3.8%2B-brightgreen)
![OS](https://img.shields.io/badge/OS-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey)

---

📋 Description

`OPTITOOL` est une suite d'outils "tout-en-un" développée en Python. Conçue avec une interface CLI animée, elle regroupe plus de 40 fonctionnalités allant du scan de vulnérabilités web à la création de tokens Discord, en passant par l'OSINT  et l'analyse réseau. 

L'outil est divisé en 3 pages pour naviguer facilement entre les différentes catégories.

---

 🚀 Installation

 Méthode 1 : Automatique (Recommandée)

**Pour Windows :**
1. Télécharge le projet et place `setup.bat` dans le même dossier.
2. Double-clique sur `setup.bat`. Il installera Python (si absent) et toutes les dépendances.

**Pour Linux / macOS :**
1. Ouvre un terminal dans le dossier du projet.
2. Rends le script exécutable et lance-le :
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

 Méthode 2 : Manuelle

Si tu préfères installer les dépendances toi-même :

```bash
pip install requests aiohttp phonenumbers pyautogui pycryptodome pywin32
```

Puis lance le script :
```bash
python mytool.py
```

---

 ⚙️ Fonctionnalités

### Page 1 : Utilitaires & OSINT
| ID | Module | Description |
|---|---|---|
| 1 | **DDoS Url** | Test de charge avec rotation de proxies. |
| 2 | **Username Tracker** | Recherche un pseudo sur plus de 80 sites web. |
| 3 | **Text Bomber** | Automatisation d'envoi de messages (PyAutoGUI). |
| 4 | **Phone Info** | OSINT sur les numéros de téléphone (opérateur, pays, annuaires). |
| 5 | **Breach Email Lookup** | Vérifie si un email a fuité dans des bases de données. |
| 6 | **Dox Creator** | Génère un rapport stylisé à partir d'informations OSINT. |
| 7 | **Email Searcher** | Recherche approfondie sur un email (LeakCheck, IntelX). |
| 8-14 | **Builders** | Générateurs de Token Grabber, Stealer, RAT, Keylogger, etc. |
| 15-20 | **Utilitaires** | Générateur de mots de passe, Proxy Scrapper, Hash Cracker. |

### Page 2 : Exploits & Réseau
| ID | Module | Description |
|---|---|---|
| 21 | **Port Scanner** | Scan de ports avec multi-threading et détection de services. |
| 22 | **SQLi Exploit** | Test et extraction de bases de données via injection SQL. |
| 23 | **XSS Exploit** | Détection et génération de payloads Cross-Site Scripting. |
| 24 | **LFI Exploiter** | Test de Local File Inclusion. |
| 25 | **Dir Bruteforce** | Recherche de répertoires et fichiers cachés. |
| 26 | **WAF Detector** | Détecte la présence d'un pare-feu applicatif web. |
| 28 | **IP Port DDoS** | Flood TCP/UDP sur une IP. |
| 29-34 | **Réseau** | DNS Lookup, MAC Lookup, Reverse IP, etc. |
| 35-40 | **Exploits** | JWT Cracker, SSRF Scanner, OS Cmd Inject, etc. |

### Page 3 : Chaos & Payloads
| ID | Module | Description |
|---|---|---|
| 41-44 | **Builders** | Ransomware, Steal All, Brute Force, Reverse Shell. |
| 45-49 | **Scanners** | Git Secrets, Cloud Exploiter, Base64 Encoder, Exe to Image. |
| 50-60 | **Payloads** | Webhook Flooder, JWT Forger, AMSI Bypass, CVE Search, etc. |




┌─────────────────────────────────────────────────────────────────────┐
│                                                                                                
│        ▒█████   ██▓███  ▄▄▄█████▓ ██▓▄▄▄█████▓ ▒█████   ▒█████   ██▓       
│        ▒██▒  ██▒▓██░  ██▒▓  ██▒ ▓▒▓██▒▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒        
│        ▒██░  ██▒▓██░ ██▓▒▒ ▓██░ ▒░▒██▒▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░        
│        ▒██   ██░▒██▄█▓▒ ▒░ ▓██▓ ░ ░██░░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░          
│        ░ ████▓▒░▒██▒ ░  ░  ▒██▒ ░ ░██░  ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒  
│        ░ ▒░▒░▒░ ▒▓▒░ ░  ░  ▒ ░░   ░▓    ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░       
│          ░ ▒ ▒░ ░▒▓░         ░     ▒ ░    ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░              
│         ░ ░ ░ ▒  ░░         ░       ▒ ░  ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░                   
│            ░ ░                     ░               ░ ░      ░ ░      ░  ░                    
├──────────────────────────────────────────────────────────────────────
│                                OptiTools.py - by MrStrabisme                      
└──────────────────────────────────────────────────────────────────────
```

---

⚠️ Avertissement 

Ce projet est fourni à des fins éducatives.
L'utilisation de ces outils pour attaquer des cibles sans autorisation écrite préalable est illégale et constitue une violation des lois sur la cybersécurité (notamment les articles 323-1 à 323-7 du Code pénal en France). 

L'auteur (`MrStrabisme`) n'assume aucune responsabilité quant à l'utilisation malveillante ou illégale de ce logiciel. Utilisez-le uniquement sur vos propres systèmes.
